myApp
		.controller(
				"agentCtrl",
				function($scope, $rootScope, $state, $localStorage, $compile) {
					$rootScope.submitted = false;
					$scope.uiRouterState = $state;
					$scope.accCurrency = getCurrencyDropdown();
					$scope.docType = getDocType();
					$scope.prospectCount = getTotalCount("prospect");
					$scope.custConvertCount = getTotalCount("custConvert");
					$scope.custOnboardCount = getTotalCount("custOnboard");
					$scope.agentObj = $localStorage.agentObj;
					$scope.onMaturityTypes = getOnMaturityTypes();
					$scope.listType = "";
					$scope.docArr = [];
					$scope.docArrCust = [];
					// Added by Linmoy::START
					$scope.errorMsgDesc = "";
					$scope.inputObj = {};
					$scope.rdSuccess = "TRANS1234";
					$scope.fdSuccess = "TRANS1234";
					$scope.saSuccess = "TRANS1234";
					$scope.Data.accCurrency = "USD";
					// Added by Linmoy::END
					$scope.listType = "TRANS1234";
					$scope.convertCustArr = [];
					$scope.frequency = getFrequency();
					$scope.expenseType = getExpenseType();
					$scope.assetType = getAssetType();
					$scope.liabilityType = getLiabilityType();
					$scope.booleanVal = getBooleanVal();
					$scope.loanTypeSelect = getLoanType();
					$scope.countryList = getCountry();
					$scope.stateList = getState();
					$scope.cityList = getCity();
					$scope.loanObj = {};
					$scope.loanObjComplete = {};
					$scope.inputObj = {};
					$scope.inputObject = {};
					$scope.$on('$stateChangeStart', function(event, toState,
							toParams, fromState, fromParams) {
						$rootScope.submitted = false;
						var toStateName = toState.name;
						var fromStateName = fromState.name;
						$scope.currentView = "Create";
						$scope.titleCust = "Capture";
						$scope.signStatus = "Pending";
						$scope.imgStatus = "Pending";
						$scope.docArrCust = [];
						if (toStateName.indexOf("upsandcomers.") > -1
								&& toStateName.indexOf("success") == -1) {
							if (fromStateName == toStateName + 'success') {
								if (!fromParams.foo) {
									delete $scope.cif;
									$scope.inputObj = {};
									delete $scope.entityId;
								}
							} else {
								delete $scope.cif;
								$scope.inputObj = {};
								delete $scope.entityId;
							}
						}
						/*
						 * if (fromStateName.indexOf("upsandcomers.") > -1 &&
						 * fromStateName.indexOf("success") > -1) {
						 * $scope.inputObj = null; $scope.cif = null; }
						 */

					});
					/*
					 * $scope.openBarcodeScan = function(k) { var params = {
					 * nameParam : null };
					 * WL.NativePage.show("com.MobyBanker.BarcodeScan",
					 * function(data) { $("#name").val(data.name);
					 * $("#nationality").val("Indian"); $("#dob").val(data.dob);
					 * $("#pincode").val(data.pincode);
					 * $("#addline1").val(data.hno);
					 * $("#addline2").val(data.addr);
					 * $("#guardianname").val(data.co);
					 * $("#relationship").val(data.relation);
					 * //alert(JSON.stringify(data));
					 * 
					 * $scope.cardNum = data.cardNum; $scope.$apply(); },
					 * params); }
					 */
					$scope.setCurrentView = function(viewName) {
						$scope.currentView = viewName;
					}
					$scope.fetchDtlsForCaptureCust = function() {
						$scope.inputObj.entityId = $scope.inputObj.cifId;
						$scope.inputObj.nic = "98745621";
						$scope.inputObj.salutation = "Mr.";
						$scope.inputObj.name = "John Thomas";
						$scope.inputObj.nationality="American";
						$scope.inputObj.passportNum="BJ192999KSS";
						$scope.inputObj.guardianname="Nulen Depp";
						$scope.inputObj.customerid="8289929";
						$scope.inputObj.relationship="FATHER";
						$scope.inputObj.dob = "1991-27-04T00:00:00";
						$scope.inputObj.addressLine1 = "142";
						$scope.inputObj.addressLine2 = "Street XYZ";
						$scope.inputObj.city = "Harrisburg";
						$scope.inputObj.country = "USA";
						$scope.inputObj.mobileno = "78945612300";
						$scope.inputObj.telno = "92891723989";
						$scope.inputObj.email = "john@gmail.com";
						if ($scope.currentView == "Edit") {
							$scope.currentView = "modify";
						} else {
							$scope.currentView = "viewed";
						}
						setTimeout(function() {
							/*$("#dob").attr("data-date", "27-04-1991");
							$("#addressDate").attr("data-date", "27-04-1999");*/
							$scope.inputObj.dob = "1991-27-04T00:00:00";
							$scope.inputObj.addressDate = "1991-27-04T00:00:00";
							$("#dob").val("1991-04-27");
							$("#addressDate").val("1991-04-27");
							$("select").selectmenu("refresh", true);
						}, 0);
					}
					
					$scope.minorCheck = function() {
						var diff = Math.floor((Date.parse(new Date()) - Date
								.parse($scope.inputObj.dob)) / 86400000);
						if (diff >= 6574) {
							$scope.inputObj.minorFlag = "N";
						} else {
							$scope.inputObj.minorFlag = "Y";
						}
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
						}, 0);
					}
					
					$scope.openView = function(viewName) {

						if ($state.current.name != "dashboard.customeronboard")
							if (viewName == "Create") {
								$scope.titleCust = "Capture";
							} else {
								$scope.titleCust = viewName;
							}
						$scope.inputObj = {};
						$scope.setCurrentView(viewName);
						$scope.inputObj.accCurrency = "USD";
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
							$("input:radio").checkboxradio("refresh");
						}, 0);
						if ($state.current.name != "upsandcomers.customeronboard") {
							$scope.titleName = viewName;
							$(".ui-collapsible-heading").addClass(
									"ui-collapsible-heading-collapsed");
							$(".ui-collapsible-content").addClass(
									"ui-collapsible-content-collapsed");
							$(".ui-collapsible-heading a").removeClass(
									"ui-icon-carat-d").addClass(
									"ui-icon-carat-r");
						} else {
							if (viewName == "Create") {
								$scope.titleCust = "Capture";
							} else {
								$scope.titleCust = viewName;
							}
						}
					}
					$scope.openProspectDetails = function(k) {
						$state
								.go("upsandcomers.captureprospect")
								.then(
										function() {
											$scope.entityId = k;
											$scope.inputObj = $scope.agentObj.prospect[k];
											$scope.inputObj.dob = new Date(
													$scope.agentObj.prospect[k].dob)
										});
					}

					$scope.convertProspectDetails = function(k) {
						$state
								.go("upsandcomers.captureprospect")
								.then(
										function() {
											$scope.entityId = k;
											$scope.inputObj = $scope.agentObj.custConvert[k];
											$scope.inputObj.dob = new Date(
													$scope.agentObj.custConvert[k].dob)
										});
					}

					$scope.convertCustomerDetails = function(k) {
						$state
								.go("upsandcomers.customeronboard")
								.then(
										function() {
											$scope.entityId = k;
											$scope.inputObj = $scope.agentObj.custOnboard[k];
											$scope.inputObj.dob = new Date(
													$scope.agentObj.custOnboard[k].dob)
										});
					}
					$scope.openProdCodePopup = function() {
						$("#productCodePopup").popup("destroy");
						$("#productCodePopup").show();
						$("#productCodePopup").popup().popup("open");
					}

					$scope.closeProdCode = function() {
						closePopup("productCodePopup");
					}
					$scope.selectProductCode = function() {
						$scope.inputObj.productCode = $scope.inputObj.row;
						closePopup("productCodePopup");
					}
					$scope.recordSelected = function(result) {

						if (result == "selectall" && this.selectall) {
							$scope.convertCustArr = Object
									.keys($scope.agentObj.prospect);
						} else if (result == "selectall") {
							$scope.convertCustArr = [];
						} else {
							if (result != undefined
									&& result.indexOf('false') > -1) {
								$scope.convertCustArr.splice($.inArray(result
										.split("_")[1], $scope.convertCustArr),
										1);
							} else if ($scope.convertCustArr.indexOf(result) > -1) {
								alert("ssss" + result);
								$scope.convertCustArr.splice($.inArray(result,
										$scope.convertCustArr), 1);
							} else {
								$scope.convertCustArr.push(result);
							}
						}
					};

					// to navigate to any child page from back/repeat
					// transaction btn
					$scope.navigateToPage = function(page) {
						/*
						 * $state.go(page, {}, { reload : true
						 * }).then(function() { animatePage(); });
						 */
						$(".highlight").removeClass("highlight");
						$state.go(page);
					}

					$scope.createAnotherClick = function() {
						if ($state.current.name == "upsandcomers.captureprospectsuccess") {
							$state.go("upsandcomers.captureprospect");
						} else {
							$state.go("upsandcomers.customeronboard");
						}
					}

					$scope.processCaptureProspect = function(inputObj) {
						var week = "agentWeek"
								+ Math.ceil(new Date().getDate() / 7);
						var cif = $scope.entityId;
						if ($state.current.name == "upsandcomers.captureprospect") {
							$scope.inputObj = angular.copy(inputObj);
							if (cif == null || cif == "" || cif == undefined) {
								$localStorage[week].prospect = $localStorage[week].prospect + 1;
								cif = "CIF"
										+ (('00000' + ($localStorage[week].prospect + $localStorage[week].custConvert))
												.substr(-5, 5));
							}
							$scope.cif = cif;
							$localStorage.agentObj.prospect[cif] = $scope.inputObj;
						} else {
							$scope.inputObj = angular.copy(inputObj);
							if (cif == null || cif == "" || cif == undefined) {
								$localStorage[week].custOnboard = $localStorage[week].custOnboard + 1;
								cif = "CIFC"
										+ (('00000' + $localStorage[week].custOnboard)
												.substr(-5, 5));
							}
							$scope.cif = cif;
							$localStorage.agentObj.custOnboard[cif] = $scope.inputObj;
						}
						processAgentSubmit(this);
					}

					$scope.processCustomerConverted = function(inputObj) {
						$scope.inputObj = angular.copy(inputObj);
						var week = "agentWeek"
								+ Math.ceil(new Date().getDate() / 7);
						var cif = $scope.convertCustArr;
						$scope.convertCustArr = [];
						$scope.cif = cif;

						// var cif = $('input:checked').val();
						for (var i = 0; i < cif.length; i++) {
							var cifid = cif[i];
							var a = $localStorage.agentObj.prospect;
							$localStorage.agentObj.custConvert[cifid] = a[cifid];
							delete a[cifid];
							$localStorage.agentObj.prospect = a;
						}
						$localStorage[week].custConvert = $localStorage[week].custConvert
								+ cif.length;
						$localStorage[week].prospect = $localStorage[week].prospect
								- cif.length;
						processAgentSubmit(this);
					};

					$scope.openAgentList = function(type, id) {

						/*
						 * $scope.listType = type;
						 * $state.go("upsandcomers.agentlist", { listType :
						 * type}, { reload : true });
						 */
						$(".collapseLinkC .ui-btn-active").removeClass(
								"ui-btn-active")
						$(".highlight").removeClass("highlight");
						$("#" + id).addClass('highlight');
						if (type == "prospect") {
							$state.go("upsandcomers.agentlist");
						} else if (type == "custConvert") {
							$state.go("upsandcomers.agentlist1");
						} else if (type == "custOnboard") {
							$state.go("upsandcomers.agentlist2");
						}
					};

					$scope.getDataSource = function() {
						if (type = "prospect") {
							return $scope.agentObj.prospect;
						} else if (type = "custConvert") {
							return $scope.agentObj.custConvert;
						} else if (type = "custOnboard") {
							return $scope.agentObj.custOnboard;
						}
					};

					$scope.agentCaptureContineBtn = function(id) {

						if (id == "a") {
							$('.animateMe').removeClass('next-element');
							$('.animateMe').removeClass('next');
							// $("#a").parent('.animateMe').next('div').addClass('next-element');
							$("#a").collapsible("collapse");
							$("#b").collapsible("expand");
							$('#c').addClass('next');
							$('#c').addClass('next-element');
							$('#d').addClass('next');
						}
						if (id == "b") {
							$('.animateMe').removeClass('next-element');
							$("#b").parent('.animateMe').next('div').addClass(
									'next-element');
							$("#b").collapsible("collapse");
							$("#c").collapsible("expand");
							$('.animateMe').removeClass('next');
							$('.animateMe').removeClass('previous');

							$('#d').addClass('next-element');
						}
						if (id == "c") {
							$('.animateMe').removeClass('next-element');
							$("#c").parent('.animateMe').next('div').addClass(
									'next-element');
							$("#c").collapsible("collapse");
							$("#d").collapsible("expand");
							$('#c').removeClass('next');
							$('.animateMe').removeClass('next');
							$('.animateMe').removeClass('previous');
						}
					}

					$scope.loanBackBtnClick = function() {
						$state.go("upsandcomers.loanApp").then(function() {
							$scope.loanType = "personal";
						});
					};

					$scope.identificationScan = function() {
						var documnt = this.docDetailsObj;
						$scope.docArr.push(documnt);
						this.docDetailsObj = "";
					};

					$scope.dynamicFormSubmit = function(a, i) {
						angular.forEach($scope["loanObj"],
								function(value, key) {
									var lbl = $("#lbl" + key).text();
									$scope.loanObjComplete[lbl] = value;
								});
						var resp = $scope["loanObj"]["select" + i];
						$scope.loanObj = {};
						if (resp == undefined) {
							$state.go("upsandcomers.loanCustDtl");
						} else {
							var data = convertToArray(a[resp]);
							$scope.populateDynamicLoanForm(data);
						}
					};

					$scope.populateDynamicLoanForm = function(data) {
						$state
								.go("upsandcomers.loanAppDynamic")
								.then(
										function() {
											$('#dynamicForm').empty();
											$scope.fields = {};
											var len = data.length;
											var decidingParent = {};
											$
													.each(
															data,
															function(i, field) {
																$scope.fields[i] = field;
																var template = $($
																		.parseHTML($(
																				'#inputRowTemplate_'
																						+ field.type)
																				.html()));
																template
																		.find(
																				'label')
																		.append(
																				field.label);
																if (field.type == 'text') {
																	template
																			.find(
																					'label')
																			.attr(
																					"id",
																					"lblinput"
																							+ i);
																	template
																			.find(
																					'input')
																			.attr(
																					{
																						'data-ng-model' : 'loanObj.input'
																								+ i
																					});
																} else if (field.type == 'select') {
																	template
																			.find(
																					'label')
																			.attr(
																					"id",
																					"lblselect"
																							+ i);
																	template
																			.find(
																					'select')
																			.attr(
																					{
																						'data-ng-model' : 'loanObj.select'
																								+ i,
																						'data-ng-options' : 'key as label '
																								+ 'for (key, label) in '
																								+ 'fields["'
																								+ i
																								+ '"].options'

																					});
																	if (!jQuery
																			.isEmptyObject(field.child)) {
																		decidingParent = $scope.fields[i].child;
																	}
																}
																var sourceHtml = $(
																		'<div>')
																		.append(
																				template)
																		.html();
																var compiledHtml = $compile(
																		sourceHtml)
																		($scope);
																$(
																		'#dynamicForm')
																		.append(
																				compiledHtml);
																if (i == (len - 1)) {
																	var template = $($
																			.parseHTML($(
																					'#inputRowTemplate_btn')
																					.html()));
																	template
																			.find(
																					'a.blue-btn')
																			.attr(
																					{
																						'data-ng-click' : 'dynamicFormSubmit('
																								+ JSON
																										.stringify(decidingParent)
																								+ ','
																								+ i
																								+ ')'
																					});
																	var sourceHtml = $(
																			'<div>')
																			.append(
																					template)
																			.html();
																	var compiledHtml = $compile(
																			sourceHtml)
																			(
																					$scope);
																	$(
																			'#dynamicForm')
																			.append(
																					compiledHtml);
																}
															});
											$('#dynamicForm').trigger("create");
										});
					};

					$scope.loanApprovalClick = function() {
						nativeAlert(
								"Based on the above details provided bank to do a pre-check and get back to the customer/agent. Kindly note the reference Id LA1234 for further processing.",
								"Success", defaultBtnArray);
					};

					$scope.openLoanApp = function(loanType) {
						$scope.loanType = loanType;
						var loanJson = {
							"home" : [ {
								"type" : "select",
								"label" : "what is the primary purpose of the Loan?",
								"options" : {
									"build" : "Purchase or Build a home ?",
									"increaseLoan" : "Increase existing loan ?",
									"other" : "Other Purpose?"
								},
								"child" : {
									"build" : {
										"type" : "select",
										"label" : "Has the customer found a home to Purchase?",
										"options" : {
											"yes" : "Yes",
											"no" : "No"
										},
										"child" : {
											"yes" : [
													{
														"type" : "text",
														"label" : "How much would the customer like to borrow?",
														"child" : {}
													},
													{
														"type" : "text",
														"label" : "What is their preferred term? (Years/Months)",
														"child" : {}
													},
													{
														"type" : "text",
														"label" : "What is the purchase price (estimated) of the property? ",
														"child" : {}
													} ],
											"no" : [
													{
														"type" : "text",
														"label" : "How much would the customer wants to borrow?",
														"child" : {}
													},
													{
														"type" : "text",
														"label" : "What is their preferred term? (Years/Months)",
														"child" : {}
													},
													{
														"type" : "text",
														"label" : "How much is the customer planning to spend on the property?",
														"child" : {}
													} ]
										}
									},
									"increaseLoan" : [
											{
												"type" : "text",
												"label" : "What is the current loan's account number?",
												"child" : {}
											},
											{
												"type" : "text",
												"label" : "What is the current balance of customer's existing loan account ?",
												"child" : {}
											},
											{
												"type" : "text",
												"label" : "How much extra does the customer require?",
												"child" : {}
											},
											{
												"type" : "text",
												"label" : "What is their preferred term? (Years/Months)",
												"child" : {}
											} ],
									"other" : [
											{
												"type" : "text",
												"label" : "How much would the customer like to borrow?",
												"child" : {}
											},
											{
												"type" : "text",
												"label" : "What is their preferred term? (Years/Months)",
												"child" : {}
											} ]
								}
							} ],
							"auto" : [
									{
										"type" : "select",
										"label" : "What type of Vehicle does the customer wants to take loan on?",
										"options" : {
											"2W" : "2W",
											"3W" : "3W",
											"4W" : "4W",
											"LMW" : "LMW",
											"HMW" : "HMW"
										},
										"child" : {}
									},
									{
										"type" : "select",
										"label" : "Has the customer already purchased the Vehicle?",
										"options" : {
											"yes" : "Yes",
											"no" : "No"
										},
										"child" : {
											"yes" : {
												"type" : "select",
												"label" : "Is the vehicle new, or used?",
												"options" : {
													"new" : "New",
													"old" : "Old"
												},
												"child" : {
													"new" : [
															{
																"type" : "text",
																"label" : "How much would the customer wants to borrow?",
																"child" : {}
															},
															{
																"type" : "text",
																"label" : "What is their preferred term? (Years/Months)",
																"child" : {}
															},
															{
																"type" : "text",
																"label" : "What is the Purchase Price?",
																"child" : {}
															} ],
													"old" : [
															{
																"type" : "text",
																"label" : "How much would the customer wants to borrow?",
																"child" : {}
															},
															{
																"type" : "text",
																"label" : "What is their preferred term? (Years/Months)",
																"child" : {}
															},
															{
																"type" : "text",
																"label" : "What is the Purchase Price?",
																"child" : {}
															} ]
												}
											},
											"no" : [
													{
														"type" : "text",
														"label" : "How much would the customer wants to borrow?",
														"child" : {}
													},
													{
														"type" : "text",
														"label" : "What is their preferred term? (Years/Months)",
														"child" : {}
													},
													{
														"type" : "text",
														"label" : "How much is the customer planning to spend on the vehicle?",
														"child" : {}
													} ]
										}
									} ],
							"personal" : [
									{
										"type" : "text",
										"label" : "How much would the customer wants to borrow?",
										"child" : {}
									},
									{
										"type" : "text",
										"label" : "What is their preferred term? (Years/Months)",
										"child" : {}
									} ]
						};
						// var loanJson =
						// {"home":{},"auto":[{"type":"select","label":"What
						// type of Vehicle does the customer wants to take loan
						// on? (2W/3W/4W/LMV/HMV)","options":{"2W" : "2W","3W" :
						// "3W","4W" : "4W","LMW" : "LMW","HMW" :
						// "HMW"},"child":{}},{"type":"select","label":"Has the
						// customer already purchased the Vehicle?
						// (Yes/No)","options": {"yes" : "Yes", "no":
						// "No"},"child":{"yes":{"type":"select","label":"Is the
						// vehicle new, or used? (New/Old)","options": {"new" :
						// "New", "old":
						// "Old"},"child":[{"type":"text","label":"How much
						// would the customer wants to
						// borrow?","child":{}},{"type":"text","label":"What is
						// their preferred term?
						// (Years/Months)","child":{}},{"type":"text","label":"What
						// is the Purchase
						// Price?","child":{}}]},"no":[{"type":"text","label":"How
						// much would the customer wants to
						// borrow?","child":{}},{"type":"text","label":"What is
						// their preferred term?
						// (Years/Months)","child":{}},{"type":"text","label":"How
						// much is the customer planning to spend on the
						// vehicle?","child":{}}]}}],"personal":{}};
						// var data = "[{\"type\":\"text\",\"label\":\"How much
						// would the customer wants to
						// borrow?\",\"child\":{}},{\"type\":\"select\",\"label\":\"What
						// is their preferred term?
						// (Years/Months)\",\"child\":{}},{\"type\":\"text\",\"label\":\"How
						// much is the customer planning to spend on the
						// vehicle?\",\"child\":{}}]";
						var data = loanJson[loanType];
						$scope.populateDynamicLoanForm(data);
					};

					$scope.openLoanAppHome = function() {
						$scope.loanObj = {};
						$scope.loanObjComplete = {};
						this.navigateToPage('upsandcomers.loanApp');
					};

					function processAgentSubmit(obj) {
						$rootScope.submitted = true;
						var elemname = angular.element(
								document.querySelector("form")).attr("name");
						if (obj[elemname].$valid) {
							$state.go($state.current.name + "success");
						}
						$scope.prospectCount = getTotalCount("prospect");
						$scope.custConvertCount = getTotalCount("custConvert");
						$scope.custOnboardCount = getTotalCount("custOnboard");
					}

					$scope.processCaptureCustomer = function(inputObj) {
						var week = "agentWeek"
								+ Math.ceil(new Date().getDate() / 7);
						$localStorage[week].custOnboard = $localStorage[week].custOnboard + 1;
						$scope.custOnboardCount = getTotalCount("custOnboard");
						$scope.cifId = "CIF987261";
						$state.go($state.current.name + "success");
					}

					function getTotalCount(countType) {
						return $localStorage.agentWeek1[countType]
								+ $localStorage.agentWeek2[countType]
								+ $localStorage.agentWeek3[countType]
								+ $localStorage.agentWeek4[countType]
								+ $localStorage.agentWeek5[countType];
					}

					$scope.identificationScanCust = function(docDetailsObj) {
						if (docDetailsObj != undefined
								|| docDetailsObj.doctype != undefined
								|| docDetailsObj.docCode != undefined) {
							docDetailsObj.docStatus = "Pending";
							var documnt = angular.copy(docDetailsObj);
							$scope.docArrCust.push(documnt);
						}
					};

					$scope.deleteCustomers = function(index) {
						/*
						 * delete $scope.docArrCust[index];
						 * $scope.docArrCust.length = $scope.docArrCust.length -
						 * 1;
						 */
						$scope.docArrCust.splice(index, 1);
					}

					// Graphs - start
					var custdata = {
						"xData" : [ "Week1", "Week2", "Week3", "Week4", "Week5" ],
						"yData" : [ {
							"name" : "Prospects Captured",
							"data" : [ 21, 12, 3, 80, 50 ]
						}/*
							 * , { "name" : "Prospects Converted", "data" : [
							 * 12, 9, 3, 60, 34 ] }
							 */, {
							"name" : "Customers Onboarded",
							"data" : [ 28, 16, 71, 33, 50 ]
						} ]
					};

					$scope.custChartYData = custdata.yData;
					$scope.custChartXData = custdata.xData;

					var acctdata = {
						"xData" : [ "Week1", "Week2", "Week3", "Week4", "Week5" ],
						"yData" : [ {
							"name" : "Savings",
							"data" : [ 3, 30, 50, 21, 12 ]
						}, {
							"name" : "Deposits",
							"data" : [ 9, 13, 40, 22, 34 ]
						}, {
							"name" : "Loans",
							"data" : [ 31, 3, 28, 6, 50 ]
						} ]
					};

					$scope.acctChartYData = acctdata.yData;
					$scope.acctChartXData = acctdata.xData;
					// Graphs - end
					$scope.custIdSearchAgent = function(inputObj, id) {
						$scope.flagCust = id;
						$scope.inputObject = {};
						$scope.cType = 'Retail';
						$rootScope.popupContent = 'custIdPopup';
						openPopup("custIdPopup");
						$rootScope.flagSearcher = '';

					};
					$scope.searchForCif = function(searchType, inputObj) {
						inputObj.page = searchType;
						$rootScope.flagSearcher = 'C';
					}
					$scope.processCifContinueClick = function() {
						$scope.inputObj.cifId = "CIF20150128085721";
						$scope.inputObj.ciffId = "CIF20150128085721";
						closePopup("custIdPopup");
					};

					$scope.openCityCodePopup = function(fieldname) {
						$scope.inputObj.fieldWithPopup = fieldname;
						$("#cityIdPopup").popup("destroy");
						$("#cityIdPopup").show();
						$("#cityIdPopup").popup().popup("open");
					}

					$scope.closeCityCode = function(currentRow) {
						$scope.inputObj[$scope.inputObj.fieldWithPopup] = currentRow;
						closePopup("cityIdPopup");
					}

					$scope.openStateCodePopup = function(fieldname) {
						$scope.inputObj.fieldWithPopup = fieldname;
						$("#stateCodePopup").popup("destroy");
						$("#stateCodePopup").show();
						$("#stateCodePopup").popup().popup("open");
					}

					$scope.closeStateCode = function(currentRow) {
						$scope.inputObj[$scope.inputObj.fieldWithPopup] = currentRow;
						closePopup("stateCodePopup");
					}

					$scope.openCountryCodePopup = function(fieldname) {
						$scope.inputObj.fieldWithPopup = fieldname;
						$("#countryCodePopup").popup("destroy");
						$("#countryCodePopup").show();
						$("#countryCodePopup").popup().popup("open");
					}

					$scope.closeCountryCode = function(currentRow) {
						$scope.inputObj[$scope.inputObj.fieldWithPopup] = currentRow;
						closePopup("countryCodePopup");
					}
					$scope.selectCityCode = function() {
						$scope.inputObject.city = $scope.inputObject.row;
						this.swapPopup('custIdPopup');
					}
					$scope.minorCheck = function() {
						var diff = Math.floor((Date.parse(new Date()) - Date
								.parse($scope.inputObj.dob)) / 86400000);
						if (diff >= 6574) {
							$scope.inputObj.minorFlag = "N";
						} else {
							$scope.inputObj.minorFlag = "Y";
						}
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
						}, 0);
					}
					$scope.captureSign = function() {
						$scope.captureSignPopup = 'option';
						openPopup("captureSign");

					}

					$scope.captureCustImg = function(index) {
						if ((index) != undefined) {
							$scope.inputObj.index = index;
						} else {
							delete $scope.inputObj.index;
						}

						$scope.captureImgPopup = 'option';

						openPopup("captureCustImg");
					}

					$scope.closeViewPopup = function() {
						closePopup("viewImg");
					}

					$scope.openOptionSign = function(radioVal) {
						if (radioVal == "gallery1") {
							$scope.captureSignPopup = "gallery";
						} else if (radioVal == "signpad1") {
							$scope.captureSignPopup = "signpad";
						} else {
							$scope.capturedSign = "images/signature.jpg";
							$scope.captureSignPopup = 'saveloading';
							setTimeout(function() {
								$scope.captureSignPopup = 'savesuccess';
								$scope.$apply();
							}, 500);
						}
					}

					$scope.openLoadingSign = function() {
						/*
						 * if($scope.signRadioVal1 == "gallery1"){ var
						 * selected_file = $('#uploadSign').get(0).files[0];
						 * selected_file = window.URL
						 * .createObjectURL(selected_file); $scope.capturedSign =
						 * selected_file; } else {
						 */
						$scope.capturedSign = "images/signature.jpg";
						// }

						$scope.captureSignPopup = 'saveloading';
						setTimeout(function() {
							$scope.captureSignPopup = 'savesuccess';
							$scope.$apply();
						}, 500);
					}
					$scope.openOptionImg = function(radioVal) {
						$scope.signRadioVal2 = radioVal;
						if (radioVal == "gallery") {
							$scope.captureImgPopup = "gallery";
						} else {
							$scope.captureImgPopup = 'saveloading';
							setTimeout(function() {
								$scope.captureImgPopup = 'savesuccess';
								$scope.$apply();
							}, 500);
						}
					}

					$scope.openLoadingImg = function() {
						/*
						 * if($scope.signRadioVal2 == "gallery"){ var
						 * selected_file = $('#sign').get(0).files[0];
						 * selected_file = window.URL
						 * .createObjectURL(selected_file); $scope.capturedImg =
						 * selected_file; } else {
						 */
						$scope.capturedImg = "images/user-2.png";
						// }
						$scope.captureImgPopup = 'saveloading';
						setTimeout(function() {
							$scope.captureImgPopup = 'savesuccess';
							$scope.$apply();
						}, 500);
					}

					$scope.closePopup = function(id) {
						if (id == "captureSign") {
							$scope.signStatus = 'Uploaded';
						} else if (id == "captureCustImg") {
							if (($scope.inputObj.index) != undefined) {
								$scope.docArrCust[$scope.inputObj.index].docStatus = "Uploaded";
							} else {
								$scope.imgStatus = 'Uploaded';
							}

						}

						closePopup(id);
					}

					$scope.openPopup = function(id, imgtype) {
						if (imgtype == "custimg") {
							$scope.viewimg = "images/user-2.png";
						}
						if (imgtype == "docimg") {
							$scope.viewimg = "images/dl.jpg";
						}
						openPopup(id);
					}
				});
myApp.filter('titleCase', function() {
	return function(input) {
		input = input || '';
		return input.replace(/\w\S*/g, function(txt) {
			return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
		});
	};
})
