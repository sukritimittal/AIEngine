var AngularChart = angular.module('AngularChart', ['myApp']).directive('chart', function () {
    return {
        restrict:'E',
        template:'<div></div>',
        transclude:true,
        replace:true,
        scope: '=',
        link:function (scope, element, attrs) {
            console.log('oo',attrs,scope[attrs.formatter])
            var opt = {
                chart:{
                    renderTo:element[0],
                    type:'line',
                   /* width : 450, */
                    height : 200
                   /* marginRight:130,
                    marginBottom:40*/
                }, credits: {
                	enabled: false
                },
                title:{
                    text:attrs.title,
                    x:-20 //center
                },
                subtitle:{
                    text:attrs.subtitle,
                    x:-20
                },
              /*  xAxis:{
                    //categories:['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun','Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    tickInterval:1,
                    title:{
                        text:attrs.xname
                    }
                },*/
                plotOptions:{
                    lineWidth:0.5
                },yAxis:{
                    title:{
                        text:attrs.yname
                    }
                },
               /* yAxis:{
                    title:{
                        text:attrs.yname
                    },
                    tickInterval:(attrs.yinterval)?new Number(attrs.yinterval):null,
                    max:attrs.ymax,
                    min: attrs.ymin*/
//                    ,
//                    plotLines:[
//                        {
//                            value:0,
//                            width:1,
//                            color:'#808080'
//                        }
//                    ]
                // },
                /*tooltip:{
                    formatter:scope[attrs.formatter]||function () {
                        return '<b>' + this.y + '</b>'
                    }
                },*/
                legend:{
                    layout:'vertical',
                    align:'right',
                    verticalAlign:'top',
                    x:-10,
                    y:100,
                    borderWidth:0
                },
                series:[
                    {
                        name:'Tokyo',
                        data:[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
                    }
                ],
                colors: [
                         '#019fde',
                         '#ed7d31',
                         '#a3a3a3',
                         '#ffbe00'
                     ]
            }


            //Update when charts data changes
            scope.$watch(function (scope) {
                return JSON.stringify({
                    xAxis:{
                        categories:scope[attrs.xdata]
                        },
                    series:scope[attrs.ydata]
                });
            }, function (news) {
                console.log('ola')
//                if (!attrs) return;
                news = JSON.parse(news)
                if (!news.series)return;
                angular.extend(opt,news)
                console.log('opt.xAxis.title.text',opt)
                



                var chart = new Highcharts.Chart(opt);
            });
        }
    }

});

AngularChart.directive('tellerbarchart', function ($filter) {
    return {
        restrict:'E',
        template:'<div></div>',
        transclude:true,
        replace:true,
        scope: '=',
        link:function (scope, element, attrs) {
        	console.log("scope"+scope);
            console.log('oo',attrs,scope[attrs.formatter])
            var opt = {
                chart:{
                    renderTo:element[0],
                    type:'column',
                    height : 200,
                    //width: 400
                }, credits: {
                	enabled: false
                },
                title:{
                    text:attrs.title,
                    x:-20 //center
                },
                subtitle:{
                    text:attrs.subtitle,
                    x:-20
                },
               /* xAxis:{
                    //categories:['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun','Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    tickInterval:1,
                    title:{
                        text:attrs.xname
                    }
                },*/
                yAxis:{
                	allowDecimals: false,
                	 title:{
                         text:attrs.yname
                     }
                },
                /*tooltip:{
                    formatter:scope[attrs.formatter]||function () {
                        return '<b>' + this.y + '</b>'
                    }
                },*/
                legend:{
                    /*layout:'vertical',
                    align:'right',
                    verticalAlign:'top',
                    x:-10,
                    y:100,
                    borderWidth:0,
                	  layout:'vertical',
                    align:'center',
                    verticalAlign:'bottom',
                    x:-10,
                    y:-10,
                    borderWidth:0, */labelFormatter: function() {
                        var total = 0;
                        for(var i=this.yData.length; i--;) { total += this.yData[i]; };
                        return this.name + ': USD ' + $filter('currencyFormat')(total, 'USD');
                     }
                },
                colors: [
                         '#019fde',
                         '#ed7d31',
                         '#a3a3a3',
                         '#ffbe00'
                     ]
            }
            //Update when charts data changes
            scope.$watch(function (scope) {
                return JSON.stringify({
                    xAxis:{
                        categories:scope[attrs.xdata]
                        },
                    series:scope[attrs.ydata]
                });
            }, function (news) {
                console.log('ola')
//                if (!attrs) return;
                news = JSON.parse(news)
                if (!news.series)return;
                angular.extend(opt,news)
                console.log('opt.xAxis.title.text',opt)
                



                var chart = new Highcharts.Chart(opt);
            });
        }
    }

});

AngularChart.directive('barchart', function () {
    return {
        restrict:'E',
        template:'<div></div>',
        transclude:true,
        replace:true,
        scope: '=',
        link:function (scope, element, attrs) {
        	console.log("scope"+scope);
            console.log('oo',attrs,scope[attrs.formatter])
            var opt = {
                chart:{
                    renderTo:element[0],
                    type:'column',
                    height : 200,
                    //width: 400
                }, credits: {
                	enabled: false
                },
                title:{
                    text:attrs.title,
                    x:-20 //center
                },
                subtitle:{
                    text:attrs.subtitle,
                    x:-20
                },
               /* xAxis:{
                    //categories:['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun','Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    tickInterval:1,
                    title:{
                        text:attrs.xname
                    }
                },*/
                yAxis:{
                	allowDecimals: false,
                	 title:{
                         text:attrs.yname
                     }
                },
                /*tooltip:{
                    formatter:scope[attrs.formatter]||function () {
                        return '<b>' + this.y + '</b>'
                    }
                },*/
                legend:{
                    layout:'vertical',
                    align:'right',
                    verticalAlign:'top',
                    x:-10,
                    y:100,
                    borderWidth:0,
                	 /* layout:'vertical',*/
                   /* align:'center',
                    verticalAlign:'bottom',
                    x:-10,
                    y:-10,
                    borderWidth:0,*/ /*labelFormatter: function() {
                        var total = 0;
                        for(var i=this.yData.length; i--;) { total += this.yData[i]; };
                        return this.name + ': USD ' + total;
                     }*/
                },
                colors: [
                         '#019fde',
                         '#ed7d31',
                         '#a3a3a3',
                         '#ffbe00'
                     ]
            }
            //Update when charts data changes
            scope.$watch(function (scope) {
                return JSON.stringify({
                    xAxis:{
                        categories:scope[attrs.xdata]
                        },
                    series:scope[attrs.ydata]
                });
            }, function (news) {
                console.log('ola')
//                if (!attrs) return;
                news = JSON.parse(news)
                if (!news.series)return;
                angular.extend(opt,news)
                console.log('opt.xAxis.title.text',opt)
                



                var chart = new Highcharts.Chart(opt);
            });
        }
    }

});

AngularChart.directive('stackedchart', function () {
    return {
        restrict:'E',
        template:'<div></div>',
        transclude:true,
        replace:true,
        scope: '=',
        link:function (scope, element, attrs) {
        	console.log("scope"+scope);
            var opt = {
                chart:{
                    renderTo:element[0],
                    type:'column',
                    height : 200
                }, credits: {
                	enabled: false
                },
                title:{
                    text:attrs.title,
                    x:-20 //center
                },
                subtitle:{
                    text:attrs.subtitle,
                    x:-20
                },
                plotOptions:{
               	 series: {
                        stacking: 'normal'
                    }
               },
                yAxis:{
                	allowDecimals: false,
                	 title:{
                         text:attrs.yname
                     }
                },
               /* legend:{
                	layout:'vertical',
                    align:'right',
                    verticalAlign:'top',
                    x:-10,
                    y:100,
                    borderWidth:0
                },*/
                colors: [
                         '#019fde',
                         '#ed7d31',
                         '#a3a3a3',
                         '#ffbe00'
                     ]
            }
            //Update when charts data changes
            scope.$watch(function (scope) {
                return JSON.stringify({
                    xAxis:{
                        categories:scope[attrs.xdata]
                        },
                    series:scope[attrs.ydata]
                });
            }, function (news) {
                console.log('ola')
                news = JSON.parse(news)
                if (!news.series)return;
                angular.extend(opt,news)
                var chart = new Highcharts.Chart(opt);
            });
        }
    }

});