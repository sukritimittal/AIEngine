var targetDevice = "web";
var realuserid = "";
var realusersessionid = "";
var tellerCurr = "USD";
var locationLang =  "nonUS";
function invokeMBProcedure(jsonObj, serviceSuccessRespHandler,
		customServiceFailureRespHandler) {
	printLogs("common.js::invokeMBProcedure::" + JSON.stringify(jsonObj));
	var serviceFailureRespHandler = failureResponseHandler;
	if (checkEmpty(customServiceFailureRespHandler)) {
		serviceFailureRespHandler = customServiceFailureRespHandler;
	}
	jsonObj.realuserid=realuserid;
	jsonObj.realusersessionid=realusersessionid;
	execService(jsonObj, null, serviceSuccessRespHandler);
}
function invokeNoRealMBProcedure(jsonObj, serviceSuccessRespHandler,
		customServiceFailureRespHandler) {
	printLogs("common.js::invokeMBProcedure::" + JSON.stringify(jsonObj));
	var serviceFailureRespHandler = failureResponseHandler;
	if (checkEmpty(customServiceFailureRespHandler)) {
		serviceFailureRespHandler = customServiceFailureRespHandler;
	}
	jsonObj.realuserid = "";
	jsonObj.realusersessionid = "";
	execService(jsonObj, null, serviceSuccessRespHandler);
}
function invokeTellerProcedureNoReal(jsonObj, serviceSuccessRespHandler,
		customServiceFailureRespHandler, page) {
	printLogs("common.js::invokeTellerProcedure::" + JSON.stringify(jsonObj));
	showLoadingTransaction();
	var serviceFailureRespHandler = failureResponseHandler;
	if (checkEmpty(customServiceFailureRespHandler)) {
		serviceFailureRespHandler = customServiceFailureRespHandler;
	}
	var successObj = {
			"page" : jsonObj.page,
			"amt" : jsonObj.transactionAmount,
			"hrs" : new Date().getHours()
		};
	if(checkEmpty(page)){
		successObj.page = page;
	}
	var successObj = {
		"page" : jsonObj.page,
		"amt" : jsonObj.transactionAmount,
		"hrs" : new Date().getHours()
	};
	var obj = {
		"successObj" : successObj
	};
	jsonObj.realuserid="";
	jsonObj.realusersessionid="";
	execService(jsonObj, obj, serviceSuccessRespHandler);
}

function invokeTellerProcedure(jsonObj, serviceSuccessRespHandler,
		customServiceFailureRespHandler, page) {
	printLogs("common.js::invokeTellerProcedure::" + JSON.stringify(jsonObj));
	showLoadingTransaction();
	var serviceFailureRespHandler = failureResponseHandler;
	if (checkEmpty(customServiceFailureRespHandler)) {
		serviceFailureRespHandler = customServiceFailureRespHandler;
	}
	var successObj = {
			"page" : jsonObj.page,
			"amt" : jsonObj.transactionAmount,
			"hrs" : new Date().getHours()
		};
	if(checkEmpty(page)){
		successObj.page = page;
	}
	var successObj = {
		"page" : jsonObj.page,
		"amt" : jsonObj.transactionAmount,
		"hrs" : new Date().getHours()
	};
	var obj = {
		"successObj" : successObj
	};
	jsonObj.realuserid=realuserid;
	jsonObj.realusersessionid=realusersessionid;
	execService(jsonObj, obj, serviceSuccessRespHandler);
}

function fail() {
	alert("S");
}

function invokeTellerProcedureWithObj(jsonObj, successObj,
		serviceSuccessRespHandler, customServiceFailureRespHandler) {
	var serviceFailureRespHandler = failureResponseHandler;
	if (checkEmpty(customServiceFailureRespHandler)) {
		serviceFailureRespHandler = customServiceFailureRespHandler;
	}
	var obj = {
		"successObj" : successObj
	};
	jsonObj.realuserid=realuserid;
	jsonObj.realusersessionid=realusersessionid;
	execService(jsonObj, obj, serviceSuccessRespHandler);
}

function invokeSearchProcedure(jsonStr, searchType, serviceSuccessRespHandler,
		customServiceFailureRespHandler) {
	printLogs("common.js::invokeSearchProcedure::" + JSON.stringify(jsonStr));
	var serviceFailureRespHandler = failureResponseHandler;
	if (checkEmpty(customServiceFailureRespHandler)) {
		serviceFailureRespHandler = customServiceFailureRespHandler;
	}
	var obj = {
		"searchType" : searchType
	};
	jsonStr.realuserid="";
	jsonStr.realusersessionid="";
	execService(jsonStr, obj, serviceSuccessRespHandler);
}
function failureResponseHandler(data) {
	hideLoadingTransaction();
	errorScenarioAlert();
}
function replaceAll(str, find, replace) {
	return str.replace(new RegExp(find, 'g'), replace);
}
function isServiceResponseValid(result) {
	printLogs("common.js::isServiceResponseValid");
	/*
	 * if (200 == result.status && result.invocationResult.isSuccessful &&
	 * isObjectValidAndNotEmpty(result.invocationResult.serviceStatus)) {
	 */
	if (isObjectValidAndNotEmpty(result)
			&& isObjectValidAndNotEmpty(result.invocationResult)) {
		return true;
	}
	return false;
}

function isObjectValidAndNotEmpty(obj) {
	printLogs("common.js::isObjectValidAndNotEmpty");
	var isValid = false;
	if (!$.isEmptyObject(obj)) {
		isValid = true;
	}
	return isValid;
}

function customerDetailsCheck() {
	printLogs("common.js::isServiceResponseValid");
	nativeAlert("Please fill in the customer details.", "Warning",
			defaultBtnArray);
}

function selectRadio(id) {
	$(".radio_grp").not("#" + id).hide();
	$("#" + id).show();
}

// TODO : remove later ..just for functionalities under development
function notAvailable() {
	printLogs("common.js::notAvailable");
	nativeAlert("This functionality is under development.", "Alert",
			defaultBtnArray);
}

function nativeAlert(message, alertType, buttonArray) {
	swal(alertType, message);
}

function animatePage() {
	printLogs("common.js::animatePage");
	$("#popuppage").animate({
		marginTop : '0',
		opacity : '1'
	}, {
		duration : 500,
		queue : false
	});
}

function openPopup(id) {
	$("#" + id).popup().popup("destroy");
	$("#" + id).show();
	$("#" + id).popup().popup("open");
}

function closePopup(id) {
	$("#" + id).popup().popup("destroy");
	$("#" + id).popup().popup("close");
}

function convertToArray(json) {
	if (checkEmpty(json)) {
		if (json[0] == undefined) {
			var arr = [];
			arr.push(json);
			return arr;
		} else {
			return json;
		}
	}
}

function showLoadingTransaction() {
	$('.data-loading').addClass("no-display");
	$(".loading-start").animate({
		right : '0',
		opacity : '1'
	});
	$('#load').removeClass("no-display");
}

function hideLoadingTransaction() {
	$('.data-loading').removeClass("no-display");
	$(".loading-start").addClass("no-display");
}

function checkEmpty(val) {
	return (val != null && val != undefined && val != "");
}

function isErrorCode(servStatus) {
	if (checkEmpty(servStatus)) {
		return (servStatus.serviceStatusCode == SERVICE_RESPONSE_CODE_ERROR);
	}
}

function showServiceErrorMsg(servStatus) {
	if (checkEmpty(servStatus.serviceStatusDesc)) {
		nativeAlert(servStatus.serviceStatusDesc, "Error", defaultBtnArray);
	}
}

function printLogs(message) {
	console.log(message);
}

function getAndroidSpecificResp(data) {
	if (targetDevice == "android") {
		return JSON.parse(data);
	} else {
		return data;
	}
}

function refreshRadio() {
	setTimeout(function() {
		$('input[type="radio"]:not(:checked)').checkboxradio("refresh");
		$("input:checked").checkboxradio("refresh");
	}, 0);
}

Date.prototype.addDays= function(d){ this.setDate(this.getDate() + d); return this; };

var MB_COMMON_ADAPTOR = 'commonAdapter';
var MB_COMMON_ADPTR_DEFAULT_PROCEDURE = 'processRequest';
var SERVICE_RESPONSE_CODE_ERROR = "1";
var defaultBtnArray = [ {
	text : "OK"
} ];
var menus = [];