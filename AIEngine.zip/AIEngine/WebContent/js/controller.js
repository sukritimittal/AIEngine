/*var myApp = angular.module('myApp', [ 'ui.router' ]).controller(
		"mainCtrl",
		function($scope, $state, $timeout) {
			$scope.uiRouterState = $state;
			$scope.customer = "new";
			$scope.menu = "T";
			$scope.labelName = "Account Number";
			$scope.tokenTable = [];
			$scope.username = "User";
			 $scope.nextField = '1';
			$scope.waveSrc = "images/sound.gif";
			$scope.assistText = "Are you an existing customer?";



			$scope.counter = 0;
			$scope.changeClass = function() {
				$scope.assistText = "Please enter your account number.";
				$scope.waveSrc = "images/sound.gif";
				$scope.customer = 'existing';
			}
			
			$scope.changeMenu = function(val) {
				$scope.menu = val;
			}
			$scope.goNextft = function(val) {
				$scope.nextField = val;
				if(val =='2'){
					 $scope.assistText = "Please enter the transfer amount.";
				}
			}

			$scope.changeClassName = function() {
				$scope.customer = 'new';
			}

			$scope.changeLabelName = function(id) {
				var value = $("#" + id).text();
				$scope.labelName = value;
				$(".login-selected").removeClass();
				$("#" + id).addClass("login-selected");
				$('.ui-popup').popup('close');
			}

			$scope.navigate = function(page) {
				$state.go("login." + page);
			}
			$scope.accNumberSubmit = function(accnum) {
				$scope.username = accnum;
				$scope.counter = 0;
				$scope.assistText = "What kind of transaction would you like to do?";
			}

			$scope.submitToken = function(alertType, message) {
				// swal(alertType, message);
				swal({
					title : alertType,
					text : message
				}, function(isConfirm) {
					$state.go("login").then(function() {
						$scope.username = "User";
						$scope.tokenTable = [];
						$scope.customer = "new";
						$scope.counter = 0;
					});

				});

			}

			$scope.addToTokenList = function(page, amount) {
				var obj = {
					"page" : page,
					"amount" : amount
				}
				$scope.tokenTable.push(obj);
				$state.go("login.menu");
				$scope.counter = $scope.counter + 1;
			}
			$scope.deleteFromTokenList = function(index) {
				$scope.tokenTable.splice(index, 1);
				$scope.counter = $scope.counter + 1;
			}

			$scope.goBack = function() {
				if ($state.current.name != $state.current.params.previousState) {
					if($state.current.name == 'login.fundtransfer' && $scope.nextField == '2'){
						$scope.nextField = '1';
					}
					else{
					$state.go($state.current.params.previousState).then(
							function() {

								if ($state.current.name == 'login'
										|| $state.current.name == 'index')
									$scope.customer = 'new';
							});

				} 
				}else {
					$scope.customer = 'new';
				}
			}

			$scope.goHome = function() {
				if ($state.current.name != 'login'
						&& $state.current.name != 'index') {
					$state.go("index").then(
							function() {

								if ($state.current.name == 'login'
										|| $state.current.name == 'index')
									$scope.customer = 'new';
							});
				} else {
					$scope.customer = 'new';
				}

			}

			$scope.newCustClick = function() {
				$state.go("login.menu").then(function() {
					$scope.username = "User";
					$scope.assistText = "What kind of transaction would you like to do?";
					$scope.counter = 0;
				});
			}
			
			$scope.$on('$stateChangeStart', function(event, toState,
					toParams, fromState, fromParams) {
				if(toState.name == 'login.menu'){
					$scope.menu = "T";
					$scope.assistText = "Please select the type of request, you wish to perform.";
				}
				else if(toState.name == 'login' && $scope.customer == "new"){
					$scope.assistText = "Are you an existing customer?";
				}
				else if(toState.name == 'login' && $scope.customer == "existing"){
					$scope.assistText = "Please enter your account number.";
				}
				else if(toState.name == 'login.deposit'){
					$scope.assistText = "Please enter deposit amount.";
				}
				else if(toState.name == 'login.withdrawal'){
					$scope.assistText = "Please enter withdrawal amount.";
				}
				else if(toState.name == 'login.tokentable'){
					$scope.assistText = "Click on submit to generate token.";
				}
				else if(toState.name == 'login.fundtransfer'){
					 $scope.nextField = '1';
					 $scope.assistText = "Please enter account number.";
				}
				
				
				
			});

		});

myApp.config(function($stateProvider) {
	$stateProvider.state('index', {
		url : "",
		templateUrl : "login.html",
		params : {
			previousState : 'index',
		}
	}).state('login', {
		templateUrl : "login.html",
		params : {
			previousState : 'login',
		}
	}).state('login.menu', {
		views : {
			"innerContainer" : {
				templateUrl : "menu.html"
			}
		},
		params : {
			previousState : 'login',
		}

	}).state('login.withdrawal', {
		views : {
			"innerContainer" : {
				templateUrl : "withdrawal.html"
			}
		},
		params : {
			previousState : 'login.menu',
		}
	}).state('login.deposit', {
		views : {
			"innerContainer" : {
				templateUrl : "deposit.html"
			}
		},
		params : {
			previousState : 'login.menu',
		}
	}).state('login.fundtransfer', {
		views : {
			"innerContainer" : {
				templateUrl : "fundtransfer.html"
			}
		},
		params : {
			previousState : 'login.menu',
		}
	}).state('login.tokentable', {
		views : {
			"innerContainer" : {
				templateUrl : "tokentable.html"
			}
		},
		params : {
			previousState : 'login.menu',
		}
	}).state('login.newmenu', {
		views : {
			"innerContainer" : {
				templateUrl : "newmenu.html"
			}
		},
		params : {
			previousState : 'login',
		}
	});
});

myApp.directive('jqm', function() {
	return {
		link : function(scope, elm, attr) {
			elm.trigger('create');
		}
	};
});

function openPopup(id) {

	$("#" + id).show();
	$("#" + id).popup().popup("open", {
		positionTo : '#acc-num'
	});
}
myApp.filter('currencyFormat',
		function($filter) {
			return function(input, currVal) {
				if (!isNaN(input)) {
					if (currVal == "USD") {
						return $filter('number')(input, 2);
					} else {
						var result = input.toString().split('.');

						var lastThree = result[0]
								.substring(result[0].length - 3);
						var otherNumbers = result[0].substring(0,
								result[0].length - 3);
						if (otherNumbers != '')
							lastThree = ',' + lastThree;
						var output = otherNumbers.replace(
								/\B(?=(\d{2})+(?!\d))/g, ",")
								+ lastThree;

						if (result.length > 1) {
							output += "." + result[1];
						}

						return output;
					}
				}
			}
		});*/

var myApp = angular.module('myApp', []);
myApp.controller("mainCtrl", function($scope, $http) {
	$scope.headingSubtext = "";
	insertChat("you", "Hi, How can I help you?");

	$scope.keyUp = function(e) {
		if (e.which == 13) {

			var text = $(".mytext").val();
			if (text !== "") {
				insertChat("me", text);
				$(".mytext").val('');

				// service invoke
				var inputObj = {
					query : text,
					page : 'chatbot'
				};
				$scope.apiCall(inputObj);
			}
		}
	};

	$scope.apiCall = function(inputObj) {
		$scope.headingSubtext = "is typing...";
		$http({
			method : "GET",
			params : inputObj,
			url : "http://localhost:7070/AIEngine/AIEngine"

		}).then(function mySuccess(response) {
			$scope.headingSubtext = "";
			insertChat("you", response.data.speech);
			if (response.data.action != null) {
				alert(response.data.action);
			}
		}, function myError(response) {
			$scope.headingSubtext = "";
			$scope.myWelcome = response.statusText;
		});
	}

});

var me = {};
me.avatar = "images/user.png";

var you = {};
you.avatar = "images/robot.png";

function formatAMPM(date) {
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var ampm = hours >= 12 ? 'PM' : 'AM';
	hours = hours % 12;
	hours = hours ? hours : 12; // the hour '0' should be '12'
	minutes = minutes < 10 ? '0' + minutes : minutes;
	var strTime = hours + ':' + minutes + ' ' + ampm;
	return strTime;
}

// -- No use time. It is a javaScript effect.
function insertChat(who, text, time) {
	$(".convo-list").animate({
		scrollTop : 20000
	});
	time = 0;
	var control = "";
	var date = formatAMPM(new Date());

	if (who == "me") {

		control = '<li style="width:100%">'
				+ '<div class="msj macro">'
				+ '<div class="avatar"><img class="img-circle" style="width:100%;" src="'
				+ me.avatar + '" /></div>' + '<div class="text text-l">'
				+ '<p>' + text + '</p>' + '<p><small>' + date + '</small></p>'
				+ '</div>' + '</div>' + '</li>';
	} else {
		control = '<li style="width:100%;">'
				+ '<div class="msj-rta macro">'
				+ '<div class="text text-r">'
				+ '<p>'
				+ text
				+ '</p>'
				+ '<p><small>'
				+ date
				+ '</small></p>'
				+ '</div>'
				+ '<div class="avatar" style="padding:0px 0px 0px 10px !important"><img class="img-circle" style="width:100%;" src="'
				+ you.avatar + '" /></div>' + '</li>';
	}
	setTimeout(function() {
		$("ul").append(control);
		$("ul").scrollTop()
	}, time);

}

function resetChat() {
	$("ul").empty();
}
