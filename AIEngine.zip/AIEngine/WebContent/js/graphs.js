//********************************************************TELLER***********************************************
function getTellerXAxis(){
	return [ "09:00AM", "10:00AM", "11:00AM", "12:00PM",
				"01:00PM", "02:00PM", "03:00PM", "04:00PM",
				"05:00PM", "06:00PM" ];
	/*return [ "08:00AM", "10:00AM", "12:00PM",
				"02:00PM", "04:00PM" ];*/
}

function getCashTranYAxis(localStorage){
	var t9 = localStorage.t9;
	var t10 = localStorage.t10;
	var t11 = localStorage.t11;
	var t12 = localStorage.t12;
	var t13 = localStorage.t13;
	var t14 = localStorage.t14;
	var t15 = localStorage.t15;
	var t16 = localStorage.t16;
	var t17 = localStorage.t17;
	var t18= localStorage.t18;
	return [
		{
			"name" : "Cash Deposit",
			"data" : [
					getTransactAmt(t9.cashDeposit),
					getTransactAmt(t10.cashDeposit),
					getTransactAmt(t11.cashDeposit),
					getTransactAmt(t12.cashDeposit),
					getTransactAmt(t13.cashDeposit),
					getTransactAmt(t14.cashDeposit),
					getTransactAmt(t15.cashDeposit),
					getTransactAmt(t16.cashDeposit),
					getTransactAmt(t17.cashDeposit),
					getTransactAmt(t18.cashDeposit) ]
		},
		{
			"name" : "Cash Withdrawal",
			"data" : [
					getTransactAmt(t9.cashWithdrawal),
					getTransactAmt(t10.cashWithdrawal),
					getTransactAmt(t11.cashWithdrawal),
					getTransactAmt(t12.cashWithdrawal),
					getTransactAmt(t13.cashWithdrawal),
					getTransactAmt(t14.cashWithdrawal),
					getTransactAmt(t15.cashWithdrawal),
					getTransactAmt(t16.cashWithdrawal),
					getTransactAmt(t17.cashWithdrawal),
					getTransactAmt(t18.cashWithdrawal) ]
		} ];
}

function getCategoryWiseTranYAxis(localStorage){
	var t9 = localStorage.t9;
	var t10 = localStorage.t10;
	var t11 = localStorage.t11;
	var t12 = localStorage.t12;
	var t13 = localStorage.t13;
	var t14 = localStorage.t14;
	var t15 = localStorage.t15;
	var t16 = localStorage.t16;
	var t17 = localStorage.t17;
	var t18= localStorage.t18;
	return [
			{
				"name" : "Cash Deposit",
				"data" : [
						getNoOfTransact(t9.cashDeposit),
						getNoOfTransact(t10.cashDeposit),
						getNoOfTransact(t11.cashDeposit),
						getNoOfTransact(t12.cashDeposit),
						getNoOfTransact(t13.cashDeposit),
						getNoOfTransact(t14.cashDeposit),
						getNoOfTransact(t15.cashDeposit),
						getNoOfTransact(t16.cashDeposit),
						getNoOfTransact(t17.cashDeposit),
						getNoOfTransact(t18.cashDeposit) ]
			},
			{
				"name" : "Cash Withdrawal",
				"data" : [
						getNoOfTransact(t9.cashWithdrawal),
						getNoOfTransact(t10.cashWithdrawal),
						getNoOfTransact(t11.cashWithdrawal),
						getNoOfTransact(t12.cashWithdrawal),
						getNoOfTransact(t13.cashWithdrawal),
						getNoOfTransact(t14.cashWithdrawal),
						getNoOfTransact(t15.cashWithdrawal),
						getNoOfTransact(t16.cashWithdrawal),
						getNoOfTransact(t17.cashWithdrawal),
						getNoOfTransact(t18.cashWithdrawal) ]
			},
			{
				"name" : "Fund Transfer",
				"data" : [
						getNoOfTransact(t9.fundTransfer),
						getNoOfTransact(t10.fundTransfer),
						getNoOfTransact(t11.fundTransfer),
						getNoOfTransact(t12.fundTransfer),
						getNoOfTransact(t13.fundTransfer),
						getNoOfTransact(t14.fundTransfer),
						getNoOfTransact(t15.fundTransfer),
						getNoOfTransact(t16.fundTransfer),
						getNoOfTransact(t17.fundTransfer),
						getNoOfTransact(t18.fundTransfer) ]
			},
			{
				"name" : "Payment Order",
				"data" : [
						getNoOfTransact(t9.paymentOrder),
						getNoOfTransact(t10.paymentOrder),
						getNoOfTransact(t11.paymentOrder),
						getNoOfTransact(t12.paymentOrder),
						getNoOfTransact(t13.paymentOrder),
						getNoOfTransact(t14.paymentOrder),
						getNoOfTransact(t15.paymentOrder),
						getNoOfTransact(t16.paymentOrder),
						getNoOfTransact(t17.paymentOrder),
						getNoOfTransact(t18.paymentOrder) ]
			} ];
}

function getNoOfTransact(val){
	return parseInt(val.noOfTransact);
}

function getTransactAmt(val){
	return parseInt(val.transactAmt);
}

//*****************************************************AGENT*************************************************

function getAgentXAxis(){
	return [ "Week1", "Week2", "Week3", "Week4", "Week5" ];
}

function getNewCustomersYAxis(localStorage){
	var week1 = localStorage.agentWeek1;
	var week2 = localStorage.agentWeek2;
	var week3 = localStorage.agentWeek3;
	var week4 = localStorage.agentWeek4;
	var week5 = localStorage.agentWeek5;
	return [
			{
				"name" : "Prospects Captured",
				"data" : [
						parseInt(week1.prospect),
						parseInt(week2.prospect),
						parseInt(week3.prospect),
						parseInt(week4.prospect),
						parseInt(week5.prospect) ]
			},
			/*{
				"name" : "Prospects Converted",
				"data" : [
						parseInt(week5.custConvert),
						parseInt(week4.custConvert),
						parseInt(week3.custConvert),
						parseInt(week2.custConvert),
						parseInt(week1.custConvert) ]
			},*/
			{
				"name" : "Customers Onboarded",
				"data" : [
						parseInt(week1.custOnboard),
						parseInt(week2.custOnboard),
						parseInt(week3.custOnboard),
						parseInt(week4.custOnboard),
						parseInt(week5.custOnboard) ]
			} ];
}
function getNewAccountsYAxis(localStorage){
	var week1 = localStorage.agentWeek1;
	var week2 = localStorage.agentWeek2;
	var week3 = localStorage.agentWeek3;
	var week4 = localStorage.agentWeek4;
	var week5 = localStorage.agentWeek5;
	return [
			{
				"name" : "Savings",
				"data" : [
						parseInt(week1.savingAccts),
						parseInt(week2.savingAccts),
						parseInt(week3.savingAccts),
						parseInt(week4.savingAccts),
						parseInt(week5.savingAccts) ]
			},
			{
				"name" : "Deposits",
				"data" : [
						parseInt(week1.recurrAccts) + parseInt(week1.fixedAccts),
						parseInt(week2.recurrAccts) + parseInt(week2.fixedAccts),
						parseInt(week3.recurrAccts) + parseInt(week3.fixedAccts),
						parseInt(week4.recurrAccts) + parseInt(week4.fixedAccts),
						parseInt(week5.recurrAccts) + parseInt(week5.fixedAccts) ]
			},
			{
				"name" : "Loans",
				"data" : [
						parseInt(week1.loanApps),
						parseInt(week2.loanApps),
						parseInt(week3.loanApps),
						parseInt(week4.loanApps),
						parseInt(week5.loanApps) ]
			} ];
}
