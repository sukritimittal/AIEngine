var myApp = angular.module('myApp',
		[ 'ngMessages', 'ui.router', 'ngStorage', 'AngularChart' ]).controller(
		"mainCtrl",
		function($scope, $rootScope, $state, $filter, Data, $timeout,
				$localStorage) {
			$scope.location = locationLang;
			$scope.inputObj = {};
			$scope.Data = Data;
			$scope.Date = new Date();
			$scope.LastLoginDate = $scope.Date.setHours($scope.Date.getHours() - 2); 
			$rootScope.submitted = false;
			$scope.txnStatus = getTxnStatus();
			$scope.txnType = getTxnType();
			$localStorage = $localStorage.$default({
				t9 : initDayString(),
				t10 : initDayString(),
				t11 : initDayString(),
				t12 : initDayString(),
				t13 : initDayString(),
				t14 : initDayString(),
				t15 : initDayString(),
				t16 : initDayString(),
				t17 : initDayString(),
				t18 : initDayString(),
				agentObj : getAgentObj(),
				agentWeek1 : initAgentCount(),
				agentWeek2 : initAgentCount(),
				agentWeek3 : initAgentCount(),
				agentWeek4 : initAgentCount(),
				agentWeek5 : initAgentCount()
			});
			$scope.pendingApproval = 9;
			$scope.ctrPage = "1";
			$scope.ctrInputObj = {};
			$scope.authSuccessArr = [];

			$scope.interacted = function(field) {
				if (field != undefined) {
					return $rootScope.submitted || field.$dirty;
				} else {
					return $rootScope.submitted;
				}
			};

			$scope.loginClick = function(data) {
				$rootScope.submitted = true;

				// var button =
				// angular.element(document.querySelector("#" +
				// data.target.id));
				var elemname = angular.element(document.querySelector("form"))
						.attr("name");
				if (this[elemname].$valid) {
					loginToApp();
				}
			};

			$scope.processLogout = function() {
				$state.go("login").then(function() {
					if ($scope.role == "T") {
						delete $scope.viewedCustDtls;
						delete $scope.viewDtl;
						$scope.Data = {};
						$scope.authSuccessArr = [];
					}
					delete $scope.role;
				});
			}

			// to navigate to any child page from back/repeat
			// transaction btn
			$scope.navigateToPage = function(page, callbackFn) {
				$state.go(page).then(function() {
					animatePage();
					if (callbackFn) {
						callbackFn();
					}
				});
			}

			// reload dashboard
			$scope.reloadDashboard = function() {
				$state.go("dashboard", {}, {
					reload : true
				}).then(function() {
					delete $scope.viewedCustDtls;
					delete $scope.viewDtl;
					$scope.Data = {};
					$scope.authSuccessArr = [];
				});
			}
			// reload dashboard
			$scope.cancelClick = function() {
				$state.go("dashboard");
			}
			$scope.reloadRmDashboard = function() {
				$state.go("rmDashboard", {}, {
					reload : true
				}).then(function() {
					delete $scope.viewedCustDtls;
					delete $scope.viewDtl;
					$scope.Data = {};
				});
			}

			$scope.reloadAgentDashboard = function() {
				$state.go("upsandcomers", {}, {
					reload : true
				});
			}

			function verifyLoginUser() {
				var user = $("#userId").val();
				/*
				 * if (user == "teller" && $("#password").val() == "admin"){
				 * return true; } else
				 */if (user == "admin" || user == "teller1" || user == "teller" || user == "Emma" || user == "emma" || user == "Dean" || user == "dean" 
						|| user == "headteller" || user == "a124355"
						|| user == "a115244" || user == "a199029") {
					/*
					 * if (user == "admin" || user == "teller1" || user ==
					 * "teller" || user == "headteller") {
					 */
					return ($("#password").val() == user);
				} else {
					return false;
				}
			}

			/* Login Start */
			function loginToApp() {

				if ($("#userId").val() == 'rm') {
					$state.go("rmDashboard");
					$scope.role = "R";
				} else if (verifyLoginUser()) {
					if ($("#userId").val() == "teller" || $("#userId").val() == "Emma" || $("#userId").val() == "emma"
							|| $("#userId").val() == "a124355") {
						$scope.userName = "Emma";
						$scope.fullName = "Ms. Emma Wills";
						$scope.userImg = "images/cus-img.png";
						$scope.tellerRole = "Head Teller";
						$scope.authSuccessArr = [ "Signature" ];
					} else {
						$scope.userName = "Dean";
						$scope.fullName = "Mr. Dean Jones";
						$scope.userImg = "images/teller.jpg";
						$scope.tellerRole = "Teller";
					}

					// if ($('#radio-choice-1').is(':checked')) {
					$state.go("dashboard");
					$scope.role = "T";
					/*
					 * } else if ($('#radio-choice-2').is(':checked')) {
					 * $state.go("rmDashboard"); //notAvailable(); $scope.role =
					 * "R"; } else if ($('#radio-choice-3').is(':checked')) {
					 * $state.go("upsandcomers"); $scope.role = "A"; }
					 */
				} else {
					// processSignin(button);
					nativeAlert("Incorrect User Id / Password", "Error",
							defaultBtnArray);
				}

			}

			function processSignin(button) {
				var form = $(button).closest('form');
				var jsonString = constructReqParamsJsonFromHtmlForm(form,
						button);
				WL.Client.invokeProcedure({
					adapter : "signAdapter",
					procedure : MB_COMMON_ADPTR_DEFAULT_PROCEDURE,
					parameters : [ JSON.parse(jsonString) ]
				}, {
					onSuccess : loginSuccessRespHandler,
					onFailure : defaultServiceFailureRespHandler
				});
			}

			function loginSuccessRespHandler(result) {

				if (isServiceResponseValid(result)) {
					$scope.userName = result.invocationResult.responseData;
					$scope.$apply();
					var msg = newShowServiceRespStatusPopMessage(result);
					if ($('#radio1').is(':checked')) {
						$state.go("dashboard");
					} else if ($('#radio2').is(':checked')) {
						$state.go("rmDashboard");
					} else if ($('#radio3').is(':checked')) {
						$state.go("upsandcomers");
						$state.go("upsandcomers");
						$state.go("upsandcomers.captureprospect").then(
								function() {
									animatePage();
								});
					}
				} else {

					nativeAlert(ERR_MSG_SERVICE_DEFAULT,
							SWEET_ALERT_TYPE_ERROR, defaultBtnArray);
				}
			}
			/* Login End */

			$scope.otpClick = function() {
				$scope.firstPopup = "first";
				$("#authenticateOTP").show();
				// $("#manageOfflinePass").popup().popup("open");
				$("#authenticateOTP").popup().popup("open");
			};
			$scope.openOTP = function() {
				$scope.firstPopup = "otp";
			}
			$scope.openBiometric = function() {
				$scope.firstPopup = "biometric";

			}
			$scope.submitOTP = function() {
				$scope.firstPopup = "first";
				closePopup("authenticateOTP");
			};
			$scope.openHeaderPopup = function() {
				$("#tellerPopup").popup("destroy");
				$("#tellerPopup").show();
				$("#tellerPopup").popup().popup("open", {
					positionTo : '#tellerimg'
				/*
				 * $scope.custIdSearchAgent = function(inputObj, id) {
				 * $scope.flagCust = id; $scope.inputObject = {}; $scope.cType =
				 * 'Retail'; $rootScope.popupContent = 'custIdPopup';
				 * openPopup("custIdPopup"); $rootScope.flagSearcher = '';
				 *  }; $scope.searchForCif = function(searchType, inputObj){
				 * inputObj.page = searchType; $rootScope.flagSearcher = 'C'; }
				 * $scope.processCifContinueClick = function() { //$scope.custId =
				 * "CIF20150128085721"; $scope.inputObj.ciffId =
				 * "CIF20150128085721"; //$scope.custList = []; if ($scope.cType !=
				 * null && $scope.cType != "" && $scope.cType != undefined) {
				 * 
				 * closePopup("acctIdPopup"); this.inputObject.customerType =
				 * $scope.cType; // TODO only for test--- remove later -- simran //
				 * this.inputObj.customerid = $scope.custId;
				 * $scope.inputObject.customerid = "CIF20150128085721";
				 * $scope.cType = ""; this.processSearch('acctid',
				 * this.inputObject); } else { this.swapPopup('acctIdPopup');
				 * $scope.inputObject.customerid = "CIF20150128085721"; }
				 * closePopup("custIdPopup"); };
				 */
				});
			};
			$scope.renderDashboardFrmTopMenu = function(viewToBeRendered) {
				$scope.Data = {};
				if (viewToBeRendered == "dashboard") {
					// $scope.authSignList = getAuthSignList();
					$scope.authSuccessArr = [];
				}
				$state.go(viewToBeRendered);
			}
			$scope.openDirectBanking = function() {
				closePopup("tellerPopup");
				$("#directBanking").show();
				$("#directBanking").popup().popup("open");

			}
			$scope.openNotificationPopup = function() {
				$("#notificationPopup").popup("destroy");
				$("#notificationPopup").show();
				$("#notificationPopup").popup().popup("open", {
					positionTo : '#notification'
				});
			};

		});
function toggleSwitchEnable() {
	$("#switch").toggleSwitch();// });
}
myApp.config(function($stateProvider) {
	$stateProvider.state('index', {
		url : "",
		templateUrl : "login.html"
	}).state('login', {
		templateUrl : "login.html"
	}).state('rmDashboard', {
		templateUrl : "rmDashboard.html",
		controller : "rmCtrl"
	}).state('rmDashboard.newappoint', {
		views : {
			"innerContainer" : {
				templateUrl : "newAppointment.html"
			}
		}
	}).state('rmDashboard.customertray', {
		views : {
			"innerContainer" : {
				templateUrl : "customerTray.html"
			}
		}
	}).state('rmDashboard.viewcust', {
		views : {
			"innerContainer" : {
				templateUrl : "rmViewCust.html"
			}
		}
	}).state('rmDashboard.rmassets', {
		views : {
			"innerContainer" : {
				templateUrl : "rmAssets.html"
			}
		}
	}).state('upsandcomers', {
		templateUrl : "agentDashboard.html",
		controller : "agentCtrl"
	}).state('upsandcomers.captureprospect', {
		views : {
			"innerContainer" : {
				templateUrl : "captureProspects.html"
			}
		}
	}).state('upsandcomers.captureprospectsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "captureProspectSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('upsandcomers.convertcustomer', {
		views : {
			"innerContainer" : {
				templateUrl : "convertCustomers.html"
			}
		}
	}).state('upsandcomers.convertcustomersuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "convertCustomerSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('upsandcomers.customeronboard', {
		views : {
			"innerContainer" : {
				templateUrl : "captureCustomer.html"
			}
		}
	}).state('upsandcomers.customeronboardsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "captureCustomerSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('upsandcomers.agentlist', {
		views : {
			"innerContainer" : {
				templateUrl : "agentList.html"
			}
		}
	}).state('upsandcomers.agentlist1', {
		views : {
			"innerContainer" : {
				templateUrl : "agentList1.html"
			}
		}
	}).state('upsandcomers.agentlist2', {
		views : {
			"innerContainer" : {
				templateUrl : "agentList2.html"
			}
		}
	}).state('dashboard', {
		templateUrl : "dashboardKiosk.html",
		controller : "tellerCtrl"
	}).state('dashboard.template', {
		views : {
			"mainContainer" : {
				templateUrl : "templatePage.html"
			}
		}
	}).state('dashboard.template.deposit', {
		views : {
			"innerContainer" : {
				templateUrl : "cashDeposit.html"
			}
		}
	}).state('dashboard.template.depositsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "cashDepositSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.withdrawal', {
		views : {
			"innerContainer" : {
				templateUrl : "cashWithdrawal.html"
			}
		}
	}).state('dashboard.template.withdrawalsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "cashWithdrawalSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.coinexchange', {
		views : {
			"innerContainer" : {
				templateUrl : "coinExchange.html"
			}
		}
	}).state('dashboard.template.coinexchangesuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "coinExchangeSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.fundtransfer', {
		views : {
			"innerContainer" : {
				templateUrl : "fundTransfer.html"
			}
		}
	}).state('dashboard.template.fundtransfersuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "singleFundTransferSuccess.html"
			}
		}
	}).state('dashboard.template.fundtransfersummary', {
		views : {
			"innerContainer" : {
				templateUrl : "fundTransferSummary.html"
			}
		}
	}).state('dashboard.template.fundtransfersummarysuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "fundTransferSummarySuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.paymentorder', {
		views : {
			"innerContainer" : {
				templateUrl : "paymentOrder.html"
			}
		}
	}).state('dashboard.template.paymentordersuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "paymentOrderSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.ddissue', {
		views : {
			"innerContainer" : {
				templateUrl : "ddIssue.html"
			}
		}
	}).state('dashboard.template.ddissuesuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "ddIssueSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.standingorder', {
		views : {
			"innerContainer" : {
				templateUrl : "standingOrder.html"
			}
		}
	}).state('dashboard.template.standingordersuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "standingOrderSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.chequebookissue', {
		views : {
			"innerContainer" : {
				templateUrl : "chequeBookIssue.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.chequebookissuesuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "chequeBookIssueSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.stopcheque', {
		views : {
			"innerContainer" : {
				templateUrl : "stopCheque.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.stopchequesuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "stopChequeSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.chequestatus', {
		views : {
			"innerContainer" : {
				templateUrl : "chequeStatus.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.chequestatussuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "chequeStatusSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.tdtrailclosure', {
		views : {
			"innerContainer" : {
				templateUrl : "tdTrailClosure.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.tdtrailclosuresuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "tdTrailClosureSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.tdclosuredetail', {
		views : {
			"innerContainer" : {
				templateUrl : "tdClosureDetail.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.tdclosurehome', {
		views : {
			"innerContainer" : {
				templateUrl : "tdClosureHomeScreen.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.tdclosure', {
		views : {
			"innerContainer" : {
				templateUrl : "tdClosure.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.tdclosuresuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "tdClosureSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.statementenquiry', {
		views : {
			"innerContainer" : {
				templateUrl : "statementEnquiry.html"
			}
		}
	}).state('dashboard.template.loanaccountenquiry', {
		views : {
			"innerContainer" : {
				templateUrl : "loanAccountInquiry.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.loanaccountenquirysuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "loanAccountInquirySuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.tdmodelling', {
		views : {
			"innerContainer" : {
				templateUrl : "tdModelling.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.tdmodellingsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "tdModellingSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('upsandcomers.recurringDeposit', {
		views : {
			"innerContainer" : {
				templateUrl : "recurringDeposit.html"
			}
		}
	}).state('upsandcomers.recurringDepositsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "recurringDepositSuccess.html"
			}
		}
	}).state('upsandcomers.fixedDeposit', {
		views : {
			"innerContainer" : {
				templateUrl : "fixedDeposit.html"
			}
		}
	}).state('upsandcomers.fixedDepositsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "fixedDepositSuccess.html"
			}
		}
	}).state('upsandcomers.savingsAccount', {
		views : {
			"innerContainer" : {
				templateUrl : "savingsAccount.html"
			}
		}
	}).state('upsandcomers.savingsAccountsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "savingsAccountSuccess.html"
			}
		}
	}).state('upsandcomers.loanApp', {
		views : {
			"innerContainer" : {
				templateUrl : "loanApplication.html"
			}
		}
	}).state('upsandcomers.loanAppDynamic', {
		views : {
			"innerContainer" : {
				templateUrl : "loanDynamicPage.html"
			}
		}
	}).state('upsandcomers.loanCustDtl', {
		views : {
			"innerContainer" : {
				templateUrl : "loanCustDetails.html"
			}
		}
	}).state('dashboard.template.transactionenquiry', {
		views : {
			"innerContainer" : {
				templateUrl : "transactionEnquiry.html"
			}
		}
	}).state('dashboard.template.transactionenquirysummary', {
		views : {
			"innerContainer" : {
				templateUrl : "transactionEnquirySummary.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.transactionenquirysuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "transactionEnquirySuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.transactionview', {
		views : {
			"innerContainer" : {
				templateUrl : "transactionView.html"
			}
		}
	}).state('dashboard.template.transactionviewdetails', {
		views : {
			"innerContainer" : {
				templateUrl : "transactionViewDetails.html"
			}
		}
	}).state('dashboard.tellercashtransfer', {
		views : {
			"mainContainer" : {
				templateUrl : "cashTransfer.html"
			}
		}
	}).state('dashboard.tellercashclosure', {
		views : {
			"mainContainer" : {
				templateUrl : "cashtovault.html"
			}
		}
	}).state('dashboard.tellercashclosuresuccess', {
		views : {
			"mainContainer" : {
				templateUrl : "cashtovaultSuccess.html"
			}
		}
	}).state('dashboard.tellercashtransfersuccess', {
		views : {
			"mainContainer" : {
				templateUrl : "cashTransferSuccess.html"
			}
		}
	}).state('dashboard.template.officialcheckpayment', {
		views : {
			"innerContainer" : {
				templateUrl : "payDemandDraft.html"
			}
		}
	}).state('dashboard.template.officialcheckpaymentsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "payDemandDraftSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.officialcheckissuance', {
		views : {
			"innerContainer" : {
				templateUrl : "ddIssue.html"
			}
		}
	}).state('dashboard.template.officialcheckissuancesuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "ddIssueSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.checkdeposit', {
		views : {
			"innerContainer" : {
				templateUrl : "checkDeposit.html"
			}
		}
	}).state('dashboard.template.checkdepositsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "checkDepositSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.checkbookorder', {
		views : {
			"innerContainer" : {
				templateUrl : "chequeBookIssue.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.checkbookordersuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "chequeBookIssueSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.combineddeposit', {
		views : {
			"innerContainer" : {
				templateUrl : "combinedDeposit.html"
			}
		}
	}).state('tellerdashboard.template.tellertransactioninquiry', {
		views : {
			"innerContainer" : {
				templateUrl : "tellerTransactionInquiry.html"
			}
		}
	}).state('tellerdashboard.template.tellernewappointment', {
		views : {
			"innerContainer" : {
				templateUrl : "newAppointment.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('tellerdashboard.template.tellertransactioninquirysuccesssuccess',
			{
				views : {
					"innerContainer" : {
						templateUrl : "tellerTransactionInquiryDetailed.html"
					}
				},
				params : {
					"foo" : null
				}
			}).state('tellerdashboard.template.tellertransactioninquirymini', {
		views : {
			"innerContainer" : {
				templateUrl : "tellerTransactionInquiryDetailed.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('tellerdashboard.template.tellertransactioninquirysuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "tellerTransactionInquirySuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('tellerdashboard', {
		templateUrl : "tellerDashboard.html",
		controller : "tellerCtrl"
	}).state('tellerdashboard.template', {
		views : {
			"mainContainer" : {
				templateUrl : "templatePage.html"
			}
		}
	}).state('tellerdashboard.template.tellercashtransfer', {
		views : {
			"innerContainer" : {
				templateUrl : "cashTransfer.html"
			}
		}
	}).state('tellerdashboard.template.tellercashclosure', {
		views : {
			"innerContainer" : {
				templateUrl : "cashtovault.html"
			}
		}
	}).state('tellerdashboard.template.tellercashclosuresuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "cashtovaultSuccess.html"
			}
		}
	}).state('tellerdashboard.template.tellercashtransfersuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "cashTransferSuccess.html"
			}
		}
	}).state('tellerdashboard.template.customertraninquiry', {
		views : {
			"innerContainer" : {
				templateUrl : "customerTranInquiry.html"
			}
		}
	}).state('tellerdashboard.template.customertraninquirysuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "customerTranInquirySuccess.html"
			}
		}
	}).state('tellerdashboard.template.pendingapprovals', {
		views : {
			"innerContainer" : {
				templateUrl : "tellerPendingApproval.html"
			}
		}
	}).state('tellerdashboard.template.withdrawal', {
		views : {
			"innerContainer" : {
				templateUrl : "cashWithdrawal.html"
			}
		}
	}).state('tellerdashboard.template.withdrawalsuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "cashWithdrawalSuccess.html"
			}
		}
	}).state('tellerdashboard.template.fileADispute', {
		views : {
			"innerContainer" : {
				templateUrl : "fileADispute.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.fileADispute', {
		views : {
			"innerContainer" : {
				templateUrl : "fileADispute.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('tellerdashboard.template.fileADisputesuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "fileADisputeSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	}).state('dashboard.template.fileADisputesuccess', {
		views : {
			"innerContainer" : {
				templateUrl : "fileADisputeSuccess.html"
			}
		},
		params : {
			"foo" : null
		}
	})
});

myApp.directive('jqm', function() {
	return {
		link : function(scope, elm, attr) {
			elm.trigger('create');
		}
	};
});

// to show the selected value of dropdown
myApp.directive('drp', function($timeout) {
	return {
		link : function($scope, elem, attrs) {
			$timeout(function() {
				$(elem).trigger("change");
			});
		}
	};
});

myApp.filter('currencyFormat',
		function($filter) {
			return function(input, currVal) {
				if (!isNaN(input)) {
					if (currVal == "USD") {
						return $filter('number')(input, 2);
					} else {
						var result = input.toString().split('.');

						var lastThree = result[0]
								.substring(result[0].length - 3);
						var otherNumbers = result[0].substring(0,
								result[0].length - 3);
						if (otherNumbers != '')
							lastThree = ',' + lastThree;
						var output = otherNumbers.replace(
								/\B(?=(\d{2})+(?!\d))/g, ",")
								+ lastThree;

						if (result.length > 1) {
							output += "." + result[1];
						}

						return output;
					}
				}
			}
		});

myApp
		.directive(
				'toggleBtn',
				[ function() {
					return {
						restrict : 'EA',
						replace : true,
						require : [ 'name', '^ngModel' ],
						scope : {
							isDisabled : '=',
							onType : '@',
							offType : '@',
							name : '@',
							ngModel : '=',
							ngChange : '&',
							onLabel : '@',
							offLabel : '@',
							required : '@',
							ngTrueValue : '@',
							ngFalseValue : '@'
						},
						template : ' <div class="toggle-switch" ng-class="\'on\'+onType+ \' \' + \'off\'+offType"> '
								+ '		<span ng-if="offLabel" class="off-label" ng-bind="offLabel"></span> '
								+ ' 	<input ng-model="ngModel" id="{{name}}" name="{{name}}" type="checkbox" selected="ngModel" ng-disabled="isDisabled" ng-change="ngChange()" '
								+ '			hidden="" ng-true-value="{{ngTrueValue? ngTrueValue:true}}" ng-false-value="{{ngFalseValue? ngFalseValue:false}}" ng-required="required"><label for="{{name}}" '
								+ '			class="toggle-knob"></label> '
								+ '		<span ng-if="onLabel" class="on-label" ng-bind="onLabel"></span> '
								+ '	</div> '
					};
				} ]);

myApp.directive('radiorefresh',
		function($timeout) {
			return {
				link : function($scope, elem, attrs) {
					$timeout(function() {
						$('input[type="radio"]:not(:checked)').checkboxradio(
								"refresh");
						$('input[type="radio"]:checked').checkboxradio(
								"refresh");
					});
				}
			};
		});

function onclickmenu(event) {
	$("#dd").toggleClass('active');
	event.stopPropagation();
};