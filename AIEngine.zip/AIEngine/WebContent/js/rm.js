
myApp.controller("rmCtrl", function($scope, $rootScope, $state, $filter) {
	$scope.Date = new Date();
	$scope.time = {
		       value: new Date(1970, 0, 1, 24, 00, 0)
		     };
	$scope.selectViewDtlsRadio = function(id) {
	
		if(id == "acct_no"){
			$scope.viewDtlTab = "acct";
		} else if(id == "cust_id"){
			$scope.viewDtlTab = "cust";
		} else if(id == "card_no"){
			$scope.viewDtlTab = "card";
		}
		$("input:text").val("");
		selectRadio(id);
	}
	
	$scope.viewDetailsClick = function(formname) {
		$rootScope.submitted = true;
		Data = $scope.Data;
			//$scope.loading = true; //Commented By: Linmoy
			processViewDtlsSubmit();
		$(".loading-start").animate({
			right : '0',
			opacity : '1'
		});
	};
	
	$scope.customerTrayPieClick = function(pieClicked){
			$state.go("rmDashboard.rmassets").then(function(){
				$scope.pieClicked = pieClicked;
			});
	};
	
	function invokeViewDetails(successHandler) {
		
		var jsonString = '{ "page":"viewDetails", "accNumber":"'
				+ Data.accNumb
				+ '","defaultAccNum":"'
				+ Data.accNumb + '"}';
		invokeMBProcedure(JSON.parse(jsonString),
				successHandler);
	}
	
	function processViewDtlsSubmit() {
		
		//invokeViewDetails(viewDtlsSuccessRespHandler);
		viewDtlsSuccessRespHandler();
	}

	function viewDtlsSuccessRespHandler() {//result
		
		//WL.Logger.debug("Service Result::"+ JSON.stringify(result));
		delete $scope.loading;
		/*if (isServiceResponseValid(result)) {
			var serviceExecCode = result.invocationResult.serviceStatus.serviceStatusCode;
			if (serviceExecCode == SERVICE_RESPONSE_CODE_SUCCESS) {*/
					$state.go("rmDashboard.customertray").then(function(){
						$scope.viewDtl = {};
				/*if (result.invocationResult.responseData != null) {*/
					populateCustDetails();//result.invocationResult.responseData
				//}
					console.log("Go");
				var jsonString = '{ "page":"signature", "accNumber":"'
						+ Data.accNumb
						+ '","defaultAccNum":"'
						+ Data.accNumb + '"}';
				// TODO - comment n uncomment - simran
				$scope.viewedCustDtls = true;
					});
				/*
				 * invokeMBProcedure(JSON.parse(jsonString),
				 * signatureSuccessRespHandler);
				 */
			/*} else if ($scope.viewDtl != ""
					&& $scope.viewDtl != undefined) {
				delete $scope.viewDtl;
				$scope.viewedCustDtls = true;
				$scope.$apply();
			} else {
				$scope.viewedCustDtls = true;
				$scope.$apply();
			}*/
		//}
	}
	
	function populateCustDetails() {//resp
		
	//	if (resp != null && resp.AcctInqRs != null) {
			//var inqResp = resp.AcctInqRs;
			var accCurrency = 'USD';//inqResp.AcctId.AcctCurr
			// Data.setAccCurrency(accCurrency);
			//Data.accCurrency = accCurrency;
			//Data.branchId = inqResp.AcctId.BankInfo.BranchId;
			//updateBalances(inqResp);
			//if (inqResp.AcctFreezeStatus == "" || inqResp.AcctFreezeStatus == " ") {
				$scope.viewDtl.freezeStat = "NA";
			/*} else {
				$scope.viewDtl.freezeStat = inqResp.AcctFreezeStatus;
			}*/
			//if (inqResp.ModeOfOperCode == "") {
				$scope.viewDtl.operationMod = "Single";
			/*} else {
				$scope.viewDtl.operationMod = inqResp.ModeOfOperCode;
			}*/
			//if (inqResp.BankAcctStatusCode == "A") {
				$scope.viewDtl.acctStat = "Active";
			/*} else if (inqResp.BankAcctStatusCode == "I") {
				$scope.viewDtl.acctStat = "Inactive";
			}*/
			$scope.viewDtl.accOpenDt = 'Oct 31, 2013';//inqResp.AcctOpenDt.split("T")[0]
			$scope.viewDtl.custId = 'MB001';//inqResp.CustId.CustId
			$scope.viewDtl.name = 'MR. STEVE ROBINS';//inqResp.CustId.PersonName.TitlePrefix+ " " + inqResp.CustId.PersonName.Name
			$scope.viewDtl.ledgerBal = 'USD 25,506.39 Cr';
			$scope.viewDtl.availBal = 'USD 25,506.39 Cr.';
			$scope.viewDtl.effAvailBal = 'USD 100,801.71 Cr.'
		//}
	}
	
	function updateBalances(inqResp) {
	
		var balArr = inqResp.AcctBal;
		var accCurrency = inqResp.AcctId.AcctCurr + " ";
		for (arr in balArr) {
			if (balArr[arr].BalType == "LEDGER") {
				$scope.viewDtl.ledgerBal = $filter('currency')(
						balArr[arr].BalAmt.amountValue,
						accCurrency, 2)
						+ " " + balArr[arr].CrDrInd + "r.";
			}
			if (balArr[arr].BalType == "AVAIL") {
				$scope.viewDtl.availBal = $filter('currency')(
						balArr[arr].BalAmt.amountValue,
						accCurrency, 2)
						+ " " + balArr[arr].CrDrInd + "r.";
			}
			if (balArr[arr].BalType == "EFFAVL") {
				$scope.viewDtl.effAvailBal = $filter('currency')
						(balArr[arr].BalAmt.amountValue,
								accCurrency, 2)
						+ " " + balArr[arr].CrDrInd + "r.";
			}
		}
	}
	$scope.newAppointmentAdd = function(name){
		if(name!=undefined && name!=""){
			var message = 'Your appointment to meet '+name+' is added successfully';
		
		}
		else{
			var message = 'Your appointment is added successfully';
		}
		nativeAlert(message, 'Success', defaultBtnArray);
	}
	
});