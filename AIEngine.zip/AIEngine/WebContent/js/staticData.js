function getDayAsString(intDate) {
	var weekday = new Array(7);
	weekday[0] = "Sunday";
	weekday[1] = "Monday";
	weekday[2] = "Tuesday";
	weekday[3] = "Wednessday";
	weekday[4] = "Thursday";
	weekday[5] = "Friday";
	weekday[6] = "Saturday";
	return weekday[intDate];
}

function getDaysArray() {
	return [ "Monday", "Tuesday", "Wednessday", "Thursday", "Friday" ];
}

function getPaymentOptions() {
	return [ {
		name : "SWIFT",
		value : "swift"
	}, {
		name : "RTGS",
		value : "rtgs"
	}, {
		name : "NEFT",
		value : "neft"
	}, {
		name : "IMPS",
		value : "imps"
	}, {
		name : "FEDWR",
		value : "fedwr"
	}, {
		name : "NACHA",
		value : "nacha"
	} ];
}

function getCustomerType() {
	return [ {
		name : "Retail",
		value : "Retail"
	}, {
		name : "Corporate",
		value : "Corporate"
	} ];
}

function getInstrumentType() {
	return [ {
		name : "Check",
		value : "CHQ"
	}, {
		name : "Withdrawal Slip",
		value : "PIS"
	} ];
}

function getInstrumentType1() {
	return [ {
		name : "Check",
		value : "CHQ"
	}, {
		name : "Transaction Slip",
		value : "PIS"
	} ];
}


function getCurrencyDropdown() {
	return [ {
		name : "USD",
		value : "USD"
	}, {
		name : "INR",
		value : "INR"
	}, {
		name : "EUR",
		value : "EUR"
	}, {
		name : "CAD",
		value : "CAD"
	}, {
		name : "ZAR",
		value : "ZAR"
	}, {
		name : "CHF",
		value : "CHF"
	}, {
		name : "GBP",
		value : "GBP"
	}, {
		name : "JPY",
		value : "JPY"
	} ];
}

function getFrequency() {
	return [ {
		name : "Daily",
		value : "D"
	}, {
		name : "Weekly",
		value : "W"
	}, {
		name : "Fortnightly",
		value : "F"
	}, {
		name : "Monthly",
		value : "M"
	}, {
		name : "Bimonthly",
		value : "B"
	}, {
		name : "Quarterly",
		value : "Q"
	}, {
		name : "Yearly",
		value : "Y"
	} ];
}

function initDayString() {
	return {
		"cashDeposit" : {
			"transactAmt" : 0,
			"noOfTransact" : 0
		},
		"cashWithdrawal" : {
			"transactAmt" : 0,
			"noOfTransact" : 0
		},
		"fundTransfer" : {
			"transactAmt" : 0,
			"noOfTransact" : 0
		},
		"paymentOrder" : {
			"transactAmt" : 0,
			"noOfTransact" : 0
		}
	};
}

function initAgentCount() {
	return {
		"prospect" : 0,
		"custConvert" : 0,
		"custOnboard" : 0
	};
}

function getAgentObj() {
	return {
		"prospect" : {},
		"custConvert" : {},
		"custOnboard" : {}
	};
}

function getDesignType() {
	return [ {
		name : "With Main Account Holder Name ",
		value : "CHQ"
	}, {
		name : "Without Main Account Holder Name",
		value : "PIS"
	} ];
}

function getReasonCode() {
	return [ {
		name : "Check Reported Lost",
		value : "001"
	}, {
		name : "Payment Stopped by drawer",
		value : "002"
	}, {
		name : "Drawer reported Insolvent",
		value : "003"
	}, {
		name : "Drawer reported Lunatic",
		value : "004"
	}, {
		name : "Account Freezed",
		value : "005"
	}, {
		name : "Refer to Drawer",
		value : "006"
	}, {
		name : "Effects not cleared",
		value : "007"
	}, {
		name : "Material Alteration",
		value : "008"
	}, {
		name : "Amt in fig and word differnce",
		value : "009"
	}, {
		name : "Signature differs",
		value : "010"
	}, {
		name : "Insufficient Balance",
		value : "011"
	}, {
		name : "Others",
		value : "999"
	} ];
}

function getClosureMode() {
	return [ {
		name : "Cash Only",
		value : "C"
	}, {
		name : "Repayment Account Only",
		value : "Y"
	} ];
}

function getWithdrawalType() {
	return [ {
		name : "None",
		value : "O"
	}, {
		name : "Net",
		value : "N"
	}, {
		name : "Gross",
		value : "G"
	} ];
}

function getClosureType() {
	return [ {
		name : "Maturity Value ",
		value : "CHQ"
	}, {
		name : "Principal With Interest",
		value : "PIS"
	}, {
		name : "Principal Without Interest",
		value : "PIS"
	} ];
}

function getClosureReasonCode() {
	return [ {
		name : "Death",
		value : "001"
	}, {
		name : "Maturity",
		value : "002"
	}, {
		name : "Needs Fund",
		value : "003"
	}, {
		name : "Unhappy with service",
		value : "004"
	}, {
		name : "Better Rates",
		value : "005"
	}, {
		name : "Affinity Account Transfer",
		value : "006"
	}, {
		name : "Account Closed by Bank",
		value : "007"
	}, {
		name : "Fraud",
		value : "008"
	}, {
		name : "Excessive withdrawal",
		value : "009"
	}, {
		name : "Reclassification",
		value : "010"
	}, {
		name : "Overdraft",
		value : "011"
	}, {
		name : "Callable",
		value : "012"
	}, {
		name : "Others",
		value : "999"
	} ];
}

function getSchemeCode() {
	return [ {
		name : "Premature Withdrawal ",
		value : "CHQ"
	}, {
		name : "Withdrawal on Maturity",
		value : "PIS"
	} ];
}

function getTransactionPeriod() {

	return [ {
		name : "Today",
		value : "today"
	}, {
		name : "Last One Month",
		value : "1Mnth"
	}, {
		name : "Last Three Months",
		value : "3Mnth"
	}, {
		name : "Last Six Months",
		value : "6Mnth"
	} ];

}

function getOnMaturityTypes() {

	return [ {
		name : "Credit back to Savings Account",
		value : "CBS"
	}, {
		name : "Auto-renew",
		value : "RN"
	},

	];

}

function getStopPaymentMode() {
	return [ {
		name : "Not Applicable",
		value : "N"
	}, {
		name : "Oral",
		value : "O"
	}, {
		name : "Written",
		value : "W"
	} ];
}


function getInterestMethod(){
	return [ {
		name : "Simple Interest Monthly",
		value : "SM"
	}, {
		name : "Simple Interest Day",
		value : "SD"
	}, {
		name : "Simple Interest full months",
		value : "MF"
	}, {
		name : "Simple Interest (Months & Days)",
		value : "MD"
	}, {
		name : "Discounted Interest",
		value : "DI"
	}, {
		name : "Compound Interest (REINV scheme)",
		value : "KD"
	}, {
		name : "Compound Interest (For RD)",
		value : "RD"
	}, {
		name : "Compound Interest (For spl RD)",
		value : "SRD"
	}, {
		name : "Quarterly Discounted Interest",
		value : "QD"
	}, {
		name : "Monthly Discounted Interest",
		value : "MDI"
	}, {
		name : "FCNR - Compound Interest (in months)",
		value : "FKD"
	}, {
		name : "FCNR - Compound Interest (in Days)",
		value : "SKD"
	}];
}

function getDaysInYr(){
	return [{
		name : "360", value : "360"
	}, {
		name : "361", value : "361"
	}, {
		name : "362", value : "362"
	}, {
		name : "363", value : "363"
	}, {
		name : "364", value : "364"
	}, {
		name : "365", value : "365"
	}];
}

function getDocType() {
	return [{
		name : "Address Proof", value : "Address Proof"
	}, {
		name : "Financial Proof", value : "Financial Proof"
	}, {
		name : "Identity Proof", value : "Identity Proof"
	}];
}

//Loan 
function getExpenseType(){
	return [{
		name : "Rent", value : "Rent"
	}, {
		name : "Maintenance", value : "Maintenance"
	}];
}

function getAssetType() {
	return [{
		name : "Vehicle", value : "Vehicle"
	}, {
		name : "Savings", value : "Savings"
	}, {
		name : "Real Estate", value : "Real Estate"
	}, {
		name : "Shares", value : "Shares"
	}, {
		name : "Others", value : "Others"
	}];
}

function getAccountType(){
	return {
		'Current Account': ['3200CA1645890701','3200CA1645890702'],
		'Savings Account': ['3200SB1645890701','3200SB1645890702'],
		'Loan Account': ['3200LA1645890701','3200LA1645890702','3200LA1645890703'],
		'Deposit Account': ['3200DA1645890701','3200DA1645890702','3200DA1645890703','3200DA1645890704']
	}
	
	/*[ {
		name : "Current Account",
		value : "Current Account"
	}, {
		name : "Savings Account",
		value : "Savings Account"
	}, {
		name : "Loan Account",
		value : "Loan Account"
	}, {
		name : "Deposit Account",
		value : "Deposit Account"
	} ];*/
}

function getbicList(){
	return [{
	      "BIC":"SANTSGSG123",
	      "DirectoryBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"294",
	         "bankCode":"01"
	      },
	      "AppBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"294",
	         "bankCode":"01"
	      },
	      "BKESetup":[],
	      "PaysysId":[],
	      "BankName":"SANTANDER"
	   },
	   {
	      "BIC":"SANTUKEUXXX",
	      "DirectoryBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"295",
	         "bankCode":"01"
	      },
	      "AppBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"295",
	         "bankCode":"01"
	      },
	      "BKESetup":[],
	      "PaysysId":[],
	      "BankName":"SANTANDER UK"
	   },
	   {
	      "BIC":"SANTPORTXXX",
	      "DirectoryBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"299",
	         "bankCode":"01"
	      },
	      "AppBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"299",
	         "bankCode":"01"
	      },
	      "BKESetup":[],
	      "PaysysId":[],
	      "BankName":"SANTANDER PORTUGAL"
	   },
	   {
	      "BIC":"NDEASEKKXXX",
	      "DirectoryBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"295",
	         "bankCode":"01"
	      },
	      "AppBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"294",
	         "bankCode":"01"
	      },
	      "BKESetup":[],
	      "PaysysId":[],
	      "BankName":"SANTANDER SPAIN"
	   },
	   {
	      "BIC":"SANTHKKKXXX",
	      "DirectoryBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"002",
	         "bankCode":"GSAN"
	      },
	      "AppBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"292",
	         "bankCode":"01"
	      },
	      "BKESetup":[],
	      "PaysysId":[],
	      "BankName":"SANTANDER HONG KONG"
	   },
	   {
	      "BIC":"SANTPOLDXXX",
	      "DirectoryBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"299",
	         "bankCode":"01"
	      },
	      "AppBankBranchInfo":{
	         "brName":[],
	         "bankName":[],
	         "brCode":"297",
	         "bankCode":"01"
	      },
	      "BKESetup":[],
	      "PaysysId":[],
	      "BankName":"SANTANDER POLAND"
	   }];
}

function getMiniTransactionDtls() {
	return [ {
		"transactionSummary" : {
			"txnDate" : "2017-03-01",
			"txnType" : "1014423",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "12,000.00 Cr."
			},
			"txnDesc" : "SoftChainLtd DDINVOICE 3664",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "60,000.50"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2017-03-02",
			"txnType" : "123431",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "600.20 Dr."
			},
			"txnDesc" : "JaneNoveltiesLtd BGINVOICE 4780",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "59,400.69"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2017-03-12",
			"txnType" : "434401",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "700.00 Dr."
			},
			"txnDesc" : "BlakeMotorsLtd\Flow TFRINVOICE47884Cash",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "58,700.15"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2017-03-10",
			"txnType" : "542261",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "10,000.50 Dr."
			},
			"txnDesc" : "TOSoftchaiLtd A\C TFR12345678",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "68,700.76"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2017-03-06",
			"txnType" : "74363",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "6,000.00 Dr."
			},
			"txnDesc" : "RentalSpaceLtd\Flow TFRINVOICE384994Check",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "62,700.45"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2017-03-02",
			"txnType" : "346546",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "600 Dr."
			},
			"txnDesc" : "Xavier'sLTD FPI INVOICE710",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "62,100.00"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2017-03-10",
			"txnType" : "567567",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "700 Dr."
			},
			"txnDesc" : "FT483INVOICE REF/3q453 USD",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "61,400.56"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2017-03-03",
			"txnType" : "M3946",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "25,000.00 Dr."
			},
			"txnDesc" : "INTERA\CTRANSFFT34 JaneNoveltiesLtd",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "25,000.52"
		}
	} ];
}

function getLiabilityType() {
	return [{
		name : "Credit Card", value : "CC"
	}, {
		name : "Overdraft", value : "OD"
	}, {
		name : "Loan", value : "LA"
	}];
}

function getBooleanVal(){
	return [{
		name : "Yes", value : "yes"
	}, {
		name : "No", value : "no"
	}];
}

function getLoanType(){
	return [{
		name : "Home", value : "H"
	}, {
		name : "Auto", value : "O"
	}, {
		name : "Personal", value : "P"
	}];
}

function getCity(){
	return [ {
		name : "Charlotte",
		value : "Charlotte"
	}, {
		name : "Sacramento",
		value : "Sacramento"
	}, {
		name : "Sanfrancisco",
		value : "Sanfrancisco"
	}, {
		name : "Harrisburg",
		value : "Harrisburg"
	}, {
		name : "Houston",
		value : "Houston"
	}, {
		name : "Dallas",
		value : "Dallas"
	}, {
		name : "Austin",
		value : "Austin"
	}, {
		name : "Phoenix",
		value : "Phoenix"
	}, {
		name : "Mesa",
		value : "Mesa"
	}, {
		name : "Pittsburgh",
		value : "Pittsburgh"
	}, {
		name : "Philadelphia",
		value : "Philadelphia"
	}];
}

function getState() {
	return [{
		name : "North Carolina", value : "North Carolina"
	}, {
		name : "California", value : "California"
	}, {
		name : "Pennysylvania", value : "Pennysylvania"
	}, {
		name : "Texas", value : "Texas"
	}, {
		name : "Arizona", value : "Arizona"
	}];
}

function getCountry() {
	return [{
		name : "USA", value : "USA"
	}];
}

function getTransactionDtls(){
    return [
           {
             "transactionSummary": {
                   "txnDate": "2016-04-01",
                    "txnType": "D",
                    "txnAmt": {
                        "currencyCode": "USD",
                        "amountValue": "2,000.00"
                    },
                    "txnDesc": "SoftChainLtd DDINVOICE3637",
             },
             "txnBalance": {
                 "currencyCode": "USD",
                 "amountValue": "60,000.50"
             }
           },
           {
                    "transactionSummary": {
                          "txnDate": "2016-04-02",
                          "txnType": "D",
                          "txnAmt": {
                               "currencyCode": "USD",
                               "amountValue": "600.20"
                          },
                          "txnDesc": "JaneNoveltiesLtd BGINVOICE7440",
             },
             "txnBalance": {
                 "currencyCode": "USD",
                 "amountValue": "59,400.69"
             }
           },
           {
             "transactionSummary": {
                          "txnDate": "2016-04-12",
                          "txnType": "D",
                          "txnAmt": {
                               "currencyCode": "USD",
                               "amountValue": "700.00"
                          },
                          "txnDesc": "BlakeMotorLtd Flow TFRINVOICE47884Cash",
                    },
             "txnBalance": {
                 "currencyCode": "USD",
                 "amountValue": "58,700.15"
             }
           },
           {
             "transactionSummary": {
                          "txnDate": "2016-05-01",
                          "txnType": "C",
                          "txnAmt": {
                               "currencyCode": "USD",
                               "amountValue": "10,000.50"
                          },
                          "txnDesc": "TOSoftchainLtd A\C TFR12345",
                    },
             "txnBalance": {
                 "currencyCode": "USD",
                 "amountValue": "68,700.76"
             }
           },
           {
             "transactionSummary": {
                          "txnDate": "2016-05-01",
                          "txnType": "D",
                          "txnAmt": {
                               "currencyCode": "USD",
                               "amountValue": "6,000.00"
                          },
                          "txnDesc": "RentalSpaceLtd \ Flow TFRINV4994Check",
                    },
             "txnBalance": {
                 "currencyCode": "USD",
                 "amountValue": "62,700.45"
             }
           },
           {
             "transactionSummary": {
                          "txnDate": "2016-05-02",
                          "txnType": "D",
                          "txnAmt": {
                               "currencyCode": "USD",
                               "amountValue": "600"
                          },
                          "txnDesc": "Xavier'sLTD FPI INVOICE6710",
                    },
             "txnBalance": {
                 "currencyCode": "USD",
                 "amountValue": "62,100.00"
             }
           },
           {
             "transactionSummary": {
                          "txnDate": "2016-05-15",
                          "txnType": "D",
                          "txnAmt": {
                               "currencyCode": "USD",
                               "amountValue": "700"
                          },
                          "txnDesc": "FT478483 INVOICE REF /3q453",
                    },
             "txnBalance": {
                 "currencyCode": "USD",
                 "amountValue": "61,400.56"
             }
           },
           {
             "transactionSummary": {
                          "txnDate": "2016-06-01",
                           "txnType": "C",
                          "txnAmt": {
                               "currencyCode": "USD",
                               "amountValue": "10,000.00"
                          },
                          "txnDesc": "INTER A\C TRANSFFT385 JaneNoveltiesLtd",
                    },
             "txnBalance": {
                 "currencyCode": "USD",
                 "amountValue": "71,400.52"
             }
           }      
    ];
}

function getTxnStatus() {
	return [{
		name : "Entered", value : "E"
	}, {
		name : "Deleted", value : "D"
	}, {
		name : "Posted", value : "P"
	}, {
		name : "Verified", value : "V"
	}];
}
function getTxnType() {
	return [{
		name : "Cash", value : "C"
	}, {
		name : "Transfer", value : "T"
	}, {
		name : "Clearing", value : "L"
	}];
}

function getDetailsOnTransID(){
	return [
	    	{
    		  "transactionDetails": {
    			  "txnID": "01174164",
    			  "txnDate": "2016-06-01",
	    		  "txnAmt": {
	    			"currencyCode": "USD",
	    			"amountValue": "2,000.00",
	    			"type": "Cr."
	    		  },
	    		  "txnDesc": "Rent of April",
    		  }
    		},{
    		  "transactionDetails": {
    			  "txnID": "01174164",
    			  "txnDate": "2016-06-01",
	    		  "txnAmt": {
	    			"currencyCode": "USD",
	    			"amountValue": "2,000.00",
	    			"type": "Dr."
	    		  },
	    		  "txnDesc": "Rent of April",
    		  }
    		}
    	];
}

function gettransIDDetails(){
	return [
	    	{
    		  "transactionDetails": {
    			  "txnID": "01174164",
    			  "txnDate": "2016-06-01",
	    		  "txnAmt": {
	    			"currencyCode": "USD",
	    			"amountValue": "2,000.00",
	    			"type": "Cr."
	    		  },
	    		  "txnDesc": "Rent of April",
    		  }
    		},{
    		  "transactionDetails": {
    			  "txnID": "01174164",
    			  "txnDate": "2016-06-01",
	    		  "txnAmt": {
	    			"currencyCode": "USD",
	    			"amountValue": "2,000.00",
	    			"type": "Dr."
	    		  },
	    		  "txnDesc": "Rent of April",
    		  }
    		},
    		{
      		  "transactionDetails": {
      			  "txnID": "01174163",
      			  "txnDate": "2016-06-01",
  	    		  "txnAmt": {
  	    			"currencyCode": "USD",
  	    			"amountValue": "3,600.00",
  	    			"type": "Cr."
  	    		  },
  	    		  "txnDesc": "Car Payment",
      		  }
      		},{
      		  "transactionDetails": {
      			  "txnID": "01174163",
      			  "txnDate": "2016-06-01",
  	    		  "txnAmt": {
  	    			"currencyCode": "USD",
  	    			"amountValue": "3,600.00",
  	    			"type": "Dr."
  	    		  },
  	    		  "txnDesc": "Car Payment",
      		  }
      		}
    	];
}
//sasi
function getTransactionSubtype() {
	return [ {
		name : "Cash Deposit",
		value : "Cash Deposit"
	}, {
		name : "On-Us Deposit",
		value : "On-Us Deposit"
	}, {
		name : "Official Check Deposit",
		value : "Official Check Deposit"
	}, {
		name : "Transit Deposit",
		value : "Transit Deposit"
	}, {
		name : "Less Cash Amount",
		value : "Less Cash Amount"
	}, {
		name : "Split Deposit",
		value : "Split Deposit"
	}, {
		name : "Official Check Purchase",
		value : "Official Check Purchase"
	} ];
} 
//sasi

function getTransactionPeriod() {

	return [ {
		name : "Today",
		value : "today"
	}, {
		name : "Last One Month",
		value : "1Mnth"
	}, {
		name : "Last Three Months",
		value : "3Mnth"
	}, {
		name : "Last Six Months",
		value : "6Mnth"
	} ];

}

function getTransactionDtls() {
	return [ {
		"transactionSummary" : {
			"txnDate" : "2016-04-01",
			"txnType" : "D",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "2,000.00"
			},
			"txnDesc" : "Rent of April",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "60,000.50"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2016-04-02",
			"txnType" : "D",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "600.20"
			},
			"txnDesc" : "Bike EMI",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "59,400.69"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2016-04-12",
			"txnType" : "D",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "700.00"
			},
			"txnDesc" : "Home Loan",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "58,700.15"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2016-05-01",
			"txnType" : "C",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "10,000.50"
			},
			"txnDesc" : "Salary May",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "68,700.76"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2016-05-01",
			"txnType" : "D",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "6,000.00"
			},
			"txnDesc" : "Rent May",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "62,700.45"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2016-05-02",
			"txnType" : "D",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "600"
			},
			"txnDesc" : "Bike EMI",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "62,100.00"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2016-05-15",
			"txnType" : "D",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "700"
			},
			"txnDesc" : "Home Loan",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "61,400.56"
		}
	}, {
		"transactionSummary" : {
			"txnDate" : "2016-06-01",
			"txnType" : "C",
			"txnAmt" : {
				"currencyCode" : "USD",
				"amountValue" : "10,000.00"
			},
			"txnDesc" : "Salary June",
		},
		"txnBalance" : {
			"currencyCode" : "USD",
			"amountValue" : "71,400.52"
		}
	} ];
}

function getbeneficiary(){
	return [ {
		name : "CIF20150128085001 - Ammy",
		value : "CIF20150128085001",

	}, {
		name : "CIF20150128085020 - John",
		value : "CIF20150128085020",

	}, {
		name : "CIF20150128085555 - William",
		value : "CIF20150128085555",

	}];
}

function getbeneficiaryOutsideBank(){
	return [ {
		name : "CUSTACCT10 - Graham",
		value : "CUSTACCT10",

	}, {
		name : "CUSTACCT11 - Jennifer",
		value : "CUSTACCT11",

	}, {
		name : "CUSTACCT13 - Joe",
		value : "CUSTACCT13",

	}];
}

function gettransactorType() {
	return [{
		name : "Beneficiary",
		value : "BENF"
	}, {
		name : "Conductor",
		value : "COND"
	}];	
}

function getAppointmentReason() {
	return [ {
		name : "Inquiry on loan offerings",
		value : "loan"
	}, {
		name : "Open SB account",
		value : "sbacct"
	}, {
		name : "Open Deposit account",
		value : "depacct"
	}, {
		name : "Inquire on mutual funds",
		value : "mutualfunds"
	}, {
		name : "Inquire on saving bonds",
		value : "savingbonds"
	}, {
		name : "Others",
		value : "Others"
	} ];
}