var accnum = "";

myApp
		.controller(
				"tellerCtrl",
				function($scope, $rootScope, $state, $filter, $timeout,
						$localStorage, getWatchCount) {
					$scope.time = {
						value : new Date()
					};
					$scope.tellerCurr = "USD";
					$scope.name1 = "Steve Robin";
					$scope.name2 = "Steve Scott";
					$scope.name3 = "Steve Linn";
					$scope.statementDiv = "sel_range";
					// $scope.accountNumber = "";
					$scope.loading = "";
					$scope.viewedCustDtls = false;
					$scope.uiRouterState = $state;
					$scope.paymentOptions = getPaymentOptions();
					$scope.frequency = getFrequency();
					$scope.accCurrency = getCurrencyDropdown();
					$scope.instrumentType = getInstrumentType();
					$scope.instrumentType1 = getInstrumentType1();
					$scope.designType = getDesignType();
					$scope.reasonCode = getReasonCode();
					$scope.closureMode = getClosureMode();
					$scope.closureType = getClosureType();
					$scope.closureReasonCode = getClosureReasonCode();
					$scope.withdrawalType = getWithdrawalType();
					$scope.schemeCode = getSchemeCode();
					$scope.transactionPeriod = getTransactionPeriod();
					$scope.custType = getCustomerType();
					$scope.stopPaymentMode = getStopPaymentMode();
					$scope.interestMethod = getInterestMethod();
					$scope.beneficiary = getbeneficiary();
					$scope.beneficiaryOutsideBank = getbeneficiaryOutsideBank();
					$scope.transactorType = gettransactorType();
					$scope.daysInYr = getDaysInYr();
					$scope.appointmentReason = getAppointmentReason();
					$scope.transactPeriod = getTransactionPeriod();
					$rootScope.submitted = false;
					$scope.fundTransferObj = {};
					$scope.openingBalance = 400000;
					$scope.fundSummaryObj = {
						fundTransferRec : 1,
						currentRec : 1,
						totalCreditAmt : 0,
						totalDebitAmt : 0,
						numOfDebits : 0,
						numOfCredits : 0
					};
					$scope.inputObj = {};
					$scope.inputObject = {};
					$scope.ctrInputObj = {};
					$scope.sel = "";
					$scope.visibleSign = false;
					/* Added by Linmoy:: START */
					$scope.accType = getAccountType();
					$scope.chqStatus = "Cancelled";
					/* Added by Linmoy:: END */
					$scope.dashboardAcct = "";
					$rootScope.popupContent = "";
					$rootScope.flagSearcher = '';
					$scope.flagExc = false;
					$scope.custSummaryObj = [];
					$scope.countryList = getCountry();
					$scope.stateList = getState();
					$scope.cityList = getCity();
					$scope.timezone = (new Date().getTimezoneOffset() / 60);
					$scope.ownTransferList = [];
					$scope.insDtlArr = [];
					$scope.inputObj.docArrCust = [];
					$scope.$on('$stateChangeStart', function(event, toState,
							toParams, fromState, fromParams) {
						$rootScope.submitted = false;
						var toStateName = toState.name;
						var fromStateName = fromState.name;
						$scope.warningFlag = true;

						if (toStateName.indexOf("dashboard.template.") > -1
								&& toStateName.indexOf("success") == -1) {
							if (fromStateName == toStateName + 'success') {
								if (!fromParams.foo) {
									$scope.insDtlArr = [];
									$scope.ctrInputObj = {};
									delete $scope.toAccName;
									// $scope.accountNumber = "";
									$scope.visibleSign = false;
									$scope.inputObj = {};
									$scope.toAccName = "";
									$scope.toAccCurrency = "";
									delete $scope.transactDtls;
									delete $scope.detailsOnTransID;
									delete $scope.transIDDetails;
								}
							} else {
								$scope.insDtlArr = [];
								$scope.ctrInputObj = {};
								delete $scope.toAccName;
								// $scope.accountNumber = "";
								$scope.inputObj = {};
								$scope.visibleSign = false;
								$scope.toAccName = "";
								$scope.toAccCurrency = "";
								delete $scope.transactDtls;
								delete $scope.detailsOnTransID;
								delete $scope.transIDDetails;
							}
						}
					});
					$scope.openView = function(viewName) {

						if ($state.current.name != "dashboard.customeronboard")
							if (viewName == "Create") {
								$scope.titleCust = "Capture";
							} else {
								$scope.titleCust = viewName;
							}
						$scope.inputObj = {};
						$scope.setCurrentView(viewName);
						$scope.inputObj.accCurrency = "USD";
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
							$("input:radio").checkboxradio("refresh");
						}, 0);
						if ($state.current.name != "dashboard.customeronboard") {
							$scope.titleName = viewName;
							$(".ui-collapsible-heading").addClass(
									"ui-collapsible-heading-collapsed");
							$(".ui-collapsible-content").addClass(
									"ui-collapsible-content-collapsed");
							$(".ui-collapsible-heading a").removeClass(
									"ui-icon-carat-d").addClass(
									"ui-icon-carat-r");
						} else {
							if (viewName == "Create") {
								$scope.titleCust = "Capture";
							} else {
								$scope.titleCust = viewName;
							}
						}
					}

					$scope.flipSign = function() {
						if (angle < 181) {
							angle = angle + 45;
						} else {
							angle = 0;
						}
						$("#signature").rotate(angle);
					};
					$scope.toggleSwitchEnable = function() {
						// $state.go('dashboard.template.tdmodelling').then(function(){
						$("#switch").toggleSwitch();// });
					}
					// Common method to process the Teller's transaction submit
					$scope.processTransaction = function(inputObj,
							accountNumber) {
						if (checkEmpty($scope.inputObj.chargeEventid)) {
							$scope.feemsg = "A fee of $5 has been deducted for this transaction.";
						}
						// $scope.accountNumber = accountNumber;
						/*
						 * $rootScope.submitted = true; var elemname =
						 * angular.element(
						 * document.querySelector("form")).attr("name"); if
						 * (this[elemname].$valid) {
						 * $('.data-loading').addClass("no-display");
						 * $(".loading-start").animate({ right : '0', opacity :
						 * '1' }); $('#load').removeClass("no-display");
						 */
						/* Code By Linmoy :: START */
						if (inputObj.page == "loanAccountInquiry") {
							/* Static for loan data */
							inputObj.disbursedAmount = "5000";
							inputObj.disbursedDate = "14-JUL-2014";
							inputObj.loanTenure = "5 Years";
							inputObj.interestRate = "14%";
							inputObj.monthlyInstallment = "1140";
							inputObj.NoOfInstall = "5";
							inputObj.nextPaymentDate = "01-AUG-2015";
							inputObj.amountDue = "5000";
						}
						if (inputObj.page == "tdModelling") {
							var year = inputObj.depositDate.getYear() + 1900;
							var duration = parseInt(inputObj.months) / 12;

							var yearArr = [];
							var amount = [];
							for (var i = 0; i < duration; i++) {
								yearArr[i] = year + i + "";
								amount[i] = parseInt(inputObj.initialDep)
										+ (0.10 * i)
										* (parseInt(inputObj.initialDep));
							}

							var tdData = {
								"xData" : yearArr,
								"yData" : [ {
									"name" : "Deposit Amount",
									"data" : amount
								} ]

							};
							$scope.tdYData = tdData.yData;
							$scope.tdXData = tdData.xData;
						}
						/* Code By Linmoy :: END */
						var loandata = {
							"xData" : [ "01-AUG-2014", "01-AUG-2015",
									"01-AUG-2016", "01-AUG-2017",
									"01-AUG-2018", "01-AUG-2019" ],
							"yData" : [ {
								"name" : "Loan Amount",
								"data" : [ 5000, 4560, 3420, 2280, 1140, 0 ]
							} ]
						};

						$scope.loanYData = loandata.yData;
						$scope.loanXData = loandata.xData;
						/*
						 * var successObj = { "page" : inputObj.page, "amt" :
						 * inputObj.transactionAmount, "hrs" : new
						 * Date().getHours() };
						 * invokeTellerProcedure($scope.inputObj, successObj,
						 * transactionSuccessRespHandler); }
						 */
						if (checkEmpty($scope.inputObj.transactionAmount)) {
							if (inputObj.page == "cashDeposit") {
								$scope.viewDtl.availBal = parseFloat($scope.viewDtl.availBal)
										+ parseFloat($scope.inputObj.transactionAmount);
							} else if (inputObj.page == "cashWithdrawal") {
								$scope.viewDtl.availBal = parseFloat($scope.viewDtl.availBal)
										- parseFloat($scope.inputObj.transactionAmount);
							}
						}
						$scope.custSummaryObj.push(new CustomerSummary(
								inputObj, $scope.transactId));

						if (inputObj.page == "cashDeposit") {
							if (parseInt(inputObj.transactionAmount) >= 10000
									&& $scope.inputObj.isCtr != true) {
								swal(
										{
											title : "Error",
											text : "You have crossed your day's aggregate amount. Please enter the CTR details."
										}, function(isConfirm) {
											/*
											 * $scope
											 * .openCtrDetails($scope.inputObj);
											 * $scope.inputObj.isCtr = true;
											 * $scope.$apply();
											 */
										});
							} else {
								$state.go($state.current.name + "success")
							}
						} else {
							$state.go($state.current.name + "success")
						}
						/*
						 * .then(function(){ //
						 * $("#"+accnum).text($scope.inputObj.accountNumber); })
						 */;
					};

					$scope.processPaymentOrder = function(inputObj) {
						inputObj.page = "paymentOrder";
						$rootScope.submitted = true;
						var elemname = angular.element(
								document.querySelector("form")).attr("name");
						if (this[elemname].$valid) {
							$('.data-loading').addClass("no-display");
							$(".loading-start").animate({
								right : '0',
								opacity : '1'
							});
							$('#load').removeClass("no-display");
							$scope.inputObj = angular.copy(inputObj);
							var successObj = {
								"page" : "paymentOrder",
								"amt" : inputObj.transactionAmount,
								"hrs" : new Date().getHours()
							};
							invokeTellerProcedure($scope.inputObj, successObj,
									transactionSuccessRespHandler);
						}
					};

					$scope.processSearch = function(searchType, inputObj) {
						inputObj.page = searchType;
						if (searchType == "bic") { // Added By Linmoy
							$scope.bicList = getbicList();
							// $scope.$apply();
						} else if (searchType == "exchangeRate") {
							$scope.flagExc = true;

						} else if (searchType == "custid") {
							/*
							 * $("#trnameFilter2").hide();
							 * $("#trnameFilter1").hide(); var name1="Steve
							 * Robin"; var name2="Regina Grey";
							 * if(checkEmpty($("#firstName").val())){
							 * if(name1.indexOf($("#firstName").val())> -1){
							 * $("#trnameFilter1").show(); } else
							 * if(name2.text().indexOf($("#firstName").val())>
							 * -1){ $("#trnameFilter2").show(); } }
							 * if(checkEmpty($("#lastName").val())){
							 * if(name2.indexOf($("#lastName").val())> -1){
							 * $("#trnameFilter2").show(); } else
							 * if(name1.indexOf($("#lastName").val())> -1){
							 * $("#trnameFilter1").show(); } }
							 */
							// $scope.flagCust = true;
							$rootScope.flagSearcher = 'C';
						} else if (searchType == "acctid") {
							// $scope.flagAcct = true;
							$rootScope.flagSearcher = 'A';
						} else {

							invokeSearchProcedure(inputObj, searchType,
									searchEnquirySuccessHandler);
						}
						/*
						 * invokeSearchProcedure(inputObj, searchType,
						 * searchEnquirySuccessHandler);
						 */
					};
					$scope.repositionPopup = function() {
						$(".ui-popup").popup("reposition", {
							positionTo : 'window'
						});
					}
					$scope.processExchangeRateContinue = function() {
						Data.rateVal = 60;
						Data.rateCode = $scope.inputObject.rateCode;
						delete $scope.rateVal;
						delete $scope.inputObject;
						closePopup("exchangeRatePopup");
					};
					$scope.tellercashtovaultsubmit = function(inputObj) {

						$scope.resultOfCashToVault = "Teller Cash Closure has been done successfully. Kindly note the transaction no. M1818 for reference.";
						$state
								.go(
										"tellerdashboard.template.tellercashclosuresuccess",
										{
											foo : true
										});
					}
					$scope.showExchangeRatePopup = function() {
						$("#exchangeRatePopup").popup("destroy");
						$("#exchangeRatePopup").show();
						$("#exchangeRatePopup").popup().popup("open");
						$scope.flagExc = false;
					};
					$scope.getRootScopeVar = function(val) {
						return $rootScope[val];
					}
					/*
					 * $scope.openAcctSearcherPopup = function(){
					 * $scope.flagAcct = ""; $rootScope.popupContent =
					 * "acctIdPopup"; $scope.inputObject = {}; $scope.flagCust =
					 * ""; $("#acctIdPopup").popup("destroy");
					 * $("#acctIdPopup").show();
					 * $("#acctIdPopup").popup().popup("open"); }
					 */

					$scope.showSharePopup = function() {
						$("#sharePopup").popup("destroy");
						$("#sharePopup").show();
						$("#sharePopup").popup().popup("open", {
							positionTo : '#shareBtn'
						});
					};

					$scope.sendToPrinter = function() {
						$("#sharePopup").popup("close");
						nativeAlert("Sent to printer successfully.", "Success",
								defaultBtnArray);
					};
					$scope.sendAsEmail = function() {
						$("#sharePopup").popup("close");
						nativeAlert(
								"Email has been sent successfully to the registered email id: s*******in@gmail.com",
								"Success", defaultBtnArray);
					};

					$scope.openExportPopup = function() {
						$("#exportPopup").popup("destroy");
						$("#exportPopup").show();
						$("#exportPopup").popup().popup("open", {
							positionTo : '#exportBtn'
						});
					};

					$scope.enableExchangeRatePopup = function() {
						if (this.inputObj.accCurrency != Data.accCurrency) {
							$scope.showExchangeRatePopup();
						}
					};

					$scope.openBicPopup = function(creditorFlag) {
						this.creditorFlag = creditorFlag;
						$scope.bicList = "";
						openPopup('bicPopup');
					};

					$scope.processContinueClick = function(index) {
						if (this.creditorFlag == "Y") {
							this.inputObj.ndiCreditor = this.inputObject.paysys;
							this.inputObj.bicCreditor = $scope.bicList[index].BIC;
							this.inputObj.bankNameCreditor = $scope.bicList[index].BankName;
						} else {
							this.inputObj.ndi = this.inputObject.paysys;
							this.inputObj.bic = $scope.bicList[index].BIC;
							this.inputObj.bankName = $scope.bicList[index].BankName;
						}

						closePopup("bicPopup");
						$scope.bicList = [];
					};

					$scope.processCustIdContinueClick = function() {
						var index = $scope.inputObject.custidRadio.split(",")[0];
						var name = $scope.inputObject.custidRadio.split(",")[1];
						var custid = $scope.inputObject.custidRadio.split(",")[2];
						$scope.custId = custid;
						$scope.inputObject.customerid = custid;
						$scope.custList = [];
						if ($scope.cType != null && $scope.cType != ""
								&& $scope.cType != undefined) {

							closePopup("acctIdPopup");
							this.inputObject.customerType = $scope.cType;
							// TODO only for test--- remove later -- simran
							// this.inputObj.customerid = $scope.custId;
							$scope.inputObject.customerid = custid;
							$scope.cType = "";
							this.processSearch('acctid', this.inputObject);
						} else {
							this.swapPopup('acctIdPopup');
							$scope.inputObject.customerid = custid;
						}
					};

					$scope.processAcctIdContinueClick = function() {
						if ($state.current.name == 'dashboard') {
							if ($scope.inputObject.custid == 'USCIF6') {
								if ($scope.inputObject.row == "1") {
									$scope.Data.dashAcctNum = "3200SB1780000045";
								} else {
									$scope.Data.dashAcctNum = "3200SB1784569045";
								}
							} else {
								if ($scope.inputObject.row == "1") {
									$scope.Data.dashAcctNum = "3200CA1789654123";
								} else {
									$scope.Data.dashAcctNum = "3200SB1645890701";
								}
							}
							closePopup('acctIdPopup');
						} else {
							if ($scope.inputObject.custid == 'USCIF6') {
								if ($scope.inputObject.row == "1") {
									$scope.inputObj[accnum] = "3200SB1780000045";
								} else {
									$scope.inputObj[accnum] = "3200SB1784569045";
								}
							} else {
								if ($scope.inputObject.row == "1") {
									$scope.inputObj[accnum] = "3200CA1789654123";
								} else {
									$scope.inputObj[accnum] = "3200SB1645890701";
								}
							}
							closePopup('acctIdPopup');
							$scope
									.toAccountBlurFundTrans($scope.inputObj[accnum]);
						}
					}

					$scope.swapPopup = function(popupId) {
						$rootScope.popupContent = popupId;
					};

					$scope.processStmntEnquiry = function(inputObj) {
						$rootScope.submitted = true;
						/*
						 * var elemname = angular.element(
						 * document.querySelector("form")).attr("name"); // if
						 * (this[elemname].$valid) {
						 * $('.data-loading').addClass("no-display");
						 * $(".loading-start").animate({ right : '0', opacity :
						 * '1' }); $('#load').removeClass("no-display");
						 */
						$scope.inputObj = angular.copy(inputObj);
						statementEnquirySuccessHandler();
						// invokeTellerProcedure($scope.inputObj, null,
						// statementEnquirySuccessHandler);
						// }
					};

					$scope.printTransaction = function(inputObj) {
						$rootScope.submitted = true;
						inputObj.transno = $scope.transactId;
						var elemname = angular.element(
								document.querySelector("form")).attr("name");
						if (this[elemname].$valid) {
							$('.data-loading').addClass("no-display");
							$(".loading-start").animate({
								right : '0',
								opacity : '1'
							});
							$('#load').removeClass("no-display");
							$scope.inputObj = angular.copy(inputObj);
							var successObj = {
								"page" : inputObj.page,
								"amt" : inputObj.transactionAmount,
								"hrs" : new Date().getHours()
							};
							invokeTellerProcedure($scope.inputObj, successObj,
									printSuccessRespHandler);
						}
					}
					$scope.camScanClick = function() {
						var params = {
							nameParam : null
						};
						WL.NativePage.show("com.MobyBanker.CardScan", function(
								data) {
							$scope.cardNum = data.cardNum;
							$scope.$apply();
						}, params);
					}
					$scope.micClick = function() {

						var params = {
							nameParam : null
						};
						WL.NativePage
								.show(
										"com.MobyBanker.MicListener",
										function(data) {
											var result = data.page;
											if (result.indexOf("deposit") > -1) {
												var res = result.split(" ");

												$state
														.go("dashboard.template.deposit");
											}
											if (result.indexOf("transfer") > -1) {
												$state
														.go("dashboard.template.fundtransfer");
											}
											if (result.indexOf("withdrawal") > -1) {
												$state
														.go("dashboard.template.withdrawal");
											}
											if (result.indexOf("payment") > -1) {
												$state
														.go("dashboard.template.paymentorder");
											}

										}, params);
					}
					$scope.viewDetailsClick = function(formname, a) {
						$rootScope.submitted = true;
						if (formname.$valid) {
							$scope.Data.accNumb = a;
							$scope.dashboardAcct = $scope.Data.dashAcctNum;
							// $scope.Data.accNumb = "3200SB1645890701";
							$scope.Data.accCurrency = "USD";
							$scope.transactId = "TRAN000456123";
							$scope.paymentOrderId = "PAYMNT06123";
							$scope.errorMsgDesc = "";
							$scope.Data.branchId = "0031";
							Data = $scope.Data;
							$scope.loading = true;
							processViewDtlsSubmit();
							$scope.viewLessDtls();
						}
						$(".loading-start").animate({
							right : '0',
							opacity : '1'
						});
					};

					$scope.processTransactWithToAcc = function(inputObj) {

						$rootScope.submitted = true;
						/*
						 * if ($scope.toAccName != "" && $scope.toAccName !=
						 * undefined && $scope.toAccName != null) { var elemname =
						 * angular.element( document.querySelector("form"))
						 * .attr("name"); if (this[elemname].$valid) {
						 * $('.data-loading').addClass("no-display");
						 * $(".loading-start").animate({ right : '0', opacity :
						 * '1' }); $('#load').removeClass("no-display");
						 */
						$scope.inputObj = angular.copy(inputObj);
						/*
						 * var successObj = { "page" : inputObj.page, "amt" :
						 * inputObj.transactionAmount, "hrs" : new
						 * Date().getHours() };
						 * invokeTellerProcedure($scope.inputObj, successObj,
						 * transactionSuccessRespHandler); } } else {
						 * nativeAlert( "Please enter a valid To Account
						 * Number", "Error", defaultBtnArray); }
						 */
						$state.go($state.current.name + "success");
					}

					$scope.toAccountBlur = function(toAcc) {
						/*
						 * invokeAccountDetails(toAcc,
						 * toAccountDetailsSuccessHandler);
						 */
						$scope.toAccName = "Neil Weber";
						$scope.toAccCurrency = "USD";
					};

					$scope.toAccountBlurFundTrans = function(val) {
						if (val == 'C') {
							$scope.toAccName = "Regina Grey";
						} else {
							$scope.toAccName = "Neil Weber";
						}
						$scope.toAccCurrency = "USD";
					}

					// to navigate to any child page from dashboard top panel
					$scope.navigate = function(page, callbackFn) {
						delete this.Data.rateVal;
						this.Data.rateCode = "";
						$scope.feemsg = "";
						if (($state.current.name).split("template.")[1] == page) {
							$scope.inputObj = {};
						}
						if ($scope.dashboardAcct == '1000TD0011USD'
							|| $scope.dashboardAcct == 'LA82389'){
							nativeAlert(
									"Please select a Savings account to proceed with any transaction.",
									"Alert", defaultBtnArray);
							return;
						}
						if ($scope.viewedCustDtls && $scope.viewDtl
								|| ($("#menuTitle").text() == "Teller Admin")) {
							$(".disable-anchor").removeClass("disable-anchor");
							if ($state.current.name == "dashboard") {
								$state.go("dashboard.template");
							}
							if ($("#menuTitle").text() == "Teller Admin") {
								$state.go("dashboard." + page)/*
																 * .then(function() {
																 * 
																 * setTimeout(function() {
																 * $scope.dateInit(); },
																 * 0); })
																 */;

							} else {

								$state.go("dashboard.template." + page)/*
																		 * .then(
																		 * function() {
																		 * 
																		 * setTimeout(function() {
																		 * $scope.dateInit(); },
																		 * 0); })
																		 */;
							}
							/*
							 * $scope.navigateToPage("dashboard.template." +
							 * page, $scope[callbackFn]);
							 */
						} else {
							nativeAlert(
									"Please fill in the customer details before proceeding with any transaction.",
									"Alert", defaultBtnArray);
						}
					};

					$scope.acctIdSearch = function(id) {
						accnum = id;
						$scope.openDashboardPopup('acctIdPopup');
					}
					$scope.tellerCashTransfer = function(inputObj) {
						$scope.transactId = "M22910";
						$state
								.go(
										"tellerdashboard.template.tellercashtransfersuccess",
										{
											foo : true
										});
					}
					$scope.ddIssueSubmit = function(inputObj) {
						$scope.transactId = "M22920";
						$state.go($state.current.name + "success");

					}
					$scope.ddPaySubmit = function(inputObj) {
						$scope.transactId = "M22530";
						$state.go($state.current.name + "success");

					}
					$scope.checkDepositSubmit = function(inputObj) {
						if (inputObj.tranMode == "Check") {
							$scope.inputObj.nextDay = new Date(
									$scope.inputObj.reqExcDate).addDays(1);
							$scope.inputObj.availableOn = new Date(
									$scope.inputObj.reqExcDate).addDays(4);

							if (!(checkEmpty($scope.insDtlArr) && $scope.insDtlArr.length > 0)) {
								if (inputObj != undefined
										&& inputObj.insNumber != undefined
										&& inputObj.instrumentAmount != undefined) {
									$scope.insDtlArr.push(inputObj);
								}
							}
						}

						$state.go($state.current.name + "success");
					}
					$scope.openDenominationPopup = function(id) {
						$("#denomination").popup("destroy");
						$("#denomination").show();
						$("#denomination").popup().popup("open");
					}
					/*
					 * $scope.dateInit = function() {
					 * $("input[type='date']").attr("data-date-format",
					 * "MM-DD-YYYY"); if (!checkEmpty($scope.inputObj)) { var
					 * date = moment($scope.Date);
					 * $(".initDate").val(date.format("YYYY-MM-DD"))
					 * .trigger("change"); } else {
					 * $("input[type=date]").each(function() { var date =
					 * moment($scope.inputObj[this.id]); this.value =
					 * date.format("YYYY-MM-DD"); }); } }
					 */
					$scope.custIdSearch = function(inputObj) {
						$rootScope.flagSearcher = '';
						$scope.inputObject = {};
						// $scope.flagCust = false;
						/*
						 * if (inputObj.customerType != "" &&
						 * inputObj.customerType != undefined &&
						 * inputObj.customerType != null) {
						 */
						$scope.cType = 'Retail';
						this.openDashboardPopup('custIdPopup');
						/*
						 * } else { nativeAlert("Please select Customer Type.",
						 * "Error", defaultBtnArray); }
						 */
					};

					$scope.onCurrencyChange = function(selectedCurrency) {
						if (selectedCurrency == Data.accCurrency) {
							Data.rateVal = "1.0";
							Data.rateCode = "";
						}
					};

					$scope.fundTransferContinue = function(inputObj) {
						$rootScope.submitted = true;
						var elemname = angular.element(
								document.querySelector("form")).attr("name");
						if (this[elemname].$valid) {
							$scope.saveRecord(inputObj);
							if (this.fundSummaryObj.totalCreditAmt == this.fundSummaryObj.totalDebitAmt) {
								$state
										.go("dashboard.template.fundtransfersummary");
							} else {
								nativeAlert(
										"Total credit amount is not equal to total debit amount.Please verify.",
										"Error", defaultBtnArray);
							}
						}
					};

					$scope.saveRec = function(inputObj) {
						$rootScope.submitted = true;
						var elemname = angular.element(
								document.querySelector("form")).attr("name");
						if (this[elemname].$valid) {
							$scope.saveRecord(inputObj);
						}
					};

					$scope.saveRecord = function(inputObj) {
						delete $scope.toAccName;
						if (checkEmpty($scope.fundTransferObj[$scope.fundSummaryObj.currentRec])) {
							$scope.fundTransferObj[$scope.fundSummaryObj.currentRec] = angular
									.copy(inputObj);
							$scope.fundSummaryObj.totalCreditAmt = 0;
							$scope.fundSummaryObj.totalDebitAmt = 0;
							angular
									.forEach(
											$scope.fundTransferObj,
											function(value, index) {
												if (value.radioSel == "C") {
													// TODO - test cross curr
													/*
													 * $scope.fundSummaryObj.totalCreditAmt =
													 * $scope.fundSummaryObj.totalCreditAmt +
													 * parseInt(value.transferAmt);
													 */
													$scope.fundSummaryObj.totalCreditAmt = $scope.fundSummaryObj.totalCreditAmt
															+ parseInt(value.amtInAcctCurr);
												}
												if (value.radioSel == "D") {
													// TODO - test cross curr
													/*
													 * $scope.fundSummaryObj.totalDebitAmt =
													 * $scope.fundSummaryObj.totalDebitAmt +
													 * parseInt(value.transferAmt);
													 */
													$scope.fundSummaryObj.totalDebitAmt = $scope.fundSummaryObj.totalDebitAmt
															+ parseInt(value.amtInAcctCurr);
												}
											});
						} else {
							$scope.fundTransferObj[$scope.fundSummaryObj.fundTransferRec] = angular
									.copy(inputObj);
							$scope.fundSummaryObj.totalCreditAmt = 0;
							$scope.fundSummaryObj.totalDebitAmt = 0;
							angular
									.forEach(
											$scope.fundTransferObj,
											function(value, index) {
												if (value.radioSel == "C") {
													$scope.fundSummaryObj.numOfCredits = $scope.fundSummaryObj.numOfCredits + 1;
													// TODO - test cross curr
													/*
													 * $scope.fundSummaryObj.totalCreditAmt =
													 * $scope.fundSummaryObj.totalCreditAmt +
													 * parseInt(value.transferAmt);
													 */
													$scope.fundSummaryObj.totalCreditAmt = $scope.fundSummaryObj.totalCreditAmt
															+ parseInt(value.amtInAcctCurr);
												}
												if (value.radioSel == "D") {
													$scope.fundSummaryObj.numOfDebits = $scope.fundSummaryObj.numOfDebits + 1;
													// TODO - test cross curr
													/*
													 * $scope.fundSummaryObj.totalDebitAmt =
													 * $scope.fundSummaryObj.totalDebitAmt +
													 * parseInt(value.transferAmt);
													 */
													$scope.fundSummaryObj.totalDebitAmt = $scope.fundSummaryObj.totalDebitAmt
															+ parseInt(value.amtInAcctCurr);
												}
											});
						}
						$rootScope.submitted = "";
					};

					$scope.addRec = function(inputObj) {
						$rootScope.submitted = true;
						var elemname = angular.element(
								document.querySelector("form")).attr("name");
						// if (this[elemname].$valid) {
						$scope.saveRecord(inputObj);
						$scope.inputObj = {};
						$scope.fundSummaryObj.fundTransferRec = $scope.fundSummaryObj.fundTransferRec + 1;
						$scope.fundSummaryObj.currentRec = $scope.fundSummaryObj.fundTransferRec;
						// }
						$('input:radio').attr("checked", false).checkboxradio(
								"refresh");
						this.inputObj.accCurrency = Data.accCurrency;
						$("#instrumentType").val("");
						$("select").selectmenu("refresh", true);
					};

					$scope.deleteRec = function(index) {
						if ($scope.fundTransferObj[index + 1].radioSel == "D") {
							$scope.fundSummaryObj.numOfDebits = $scope.fundSummaryObj.numOfDebits - 1;
							/*
							 * $scope.fundSummaryObj.totalDebitAmt =
							 * $scope.fundSummaryObj.totalDebitAmt -
							 * parseInt($scope.fundTransferObj[index +
							 * 1].transferAmt);
							 */
							$scope.fundSummaryObj.totalDebitAmt = $scope.fundSummaryObj.totalDebitAmt
									- parseInt($scope.fundTransferObj[index + 1].amtInAcctCurr);
						} else if ($scope.fundTransferObj[index + 1].radioSel == "C") {
							$scope.fundSummaryObj.numOfCredits = $scope.fundSummaryObj.numOfCredits - 1;
							/*
							 * $scope.fundSummaryObj.totalCreditAmt =
							 * $scope.fundSummaryObj.totalCreditAmt -
							 * parseInt($scope.fundTransferObj[index +
							 * 1].transferAmt);
							 */
							$scope.fundSummaryObj.totalCreditAmt = $scope.fundSummaryObj.totalCreditAmt
									- parseInt($scope.fundTransferObj[index + 1].amtInAcctCurr);
						}
						$scope.fundSummaryObj.fundTransferRec = $scope.fundSummaryObj.fundTransferRec - 1;
						delete $scope.fundTransferObj[index + 1];
					};

					$scope.editRec = function(index) {
						$scope.fundSummaryObj.currentRec = index + 1;
						$scope.fundRecRecEdit = true;
						$state
								.go("dashboard.template.fundtransfer")
								.then(
										function() {
											$scope.inputObj = $scope.fundTransferObj[index + 1];
											$("#instrumentType").selectmenu(
													"refresh", true);
											setTimeout(function() {
												$("input:radio").checkboxradio(
														"refresh");
											}, 0);
										});

					};

					$scope.nextRec = function(inputObj) {
						if ($scope.fundSummaryObj.currentRec != $scope.fundSummaryObj.fundTransferRec) {
							$scope.saveRecord(inputObj);
							$scope.fundSummaryObj.currentRec = $scope.fundSummaryObj.currentRec + 1;
							$scope.inputObj = $scope.fundTransferObj[$scope.fundSummaryObj.currentRec];
						} else {
							$scope.addRec(inputObj);
						}
						setTimeout(function() {
							$("input:radio").checkboxradio("refresh");
						}, 0);

					};

					$scope.prevRec = function(inputObj) {
						$scope.saveRecord(inputObj);
						if ($scope.fundSummaryObj.currentRec >= 2) {
							$scope.fundSummaryObj.currentRec = $scope.fundSummaryObj.currentRec - 1;
							$scope.inputObj = $scope.fundTransferObj[$scope.fundSummaryObj.currentRec];
						}
						setTimeout(function() {
							$("input:radio").checkboxradio("refresh");
						}, 0);
					};

					$scope.fundtransferSubmit = function() {
						/*
						 * var successObj = { "page" : "fundTransfer", "amt" :
						 * JSON
						 * .stringify($scope.fundSummaryObj.totalCreditAmt),
						 * "hrs" : new Date().getHours() }; var a = {
						 * "fundTransfer" : JSON
						 * .stringify($scope.fundTransferObj), "page" :
						 * "fundTransfer" }; invokeTellerProcedure(a,
						 * successObj, transactionSuccessRespHandler);
						 */
						if ($scope.fundSummaryObj.totalCreditAmt == 0
								|| $scope.fundSummaryObj.totalDebitAmt == 0) {

							nativeAlert(
									"Total credit amount and total debit amount should not be zero.Please verify.",
									"Error", defaultBtnArray);

						}

						else if (this.fundSummaryObj.totalCreditAmt == this.fundSummaryObj.totalDebitAmt) {

							$state.go($state.current.name + "success");

						} else {
							nativeAlert(
									"Total credit amount is not equal to total debit amount.Please verify.",
									"Error", defaultBtnArray);
						}

					};

					$scope.fundTransferSuccessBackBtn = function() {
						this
								.navigateToPage(
										'dashboard.template.fundtransfer')
								.then(
										function() {
											$scope.inputObj = $scope.fundTransferObj[$scope.fundSummaryObj.currentRec];
										});
					};

					$scope.navToFundTransfer = function() {
						$scope.resetFundTransferScope();
						$scope.navigate('fundtransfer');
					};

					$scope.resetFundTransferScope = function() {
						$scope.fundRecRecEdit = "";
						$scope.fundTransferObj = {};
						$scope.fundSummaryObj = {
							fundTransferRec : 1,
							currentRec : 1,
							totalCreditAmt : 0,
							totalDebitAmt : 0,
							numOfDebits : 0,
							numOfCredits : 0
						};
						$scope.sel = "";
					};

					/* View Details Start */
					function processViewDtlsSubmit() {

						viewDtlsSuccessRespHandler();
						// invokeViewDetails(viewDtlsSuccessRespHandler);
					}

					function viewDtlsSuccessRespHandler() {// result) {

						// WL.Logger.debug("Service Result::"+
						// JSON.stringify(result));
						delete $scope.loading;

						/*
						 * if (isServiceResponseValid(result)) { var
						 * serviceExecCode =
						 * result.invocationResult.serviceStatus.serviceStatusCode;
						 * if (serviceExecCode == SERVICE_RESPONSE_CODE_SUCCESS) {
						 */

						$scope.viewDtl = {};
						/*
						 * if (result.invocationResult.responseData != null) {
						 * populateCustDetails(result.invocationResult.responseData); }
						 */
						populateCustDetails(); // Remove if uncommmenting other
						// code::LINMOY
						var jsonString = '{ "page":"signature", "accNumber":"'
								+ Data.accNumb + '","defaultAccNum":"'
								+ Data.accNumb + '"}';
						// TODO - comment n uncomment - simran
						$scope.viewedCustDtls = true;
						/*
						 * $scope.$apply();
						 * 
						 * invokeMBProcedure(JSON.parse(jsonString),
						 * signatureSuccessRespHandler); } else if
						 * ($scope.viewDtl != "" && $scope.viewDtl != undefined) {
						 * delete $scope.viewDtl; $scope.viewedCustDtls = true;
						 * $scope.$apply(); } else { $scope.viewedCustDtls =
						 * true; $scope.$apply(); } }
						 */
					}

					function signatureSuccessRespHandler(data) {

						busyIndicator.hide();
						if (data.invocationResult.responseData != null
								&& data.invocationResult.responseData != null
								&& data.invocationResult.responseData.SigInqRs != null
								&& data.invocationResult.responseData.SigInqRs.signatureData != null) {
							$scope.viewDtl.custImgSrc = data.invocationResult.responseData.SigInqRs.signatureData.returnedPhotograph;
							$scope.viewDtl.signSrc = data.invocationResult.responseData.SigInqRs.signatureData.returnedSignature;
							$scope.viewedCustDtls = true;
							$scope.$apply();
							if ($scope.role == "R") {
								$state.go("custAnalytics");
							}
						}

					}

					function populateCustDetails() {// resp) {

						var accCurrency = 'USD';
						if ($scope.Data.accNumb == "1000TD0011USD") {
							tdClosureAccountDetailsSuccessHandler();
							$scope.viewDtl = $scope.tdClosureObjComp[0];
							/*
							 * $scope.viewDtl.netIntRate = "6.0";
							 * $scope.viewDtl.intAmt = "123.00";
							 * $scope.viewDtl.maturityAmt = "2000.00";
							 * $scope.viewDtl.depAmt = "2123.00";
							 * $scope.viewDtl.accOpenDt = 'Sep 17, 2014';
							 * $scope.viewDtl.maturityDt = 'Sep 17, 2015';
							 * $scope.viewDtl.depTerm = '12 months';
							 * $scope.viewDtl.custId = 'RET0001';
							 * $scope.viewDtl.name = 'Mr. Adrian Desouza';
							 */
						} else {
							$scope.viewDtl.freezeStat = "NA";
							$scope.viewDtl.acctStat = "Active";
							$scope.viewDtl.custId = 'CIF20150128085721';
							$scope.viewDtl.name = 'Mr. Steve Robin';
							$scope.viewDtl.operationMod = "Primary Account Holder";
							if ($scope.Data.accNumb == "3200SB1784569045") {
								$scope.viewDtl.ledgerBal = 206.00;
								$scope.viewDtl.availBal = 206.00;
								$scope.viewDtl.effAvailBal = 206.00;
								$scope.viewDtl.accOpenDt = 'Nov 24, 2016';
							} else if ($scope.Data.accNumb == "3200CA1789654123") {
								$scope.viewDtl.ledgerBal = 35006.39;
								$scope.viewDtl.availBal = 35006.39;
								$scope.viewDtl.effAvailBal = 35006.39;
								$scope.viewDtl.accOpenDt = 'Jan 16, 2017';
							} /*
								 * else if ($scope.Data.accNumb == "SB123") {
								 * $scope.viewDtl.ledgerBal = 206.39;
								 * $scope.viewDtl.availBal = 206.39;
								 * $scope.viewDtl.effAvailBal = 206.39;
								 * $scope.viewDtl.accOpenDt = 'Jan 10, 2013'; }
								 */else {
								$scope.viewDtl.ledgerBal = 25506.39;
								$scope.viewDtl.availBal = 25506.39;
								$scope.viewDtl.effAvailBal = 25506.39;
								$scope.viewDtl.accOpenDt = 'Oct 31, 2013';
							}
						}
						$scope.viewDtl.currentRec = 1;
						$scope.viewDtl.img = "images/user-2.jpg";
						$scope.viewDtl.sign = "images/signature.jpg";
					}
					$scope.jointclick = function(resp) {
						$scope.visibleSign = false;
						if (($scope.viewDtl.name == "Mr. Steve Robin")
								|| ($scope.viewDtl.name == "Mr. Adrian Desouza")) {
							$scope.viewDtl.operationMod = "Joint Account Holder";
							$scope.viewDtl.name = "Ms. Regina Grey";
							$scope.viewDtl.img = "images/user-1.png";
							$scope.viewDtl.sign = "images/sign_2.jpg";
							$scope.viewDtl.currentRec = 2;
						} else if ($scope.viewDtl.name == "Ms. Regina Grey") {
							$scope.viewDtl.operationMod = "Primary Account Holder";
							$scope.viewDtl.name = "Mr. Steve Robin";
							$scope.viewDtl.img = "images/user-2.png";
							$scope.viewDtl.sign = "images/signature.png";
							$scope.viewDtl.currentRec = 1;
						}
					}

					/* View Dtls end */
					function printSuccessRespHandler(result) {
						var win = window.open(
								result.invocationResult.responseData, '_blank');
						// win.focus();

					}

					// Common handler for teller's transactions
					function transactionSuccessRespHandler(result) {

						var elemname = result.invocationContext.successObj.page;
						/*
						 * if (elemname != "standingorder" && elemname !=
						 * "chequeBookIssue" && elemname != "stopCheque" &&
						 * elemname != "chequeStatus" && elemname != "tdClosure" &&
						 * elemname != "loanAccountInquiry" && elemname !=
						 * "tdModelling" && elemname != "statementEnquiry" &&
						 * elemname != "ddIssue") {
						 */
						if (elemname == "cashDeposit"
								|| elemname == "cashWithdrawal"
								|| elemname == "fundTransfer"
								|| elemname == "paymentOrder") {
							var transactionAmount = result.invocationContext.successObj.amt;
							var tranTime = result.invocationContext.successObj.hrs;
							$localStorage["t" + tranTime][elemname].transactAmt = $localStorage["t"
									+ tranTime][elemname].transactAmt
									+ parseInt(transactionAmount);
							$localStorage["t" + tranTime][elemname].noOfTransact = $localStorage["t"
									+ tranTime][elemname].noOfTransact + 1;
						}
						if (isServiceResponseValid(result)) {
							$scope.errorMsgDesc = "";
							if (result.invocationResult.serviceStatus.serviceStatusCode == "1") {
								if (result.invocationResult.serviceStatus.serviceStatusDesc != null) {
									$scope.errorMsgDesc = result.invocationResult.serviceStatus.serviceStatusDesc;
									$state.go($state.current.name + "success",
											{
												foo : true
											});
								}
							} else {
								if ($state.current.name == "dashboard.template.fundtransfersummary") {
									try {
										$scope.transactId = (result.invocationResult.responseData.TransferTranOutputStruct.transferTranDetail.tranIdentifierTransfer.tranId)
												.trim();
									} catch (Exception) {

									}
								}

								else if ($state.current.name == "dashboard.template.deposit") {
									try {
										$scope.transactId = result.invocationResult.responseData.CreditAddRs.TrnId;
									} catch (Exception) {

									}
								} else if ($state.current.name == "dashboard.template.withdrawal") {
									try {
										$scope.transactId = result.invocationResult.responseData.DebitAddResponse.DebitAddRs.TrnId;
									} catch (Exception) {

									}
								} else if ($state.current.name == "dashboard.template.paymentorder") {
									try {
										$scope.transactId = result.invocationResult.responseData.AddOutboundPymtEntryDtlsRs.PymtReferenceNumber;
									} catch (Exception) {

									}
								} else if ($state.current.name == "dashboard.template.ddissue") {
									try {
										$scope.transactId = result.invocationResult.responseData.doDDRequestResponse.DDReqOutputVO;
									} catch (Exception) {

									}
								} else if ($state.current.name == "dashboard.template.tdclosure") {
									try {
										// TODO fetch transact id
										$scope.transactId = result.invocationResult.responseData.DepAcctCloseResponse.DepAcctCloseRs.TrnDetailsRec.TrnId;
									} catch (Exception) {

									}
								} else if ($state.current.name == "dashboard.template.stopcheque") {
									try {
										$scope.chqStatus = result.invocationResult.responseData.StopChkAddRs.ChkStatusRec.ChkStatus;
										$scope.transactId = result.invocationResult.responseData.StopChkAddRs.RefNum;
									} catch (Exception) {

									}
								} else if ($state.current.name == "dashboard.template.loanaccountenquiry") {
									try {
										$scope.loanAcctDt = result.invocationResult.responseData.LoanAcctInqRs;
									} catch (Exception) {

									}
								} else if ($state.current.name == "dashboard.template.tdmodelling") {
									try {
										$scope.interestRate = result.invocationResult.responseData.DepModelOutStruct.interestRate;
										$scope.interestAmt = result.invocationResult.responseData.DepModelOutStruct.interestAmount;
									} catch (Exception) {

									}
								}
								if (elemname != "standingOrder"
										&& elemname != "paymentOrder"
										&& elemname != "chequeStatus"
										&& elemname != "loanAccountInquiry"
										&& elemname != "tdModelling") {
									invokeViewDetails(updateBalanceDetailsHandler);
								}
								$scope.navigateToPage($state.current.name
										+ "success");
							}
							$scope.$apply();

						} else {
							$('.data-loading').removeClass("no-display");
							$(".loading-start").addClass("no-display");
						}
					}

					function invokeViewDetails(successHandler) {

						var jsonString = '{ "page":"viewDetails", "accNumber":"'
								+ Data.accNumb
								+ '","defaultAccNum":"'
								+ Data.accNumb + '"}';
						invokeMBProcedure(JSON.parse(jsonString),
								successHandler);
					}

					function invokeAccountDetails(toAcc, successHandler) {

						var jsonString = '{ "page":"viewDetails", "accNumber":"'
								+ toAcc + '","defaultAccNum":"' + toAcc + '"}';
						invokeMBProcedure(JSON.parse(jsonString),
								successHandler);
					}

					function updateBalanceDetailsHandler(data) {

						var resp = data.invocationResult.responseData;
						var inqResp = resp.AcctInqRs;
						updateBalances(inqResp);
					}

					function updateBalances(inqResp) {

						var balArr = inqResp.AcctBal;
						var accCurrency = inqResp.AcctId.AcctCurr + " ";
						for (arr in balArr) {
							if (balArr[arr].BalType == "LEDGER") {
								$scope.viewDtl.ledgerBal = $filter('currency')(
										balArr[arr].BalAmt.amountValue,
										accCurrency, 2)
										+ " " + balArr[arr].CrDrInd + "r.";
							}
							if (balArr[arr].BalType == "AVAIL") {
								$scope.viewDtl.availBal = $filter('currency')(
										balArr[arr].BalAmt.amountValue,
										accCurrency, 2)
										+ " " + balArr[arr].CrDrInd + "r.";
							}
							if (balArr[arr].BalType == "EFFAVL") {
								$scope.viewDtl.effAvailBal = $filter('currency')
										(balArr[arr].BalAmt.amountValue,
												accCurrency, 2)
										+ " " + balArr[arr].CrDrInd + "r.";
							}
						}
						$scope.$apply();
					}

					function toAccountDetailsSuccessHandler(result) {

						resp = result.invocationResult.responseData;
						if (resp != null && resp.AcctInqRs != null) {
							var inqResp = resp.AcctInqRs;
							$scope.toAccName = inqResp.CustId.PersonName.TitlePrefix
									+ " " + inqResp.CustId.PersonName.Name;
							$scope.toAccCurrency = inqResp.AcctId.AcctCurr;
							$scope.$apply();
						} else {
							delete $scope.toAccName;
							delete $scope.toAccCurrency;

						}
					}
					$scope.openDashboardPopup = function(popupId) {
						delete $scope.custId;
						$scope.swapPopup(popupId);
						openPopup("acctIdPopup");
						// $scope.flagAcct = false;
						$scope.inputObject = {};
						// $scope.flagCust = false;
						$rootScope.flagSearcher = '';
					};

					$scope.openTransIDPopup = function(popupId) {
						$("#transIdPopup").show();
						$("#transIdPopup").popup().popup("open");
					}
					function statementEnquirySuccessHandler() {// result) {
						/*
						 * if (isServiceResponseValid(result)) {
						 * $('.data-loading').removeClass("no-display");
						 * $(".loading-start").addClass("no-display");
						 * $scope.errorMsgDesc = ""; if
						 * (result.invocationResult.serviceStatus.serviceStatusCode ==
						 * "1") { delete $scope.transactDtls; if
						 * (result.invocationResult.serviceStatus.serviceStatusDesc !=
						 * null) { nativeAlert(
						 * result.invocationResult.serviceStatus.serviceStatusDesc,
						 * "Error", defaultBtnArray); } } else {
						 */
						$scope.transactDtls = getTransactionDtls(); // result.invocationResult.responseData.AccountStatement.transactionDetails;
						/*
						 * $scope.$apply(); } }
						 */
					}

					function searchEnquirySuccessHandler(result) {
						if (isServiceResponseValid(result)) {
							$('.data-loading').removeClass("no-display");
							$(".loading-start").addClass("no-display");
							$scope.errorMsgDesc = "";
							if (result.invocationResult.serviceStatus.serviceStatusCode == "1") {
								if (result.invocationResult.serviceStatus.serviceStatusDesc != null) {
									nativeAlert(
											result.invocationResult.serviceStatus.serviceStatusDesc,
											"Error", defaultBtnArray);
									delete $scope.inputObject;
								}
							} else {
								if (result.invocationContext.searchType == "bic") {
									$scope.bicList = result.invocationResult.responseData.BICInqRs;
								} else if (result.invocationContext.searchType == "custid") {
									$scope.custList = convertToArray(result.invocationResult.responseData.CustListInqRs.CustomerListRec);
								} else if (result.invocationContext.searchType == "exchangeRate") {
									$scope.rateVal = result.invocationResult.responseData.ExchangeRateForRateCodeOutputVO.varCrncyUnits;
								} else if (result.invocationContext.searchType == "customerAcct") {
									var accList = result.invocationResult.responseData.CustAcctInqRs.CustAcctRec;
									var sbaList = [], caaList = [], laaList = [], ccaList = [], odaList = [], tdaList = [];
									for ( var i in accList) {
										if (accList[i].ProductInfo.ProductCategory == "SBA") {
											sbaList.push(accList[i].AcctId);
										} else if (accList[i].ProductInfo.ProductCategory == "CCA") {
											ccaList.push(accList[i].AcctId);
										} else if (accList[i].ProductInfo.ProductCategory == "CAA") {
											caaList.push(accList[i].AcctId);
										} else if (accList[i].ProductInfo.ProductCategory == "LAA") {
											laaList.push(accList[i].AcctId);
										} else if (accList[i].ProductInfo.ProductCategory == "ODA") {
											odaList.push(accList[i].AcctId);
										} else if (accList[i].ProductInfo.ProductCategory == "TDA") {
											tdaList.push(accList[i].AcctId);
										}
									}
									$scope.accountsList = {
										"sbaList" : sbaList,
										"caaList" : caaList,
										"ccaList" : ccaList,
										"tdaList" : tdaList,
										"laaList" : laaList,
										"odaList" : odaList
									};
								} else if (result.invocationContext.searchType == "acctid") {
									// TODO - handle success scenario for acct
									// id searcher
									if (result.invocationResult.responseData.CustomerAcctInquiryOutputVO.numOfAccounts) {
										$scope.numOfAccounts = 0;
									}
								}
								$scope.$apply();
							}
						}
					}
					;

					$scope.selectViewDtlsRadio = function() {
						delete this.accountsList;
						delete $scope.flagCust;
						delete $scope.custId;
						var id = "";
						if (this.custDtlsRadio == "choice-2") {
							delete $scope.cType;
							this.inputObject.customerType = "";
							this.actType = "";
							// delete $scope.accountsList;
							delete $scope.custList;
							this.Data.dashAcctNum = "";
							id = "acct";
						} else if (this.custDtlsRadio == "choice-3") {
							$("select").selectmenu("refresh", true);
							id = 'cust';
						} else if (this.custDtlsRadio == "choice-1") {
							delete $scope.cType;
							this.inputObject.customerType = "";
							// delete $scope.accountsList;
							delete $scope.custList;
							this.actType = "";
							this.Data.dashAcctNum = "";
							id = "card";
						} else if (this.custDtlsRadio == "choice-4") {
							delete $scope.cType;
							this.inputObject.customerType = "";
							// delete $scope.accountsList;
							delete $scope.custList;
							this.actType = "";
							this.Data.dashAcctNum = "";
							id = "nic";
						}
						$scope.viewDtlTab = id;
						$("input:text").val("");
						selectRadio(id);
					};

					$scope.statmentEnqRadioBtnClick = function(radioId) {
						delete $scope.transactDtls;
						$("input:text:enabled").val("");
						$('input[type="date"]').val("");
						$("select").val("");
						$("select").selectmenu("refresh", true);
						/* $("select").trigger("change"); */
						selectRadio(radioId);
						$scope.statementDiv = radioId;
					};

					$scope.tdClosureExchangeRateEnable = function() {
						if (this.inputObj.closureMode == "C") {
							if (this.inputObj.cashCurrency != this.Data.accCurrency) {
								$scope.showExchangeRatePopup();
							}
						} else if (this.inputObj.closureMode == "Y") {
							if (this.toAccCurrency != undefined
									&& this.toAccCurrency != this.Data.accCurrency) {
								$scope.showExchangeRatePopup();
							}
						}
					};

					$scope.singleFundtransferSubmit = function(inputObj) {
						/*
						 * $scope.inputObj.accountNumber =
						 * inputObj.accountNumber;
						 * $scope.inputObj.accountNumberTo =
						 * inputObj.accountNumberTo;
						 */
						// $state.go($state.current.name + "success");
						$rootScope.submitted = true;
						var elemname = angular.element(
								document.querySelector("form")).attr("name");
						if (this[elemname].$valid) {

							if (($scope.inputObj.index) != undefined) {
								$scope.ownFundTransfer(inputObj,
										$scope.inputObj.index);

							} else {
								$scope.ownFundTransfer(inputObj);
							}
							$state.go($state.current.name + "summary").then(
									function() {
										delete $scope.inputObj.index;
									});
						}
					};

					$scope.tdClosureHomeSubmit = function(accNum) {
						// $scope.invokeAccountDetails(accNum,
						tdClosureAccountDetailsSuccessHandler(accNum);// );
						$state.go('dashboard.template.tdclosuredetail');
					};

					function tdClosureAccountDetailsSuccessHandler(result) {
						/*
						 * WL.Logger.debug("populateCustDetails"); resp =
						 * result.invocationResult.responseData; if
						 * (checkEmpty(resp) && checkEmpty(resp.AcctInqRs)) {
						 * 
						 * var res = resp.AcctInqRs;
						 */
						$scope.tdClosureObjComp = [];
						// if (result == "TD123") {
						var date = new Date();
						var currentDt = ('0' + (date.getDate() + 1)).slice(-2)
								+ '/' + ('0' + (date.getMonth() + 1)).slice(-2)
								+ '/' + date.getFullYear();
						var prevDt = ('0' + (date.getDate() + 1)).slice(-2)
								+ '/' + ('0' + (date.getMonth() + 1)).slice(-2)
								+ '/' + (date.getFullYear() - 3);
						var a = {
							depositAccountNumber : "TD1234",
							accCurrency : "USD",
							name : "Mr. Steve Robin",
							/*
							 * accOpenDate : "2014-02-18T00:00:00.000",
							 * maturityDate : "2017-02-18T00:00:00.000",
							 */
							accOpenDate : new Date(new Date()
									.setFullYear(new Date().getFullYear() - 3)),
							maturityDate : new Date(),
							depositAmount : "1,00,000.0",
							intrestAmt : "19,561.82",
							maturityAmt : "1,19,561.82",
							custId : "CIF20150128085721",
							operationMod : "Single",
							depTerm : "12 months",
							netIntRate : "6.0"
						};
						$scope.tdClosureObjComp.push(a);
						// } else {
						var a = {
							depositAccountNumber : "TD8939",
							accCurrency : "USD",
							name : "Mr. Steve Robin",
							/*
							 * accOpenDate : "2014-02-18T00:00:00.000",
							 * maturityDate : "2017-02-18T00:00:00.000",
							 */
							accOpenDate : new Date("2013-02-18"),
							maturityDate : new Date("2016-02-18"),
							depositAmount : "1,00,000.0",
							intrestAmt : "19,561.82",
							maturityAmt : "1,19,561.82"
						};
						$scope.tdClosureObjComp.push(a);
						// }
						// }
					}

					$scope.tdTrailClosureSubmit = function(tdClosureObj) {
						$rootScope.submitted = true;
						var elemname = angular.element(
								document.querySelector("form")).attr("name");
						// if (this[elemname].$valid) {

						// }
					};

					$scope.trailCloseClick = function(inputObj) {

						/*
						 * $scope.tdClosureObj.repaymentAccountNumber =
						 * inputObj.repaymentAccountNumber;
						 * $scope.tdClosureObj.cashCurrency =
						 * inputObj.cashCurrency;
						 * $scope.tdClosureObj.closureMode =
						 * inputObj.closureMode;
						 * $scope.tdClosureObj.amtToBePaidFlag =
						 * inputObj.withdrawalType;
						 * $scope.tdClosureObj.closureReasonCode =
						 * inputObj.closureReasonCode;
						 * $scope.tdClosureObj.remarks = inputObj.remarks;
						 * $scope.tdClosureObj.valueDate = inputObj.valueDate;
						 * $scope.tdClosureObj.withdrawalType =
						 * inputObj.withdrawalType;
						 * 
						 * alert(JSON.stringify($scope.tdClosureObj));
						 * 
						 * $scope.tdClosureObj.page = "tdTrailClosure";
						 * 
						 * invokeTellerProcedure($scope.tdClosureObj,
						 */
						tdTrailClosureSuccessHandler();// );

					};

					function tdTrailClosureSuccessHandler(result) {

						$state.go('dashboard.template.tdtrailclosure');

					}

					$scope.showSignature = function() {
						$scope.visibleSign = true;
					};
					$scope.hideSignature = function() {
						$scope.visibleSign = false;
					};

					// Graphs - start
					var cashdata = {
						"xData" : [ "09:00AM", "11:00AM", "01:00PM", "03:00PM",
								"05:00PM" ],
						"yData" : [ /*
									 * { "name" : "Opening Cash", "data" : [
									 * 8000, 0, 0, 0, 0 ] },
									 */{
							"name" : "Cash Deposit",
							"data" : [ 1000, 720, 8000, 322, 3900 ]
						}, {
							"name" : "Cash Withdrawal",
							"data" : [ 767, 1000, 3333, 3330, 899 ]
						} ]
					};

					$scope.cashChartYData = cashdata.yData;
					$scope.cashChartXData = cashdata.xData;
					/*
					 * var dep = $(".highcharts-legend-item
					 * tspan")[1].textContent.replace(/[^0-9]/g, ''); var withdr =
					 * $(".highcharts-legend-item
					 * tspan")[2].textContent.replace(/[^0-9]/g, ''); var open =
					 * $(".highcharts-legend-item
					 * tspan")[0].textContent.replace(/[^0-9]/g, '');
					 */
					/*
					 * var dep = 139442; var withdr = 93295; var open = 8000;
					 * var netCashBal = dep+open - withdr;
					 * alert("netCashBal"+netCashBal);
					 */
					var catdata = {
						"xData" : [ "09:00AM", "11:00AM", "01:00PM", "03:00PM",
								"05:00PM" ],
						"yData" : [ {
							"name" : "Cash Deposit",
							"data" : [ 1, 3, 15, 7, 18 ]
						}, {
							"name" : "Cash Withdrawal",
							"data" : [ 31, 4, 18, 9, 21 ]
						}, {
							"name" : "Fund Transfer",
							"data" : [ 15, 4, 7, 21, 5 ]
						}, {
							"name" : "Payment Order",
							"data" : [ 12, 7, 3, 2, 12 ]
						} ]
					};
					$scope.catChartYData = catdata.yData;
					$scope.catChartXData = catdata.xData;
					// Graphs - end
					$scope.settingsClick = function() {
						$("#settingsPopup").show();
						$("#settingsPopup").popup().popup("open", {
							positionTo : '#settings'
						});
					};

					$scope.managePassword = function() {
						$("#settingsPopup").popup("close");
						$("#manageOfflinePass").show();
						$("#manageOfflinePass").popup().popup("open");
					};
					$scope.changeOpeningBal = function() {
						$("#settingsPopup").popup("close");
						$("#openingBal").show();
						$("#openingBal").popup().popup("open");
					};
					$scope.setOpeningBalance = function(bal) {
						$scope.openingBalance = bal;
						closePopup("openingBal");
					}
					$scope.submitOfflinePassClick = function() {
						closePopup("manageOfflinePass");
					}

					$scope.viewMoreDtls = function() {
						$rootScope.submitted = "";
						$("#more-details").hide();
						$("#less-details").show();
						$(".viewDetailsBalInq").show();
						$(".ui-grid-solo.acc-details:first").addClass(
								"addShadowToMainViewDtlsDiv");
						$(".ui-grid-solo.acc-details").addClass(
								"addShadowToViewDtlsDiv");
						var balDtls = {};
						var cur = "USD";
						balDtls.clrbal = "0";
						balDtls.clrbalCurr = cur;
						balDtls.sanlim = "212,634";
						balDtls.sanlimCurr = cur;
						balDtls.drwpwr = "0";
						balDtls.drwpwrCurr = cur;
						balDtls.utlamt = "0";
						balDtls.utlamtCurr = cur;
						balDtls.dacc = "0";
						balDtls.daccCurr = cur;
						balDtls.lien = "100";
						balDtls.lienCurr = cur;
						balDtls.efuavl = "212,534";
						balDtls.efuavlCurr = cur;
						balDtls.float = "0";
						balDtls.floatCurr = cur;
						balDtls.unclrbal = "0";
						balDtls.unclrbalCurr = cur;
						balDtls.dafalm = "0";
						balDtls.dafalmCurr = cur;
						balDtls.futbal = "0";
						balDtls.futbalCurr = cur;
						$scope.balDtls = balDtls;
						$scope.transactDtls = getMiniTransactionDtls();
					};

					$scope.viewLessDtls = function() {
						$rootScope.submitted = "";
						$("#more-details").show();
						$("#less-details").hide();
						$(".viewDetailsBalInq").hide();
						$(".ui-grid-solo.acc-details:first").removeClass(
								"addShadowToMainViewDtlsDiv");
						$(".ui-grid-solo.acc-details").removeClass(
								"addShadowToViewDtlsDiv");
					};

					$state.get("dashboard.template.fundtransfer").onEnter = function() {
						if ($scope.fundRecRecEdit != true) {
							$scope.resetFundTransferScope();
						} else {
							$scope.fundRecRecEdit = "";
						}
					};
					$scope.processTransDetails = function(inputObj) {
						$scope.detailsOnTransID = getDetailsOnTransID();
					}
					$scope.searchOnTransId = function(inputObj) {
						$scope.transIDDetails = gettransIDDetails();
					}

					$scope.initDenoPopup = function() {
						$("#denomination").popup("destroy");
						$("#denomination").popup().popup("open");
						$("#denomination").popup('close');
					}

					// ctr - start
					$scope.openCtr = function(index) {
						$("#ctr").popup("destroy");
						$("#ctr").show();
						$("#ctr").popup().popup("open");
						$scope.ctrPage = "1";
						if (index != null && index != undefined
								&& checkEmpty($scope.ctrObj[index])) {
							$scope.ctrInputObj = $scope.ctrObj[index];
						} else {
							$scope.ctrInputObj = {};
						}
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
						}, 0);
					};
					$scope.pageChangeCtr = function(val) {
						$scope.ctrPage = val;
					}
					$scope.closeCtr = function() {
						$scope.ctrPage = "1";
						closePopup("ctr");
						if ($scope.ctrInputObj.entityType == $scope.ctrObj[0].entityType) {
							$scope.ctrObj[0] = $scope.ctrInputObj;
						} else if ($scope.ctrInputObj.entityType == $scope.ctrObj[1].entityType) {
							$scope.ctrObj[1] = $scope.ctrInputObj;
						}
						$scope.ctrInputObj = {};
						// $scope.inputObj[$scope.ctrInputObj.entityType] =
						// $scope.ctrInputObj;
					};

					$scope.openCtrDetails = function(inputObj) {
						if ($scope.inputObj.isCtr != true) {
							$scope.invokeFetchCtrDetails(inputObj);
						} else {
							delete $scope.ctrObj;
						}
					}

					$scope.invokeFetchCtrDetails = function(inputObj) {
						var customDataObj = {};
						/*
						 * if ($state.current.name ==
						 * "dashboard.template.withdrawal") { customDataObj = {
						 * "serial_num_1" : "1", "srlNum_1" : "2", "entityId_1" :
						 * "CIF20150128085721", "entityType_1" : "COND",
						 * "transactionAmt_1" : "0", "taxId_1" : "987765654",
						 * "address1_1" : "LINE1", "city_1" : "27042",
						 * "cityDesc_1" : "MANKATO", "state_1" : "KS",
						 * "stateDesc_1" : "KANSAS", "country_1" : "US",
						 * "countryDesc_1" : "UNITED STATES", "postalCode_1" :
						 * "56001", "dateOfBirth_1" : new Date(
						 * "1960-09-01T00:00:00.000"), "documentType_1" : "DL",
						 * "documentTypeDesc_1" : "DRIVERS LICENSE",
						 * "documentNo_1" : "87765654", "docExpDate_1" : new
						 * Date( "2099-12-31T00:00:00.000"), "firstName_1" :
						 * "STEVE", "lastName_1" : "ROBIN" }; var obj1 = {}; for (
						 * var key in customDataObj) { if (/_[1]/.test(key)) {
						 * obj1[key.replace("_1", "")] = customDataObj[key]; } }
						 * $scope.ctrObj = [ obj1 ]; } else {
						 */
						customDataObj = {
							"serial_num_0" : "0",
							"srlNum_0" : "1",
							"entityId_0" : "CIF20150128085721",
							"entityType_0" : "BENF",
							"transactionAmt_0" : "0",
							"taxId_0" : "987765654",
							"address1_0" : "LINE1",
							"city_0" : "27042",
							"cityDesc_0" : "MANKATO",
							"state_0" : "KS",
							"stateDesc_0" : "KANSAS",
							"country_0" : "US",
							"countryDesc_0" : "UNITED STATES",
							"postalCode_0" : "56001",
							"dateOfBirth_0" : new Date(
									"1960-09-01T00:00:00.000"),
							"documentType_0" : "DL",
							"documentTypeDesc_0" : "DRIVERS LICENSE",
							"documentNo_0" : "87765654",
							"docExpDate_0" : new Date("2099-12-31T00:00:00.000"),
							"firstName_0" : "STEVE",
							"lastName_0" : "ROBIN",
							"serial_num_1" : "1",
							"srlNum_1" : "2",
							"entityId_1" : "CIF20150128085721",
							"entityType_1" : "COND",
							"transactionAmt_1" : "0",
							"taxId_1" : "987765654",
							"address1_1" : "LINE1",
							"city_1" : "27042",
							"cityDesc_1" : "MANKATO",
							"state_1" : "KS",
							"stateDesc_1" : "KANSAS",
							"country_1" : "US",
							"countryDesc_1" : "UNITED STATES",
							"postalCode_1" : "56001",
							"dateOfBirth_1" : new Date(
									"1960-09-01T00:00:00.000"),
							"documentType_1" : "DL",
							"documentTypeDesc_1" : "DRIVERS LICENSE",
							"documentNo_1" : "87765654",
							"docExpDate_1" : new Date("2099-12-31T00:00:00.000"),
							"firstName_1" : "STEVE",
							"lastName_1" : "ROBIN"
						};
						var obj0 = {}, obj1 = {};
						for ( var key in customDataObj) {
							if (/_[0]/.test(key)) {
								obj0[key.replace("_0", "")] = customDataObj[key];
							}
							if (/_[1]/.test(key)) {
								obj1[key.replace("_1", "")] = customDataObj[key];
							}
						}
						$scope.ctrObj = [ obj0, obj1 ];
						$scope.$apply();
						// }
					}
					// ctr end

					// deno start
					$scope.openDenominationPopup = function(id) {
						$("#denomination").popup("destroy");
						$("#denomination").show();
						$("#denomination").popup().popup("open");
					}

					$scope.conductorBeneficiaryRadioBtnChange = function(
							radioVal, correspTxtId, custFieldId) {
						if (radioVal == "Y") {
							$scope.inputObj[correspTxtId] = $scope.viewDtl.custId;
							$scope[custFieldId] = $scope.viewDtl.name;
						} else {
							$scope.inputObj[correspTxtId] = "";
							$scope[custFieldId] = "";
						}
						refreshRadio();
					}
					$scope.openProdCodePopup = function() {
						$("#productCodePopup").popup("destroy");
						$("#productCodePopup").show();
						$("#productCodePopup").popup().popup("open");
					}

					$scope.closeProdCode = function() {
						closePopup("productCodePopup");
					}
					$scope.selectProductCode = function() {
						$scope.inputObj.productCode = $scope.inputObj.row;
						closePopup("productCodePopup");
					}
					$scope.denominationSubmit = function(inputObj) {
						if ($state.current.name == "dashboard.tellercashtovault") {

							if (inputObj.systemClosingBal < inputObj.physicalClosingBal) {
								$scope.inputObj.excessAmt = inputObj.physicalClosingBal
										- inputObj.systemClosingBal;
								$scope.inputObj.excessAmt = $scope.inputObj.excessAmt
										+ "";
								$scope.inputObj.shortAmt = 0.00;
							} else if (inputObj.systemClosingBal > inputObj.physicalClosingBal) {
								$scope.inputObj.shortAmt = inputObj.systemClosingBal
										- inputObj.physicalClosingBal;
								$scope.inputObj.shortAmt = $scope.inputObj.shortAmt
										+ "";
								$scope.inputObj.excessAmt = 0.00;
							}
						}

					}
					// deno end
					// sasi

					$scope.subTypes = getTransactionSubtype();
					var transactionAmount;
					var depositAmt;
					var netAmount;
					$scope.openCtrDetailsStub = function(inputObj) {
						if (inputObj.isCtr == undefined
								|| inputObj.isCtr == false) {
							inputObj = {
								"conductorid" : "USCIF6",
								"lessCashInitiatorId" : "",
								"beneficiaryIdTrans" : "",
								"physicalClosingBal" : 0,
								"accountNumber" : "20000000000003815",
								"accCurrency" : "USD",
								"valueDate" : "2015-06-23T05:00:00.000Z",
								"sourceOfFunds" : "",
								"isConductorOwner" : true,
								"beneficiaryid" : "USCIF6",
								"partTranType" : "C",
								"loose100" : 0,
								"loose50" : 0,
								"loose20" : 0,
								"loose10" : 0,
								"loose5" : 0,
								"loose2" : 0,
								"loose1" : 0,
								"loosec1" : 0,
								"loose050" : 0,
								"loose025" : 0,
								"loose010" : 0,
								"loose005" : 0,
								"loose001" : 0,
								"cname" : "ADAM D",
								"sourceOfFundsDesc" : "",
								"isCondOwnerOfAccAndBen" : true,
								"page" : "custFetchCTR",
								"userId" : "MBUSER1"
							};
							$scope.invokeFetchCtrDetails(inputObj);
						} else {
							delete $scope.ctrObj;
						}

					}

					$scope.subTypeSelected = function(type) {
						$scope.inputObj.txnAmount = "";
						$scope.initDeno();
						switch (type) {

						case 'CashDeposit':
						case 'Cash Deposit':
							$('#cashDepositBlock').show();
							$('#addDetailsCollapsible').show();
							$('#addDetailsCollapsibleLessCash').hide();
							$('#onUsDepositBlock').hide();
							$('#lessCashAmountBlock').hide();
							$('#previewSection').hide();
							break;
						case 'On-UsDeposit':
						case 'On-Us Deposit':
							$('#onUsDepositBlock').show();
							$('#cashDepositBlock').hide();
							$('#lessCashAmountBlock').hide();
							$('#addDetailsCollapsible').hide();
							$('#addDetailsCollapsibleLessCash').hide();
							$('#previewSection').hide();
							break;
						case 'LessCashAmount':
						case 'Less Cash Amount':
							$('#lessCashAmountBlock').show();
							$('#addDetailsCollapsibleLessCash').show();
							$('#addDetailsCollapsible').hide();
							$('#cashDepositBlock').hide();
							$('#onUsDepositBlock').hide();
							$('#previewSection').hide();
							break;
						default:
							$('#cashDepositBlock').hide();
							$('#onUsDepositBlock').hide();
							$('#lessCashAmountBlock').hide();
							$('#addDetailsCollapsible').hide();
							$('#addDetailsCollapsibleLessCash').hide();
							$('#previewSection').hide();
						}
					}

					$scope.subTypeSelection = function() {
						if ($("#transactionSubtype").val() != "") {
							/*
							 * transactionAmount =
							 * parseInt($('.txnAmount').val()); depositAmt =
							 * parseInt($('.depositAmount').text()); netAmount =
							 * depositAmt + transactionAmount;
							 * $('.depositAmount').text(netAmount);
							 */
							var transSubType = $("#transactionSubtype").val()
									.split(":")[1];
							if (transSubType == "Cash Deposit"
									&& $scope.inputObj.transactionAmount != ""
									&& $scope.inputObj.transactionAmount != undefined) {
								if ($scope.inputObj.cashDepositAmount == undefined) {
									$scope.inputObj.cashDepositAmount = 0;

								}
								$scope.inputObj.depositAmount = parseInt($scope.inputObj.depositAmount)
										+ parseInt($scope.inputObj.transactionAmount);
								$scope.inputObj.cashDepositAmount = parseInt($scope.inputObj.cashDepositAmount)
										+ parseInt($scope.inputObj.transactionAmount);
							} else if (transSubType == "On-Us Deposit"
									&& $scope.inputObj.onustxnAmount != ""
									&& $scope.inputObj.onustxnAmount != undefined) {
								if ($scope.inputObj.onUsDepositAmount == undefined) {
									$scope.inputObj.onUsDepositAmount = 0;

								}
								$scope.inputObj.depositAmount = parseInt($scope.inputObj.depositAmount)
										+ parseInt($scope.inputObj.onustxnAmount);
								$scope.inputObj.onUsDepositAmount = parseInt($scope.inputObj.onUsDepositAmount)
										+ parseInt($scope.inputObj.onustxnAmount);
							} else if (transSubType == "Less Cash Amount") {
								if ($scope.inputObj.lessCashAmount == undefined
										&& $scope.inputObj.lesstxnAmount != ""
										&& $scope.inputObj.lesstxnAmount != undefined) {
									$scope.inputObj.lessCashAmount = 0;

								}
								$scope.inputObj.depositAmount = parseInt($scope.inputObj.depositAmount)
										- parseInt($scope.inputObj.lesstxnAmount);
								$scope.inputObj.lessCashAmount = parseInt($scope.inputObj.lessCashAmount)
										+ parseInt($scope.inputObj.lesstxnAmount);
							}
						}
						// alert($scope.inputObj.transSubType);
						$scope.inputObj.transSubType = "";
						$scope.inputObj.txnAmount = "";
						setTimeout(function() {
							$("#transactionSubtype")
									.selectmenu("refresh", true);
						}, 0);
						$('#cashDepositBlock').hide();
						$('#onUsDepositBlock').hide();
						$('#lessCashAmountBlock').hide();
						$('#addDetailsCollapsible').hide();
						$('#addDetailsCollapsibleLessCash').hide();
						$('#previewSection').hide();
					}

					$scope.repeatTask = function(flag) {
						$scope.inputObj.transSubType = "";
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
						}, 0);
						if (flag == "reset") {
							$scope.inputObj = {};
							$scope.initDenoPopup();
						}
						$('#txnDtlAdd').show();
						$('#txnDtlComplete').hide();
						$('#successTxn').hide();
						$('.detail-container').show();
						$('.form-container').show();
						$('#txnSubtypeBlock').show();
						$('.successContainer').hide();
						$('#cashDepositBlock').hide();
						$('#onUsDepositBlock').hide();
						$('#lessCashAmountBlock').hide();
						$('#addDetailsCollapsible').hide();
						$('#addDetailsCollapsibleLessCash').hide();
						$('#previewSection').hide();
					}

					$scope.previewSelection = function() {
						if ($("#transactionSubtype").val() != "") {
							/*
							 * transactionAmount =
							 * parseInt($('.txnAmount').val()); depositAmt =
							 * parseInt($('.depositAmount').text()); netAmount =
							 * depositAmt + transactionAmount;
							 * $('.depositAmount').text(netAmount);
							 */
							var transSubType = $("#transactionSubtype").val()
									.split(":")[1];
							if (transSubType == "Cash Deposit"
									&& $scope.inputObj.transactionAmount != ""
									&& $scope.inputObj.transactionAmount != undefined) {
								if ($scope.inputObj.cashDepositAmount == undefined) {
									$scope.inputObj.cashDepositAmount = 0;

								}
								$scope.inputObj.depositAmount = parseInt($scope.inputObj.depositAmount)
										+ parseInt($scope.inputObj.transactionAmount);
								$scope.inputObj.cashDepositAmount = parseInt($scope.inputObj.cashDepositAmount)
										+ parseInt($scope.inputObj.transactionAmount);
							} else if (transSubType == "On-Us Deposit"
									&& $scope.inputObj.onustxnAmount != ""
									&& $scope.inputObj.onustxnAmount != undefined) {
								if ($scope.inputObj.onUsDepositAmount == undefined) {
									$scope.inputObj.onUsDepositAmount = 0;

								}
								$scope.inputObj.depositAmount = parseInt($scope.inputObj.depositAmount)
										+ parseInt($scope.inputObj.onustxnAmount);
								$scope.inputObj.onUsDepositAmount = parseInt($scope.inputObj.onUsDepositAmount)
										+ parseInt($scope.inputObj.onustxnAmount);
							} else if (transSubType == "Less Cash Amount") {
								if ($scope.inputObj.lessCashAmount == undefined
										&& $scope.inputObj.lesstxnAmount != ""
										&& $scope.inputObj.lesstxnAmount != undefined) {
									$scope.inputObj.lessCashAmount = 0;

								}
								$scope.inputObj.depositAmount = parseInt($scope.inputObj.depositAmount)
										- parseInt($scope.inputObj.lesstxnAmount);
								$scope.inputObj.lessCashAmount = parseInt($scope.inputObj.lessCashAmount)
										+ parseInt($scope.inputObj.lesstxnAmount);
							}
						}
						$('#previewSection').show();
						$('#txnDtlComplete').show();
						$('#txnDtlAdd').hide();
						$('#successScreen').hide();
						$('#cashDepositBlock').hide();
						$('#onUsDepositBlock').hide();
						$('#lessCashAmountBlock').hide();
						$('#addDetailsCollapsible').hide();
						$('#addDetailsCollapsibleLessCash').hide();
						$('#txnSubtypeBlock').hide();
					}

					$scope.txnSubmit = function() {
						$('#netAmount').text(depositAmt)
						$('#successScreen').show();
						$('.successContainer').show();
						$('#successTxn').show();
						$('.detail-container').hide();
						$('.form-container').hide();
						$('#addDetailsCollapsible').hide();
						$('#addDetailsCollapsibleLessCash').hide();
						$('#txnDtlAdd').hide();
						$('#txnDtlComplete').hide();
					}

					$scope.editClick1 = function() {
						$('#txnSubtypeBlock').show();
						$('#txnDtlAdd').show();
						$('#previewSection').hide();
						$('#txnDtlComplete').hide();
						var subtype = 'CashDeposit'
						$scope.subTypeSelected(subtype);
					}

					$scope.editClick2 = function() {
						$('#txnSubtypeBlock').show();
						$('#txnDtlAdd').show();
						$('#previewSection').hide();
						$('#txnDtlComplete').hide();
						var subtype = 'On-UsDeposit'
						$scope.subTypeSelected(subtype);
					}

					$scope.editClick3 = function() {
						$('#txnSubtypeBlock').show();
						$('#txnDtlAdd').show();
						$('#previewSection').hide();
						$('#txnDtlComplete').hide();
						var subtype = 'LessCashAmount'
						$scope.subTypeSelected(subtype);
					}

					$scope.deleteTypeSelected = function(type) {
						$scope.inputObj.txnAmount = "";
						switch (type) {

						case 'CashDeposit':
						case 'Cash Deposit':
							$scope.inputObj.depositAmount = parseInt(this.inputObj.depositAmount)
									- parseInt(this.inputObj.transactionAmount);
							$scope.inputObj.cashDepositAmount = 0;
							break;
						case 'On-UsDeposit':
						case 'On-Us Deposit':
							$scope.inputObj.depositAmount = parseInt(this.inputObj.depositAmount)
									- parseInt(this.inputObj.onustxnAmount);
							$scope.inputObj.onUsDepositAmount = 0;
							break;
						case 'LessCashAmount':
						case 'Less Cash Amount':
							$scope.inputObj.depositAmount = parseInt(this.inputObj.depositAmount)
									+ parseInt(this.inputObj.lesstxnAmount);
							$scope.inputObj.lessCashAmount = 0;
							break;
						}
						;
					}

					// sasi end
					$scope.tellerTransSubmit = function() {
						$scope.tellerTransValues = [ {
							"tranId" : "M3946",
							"partTranSrlNum" : "1",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-06-23T00:00:00",
							"Iban" : "20000000000003815",
							"tranType" : "C",
							"tranAmt" : "1400.00",
							"partTranType" : "D",
							"status" : "Posted",
							"masterAccId" : []
						}, {
							"tranId" : "M3946",
							"partTranSrlNum" : "2",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-06-23T00:00:00",
							"Iban" : "20000000000003888",
							"tranType" : "C",
							"tranAmt" : "1400.00",
							"partTranType" : "C",
							"status" : "Posted",
							"masterAccId" : []
						}, {
							"tranId" : "SDG1960",
							"partTranSrlNum" : "1",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-06-23T00:00:00",
							"Iban" : "342423000000003815",
							"tranType" : "D",
							"tranAmt" : "8000.00",
							"partTranType" : "C",
							"status" : "Verified",
							"masterAccId" : []
						}, {
							"tranId" : "SDG1960",
							"partTranSrlNum" : "2",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-06-23T00:00:00",
							"Iban" : "204564560000003815",
							"tranType" : "D",
							"tranAmt" : "8000.00",
							"partTranType" : "D",
							"status" : "Verified",
							"masterAccId" : []
						}, {
							"tranId" : "M3941",
							"partTranSrlNum" : "1",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-01-23T00:00:00",
							"Iban" : "353454357777367565",
							"tranType" : "D",
							"tranAmt" : "8000.00",
							"partTranType" : "D",
							"status" : "Verified",
							"masterAccId" : "LA008525"
						}, {
							"tranId" : "M3941",
							"partTranSrlNum" : "2",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-06-23T00:00:00",
							"Iban" : "123123579077555",
							"tranType" : "D",
							"tranAmt" : "8000.00",
							"partTranType" : "C",
							"status" : "Verified",
							"masterAccId" : "CA007979"
						}, {
							"tranId" : "M3931",
							"partTranSrlNum" : "1",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-05-23T00:00:00",
							"Iban" : "20000000000003815",
							"tranType" : "D",
							"tranAmt" : "25000.00",
							"partTranType" : "D",
							"status" : "Verified",
							"masterAccId" : "LA008464"
						}, {
							"tranId" : "M3931",
							"partTranSrlNum" : "2",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-06-23T00:00:00",
							"Iban" : "20000000000003815",
							"tranType" : "D",
							"tranAmt" : "25000.00",
							"partTranType" : "C",
							"status" : "Verified",
							"masterAccId" : "CA007979"
						}, {
							"tranId" : "M3858",
							"partTranSrlNum" : "1",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-06-23T00:00:00",
							"Iban" : "78674564649098095",
							"tranType" : "C",
							"tranAmt" : "1000.00",
							"partTranType" : "D",
							"status" : "Posted",
							"masterAccId" : "CA007979"
						}, {
							"tranId" : "M3858",
							"partTranSrlNum" : "2",
							"tranDate" : "2015-06-23T00:00:00",
							"valueDate" : "2015-06-23T00:00:00",
							"Iban" : "78674564649098095",
							"tranType" : "C",
							"tranAmt" : "1000.00",
							"partTranType" : "C",
							"status" : "Posted",
							"masterAccId" : "CA007979"
						} /*
							 * , { "tranId" : "M3816", "partTranSrlNum" : "1",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "250.00", "partTranType" : "D",
							 * "status" : "Entered", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3816", "partTranSrlNum" : "2",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "250.00", "partTranType" : "C",
							 * "status" : "Entered", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3815", "partTranSrlNum" : "1",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "200.00", "partTranType" : "D",
							 * "status" : "Entered", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3815", "partTranSrlNum" : "2",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "200.00", "partTranType" : "C",
							 * "status" : "Entered", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3814", "partTranSrlNum" : "1",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "150.00", "partTranType" : "D",
							 * "status" : "Entered", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3814", "partTranSrlNum" : "2",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "150.00", "partTranType" : "C",
							 * "status" : "Entered", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3807", "partTranSrlNum" : "2",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "C", "tranAmt" : "10000.00", "partTranType" :
							 * "D", "status" : "Posted", "masterAccId" :
							 * "CA007979" }, { "tranId" : "M3807",
							 * "partTranSrlNum" : "1", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "C", "tranAmt" : "10000.00", "partTranType" :
							 * "C", "status" : "Posted", "masterAccId" :
							 * "CA007979" }, { "tranId" : "M3804",
							 * "partTranSrlNum" : "1", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "125.00", "partTranType" : "D",
							 * "status" : "Posted", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3804", "partTranSrlNum" : "2",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "125.00", "partTranType" : "C",
							 * "status" : "Posted", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3803", "partTranSrlNum" : "1",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "125.00", "partTranType" : "D",
							 * "status" : "Posted", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3803", "partTranSrlNum" : "2",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : [], "tranType" :
							 * "T", "tranAmt" : "125.00", "partTranType" : "C",
							 * "status" : "Posted", "masterAccId" : "CA007979" }, {
							 * "tranId" : "M3787", "partTranSrlNum" : "1",
							 * "tranDate" : "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : "/ ID",
							 * "tranType" : "C", "tranAmt" : "2000.00",
							 * "partTranType" : "C", "status" : "Verified",
							 * "masterAccId" : "CA007979" }, { "tranId" :
							 * "M3787", "partTranSrlNum" : "2", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : "/ ID",
							 * "tranType" : "C", "tranAmt" : "2000.00",
							 * "partTranType" : "D", "status" : "Verified",
							 * "masterAccId" : "CA007979" }, { "tranId" :
							 * "M3770", "partTranSrlNum" : "1", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : "/ ID",
							 * "tranType" : "C", "tranAmt" : "125.00",
							 * "partTranType" : "D", "status" : "Posted",
							 * "masterAccId" : "CA007979" }, { "tranId" :
							 * "M3770", "partTranSrlNum" : "2", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : "/ ID",
							 * "tranType" : "C", "tranAmt" : "125.00",
							 * "partTranType" : "C", "status" : "Posted",
							 * "masterAccId" : "CA007979" }, { "tranId" :
							 * "M3767", "partTranSrlNum" : "1", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : "/ ID",
							 * "tranType" : "C", "tranAmt" : "125.00",
							 * "partTranType" : "D", "status" : "Posted",
							 * "masterAccId" : "CA007979" }, { "tranId" :
							 * "M3767", "partTranSrlNum" : "2", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : "/ ID",
							 * "tranType" : "C", "tranAmt" : "125.00",
							 * "partTranType" : "C", "status" : "Posted",
							 * "masterAccId" : "CA007979" }, { "tranId" :
							 * "M3696", "partTranSrlNum" : "1", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : "/ ID",
							 * "tranType" : "C", "tranAmt" : "2500.00",
							 * "partTranType" : "C", "status" : "Posted",
							 * "masterAccId" : "CA007979" }, { "tranId" :
							 * "M3696", "partTranSrlNum" : "2", "tranDate" :
							 * "2015-06-23T00:00:00", "valueDate" :
							 * "2015-06-23T00:00:00", "Iban" : "/ ID",
							 * "tranType" : "C", "tranAmt" : "2500.00",
							 * "partTranType" : "D", "status" : "Posted",
							 * "masterAccId" : "CA007979" }
							 */];
						for ( var i in $scope.tellerTransValues) {
							if ($scope.tellerTransValues[i].Iban.length == 0) {
								$scope.tellerTransValues[i].Iban = "-";
							}
						}
						$state
								.go("tellerdashboard.template.tellertransactioninquirysuccess");
					}
					$scope.loadDetailedTran = function(inputObj) {
						$scope.inputObj = angular.copy(inputObj);
						$scope.tellerTransValuesDet = [
								{
									"TotalUsedTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"UsedSecRunTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"UsedCleanRunTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"UsedSecSingleTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"UsedCleanSingleTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"TODEntityType" : [],
									"ValueDate" : "2015-05-23T00:00:00.000",
									"TranAcctId" : {
										"foracid" : "LA008464",
										"crncyCode" : "USD",
										"solId" : "295",
										"acctName" : "SUSAN GRIFFITH",
										"acctShortName" : []
									},
									"InstrumentInfo" : {
										"InstrumentNumber" : [],
										"InstrumentType" : [],
										"InstrumentAlpha" : []
									},
									"PartTranType" : "D",
									"ReferenceAmt" : {
										"amountValue" : "25000.00",
										"currencyCode" : "USD"
									},
									"ReferenceCrncy" : "USD",
									"ReferenceNumber" : [],
									"TranCrncy" : "USD",
									"TranParticulars" : "LA008464 Loan Disbursement Debit",
									"Remarks1" : [],
									"Remarks2" : [],
									"Rate" : "1.00"
								},
								{
									"TotalUsedTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"UsedSecRunTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"UsedCleanRunTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"UsedSecSingleTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"UsedCleanSingleTODAmt" : {
										"amountValue" : "0.00",
										"currencyCode" : "USD"
									},
									"TODEntityType" : [],
									"ValueDate" : "2015-06-23T00:00:00.000",
									"TranAcctId" : {
										"foracid" : "CA007979",
										"crncyCode" : "USD",
										"solId" : "295",
										"acctName" : "SUSAN GRIFFITH",
										"acctShortName" : []
									},
									"InstrumentInfo" : {
										"InstrumentNumber" : [],
										"InstrumentType" : [],
										"InstrumentAlpha" : []
									},
									"PartTranType" : "C",
									"ReferenceAmt" : {
										"amountValue" : "25000.00",
										"currencyCode" : "USD"
									},
									"ReferenceCrncy" : "USD",
									"ReferenceNumber" : [],
									"TranCrncy" : "USD",
									"TranParticulars" : "LA008464 Loan Disbursement Credit",
									"Remarks1" : [],
									"Remarks2" : [],
									"Rate" : "1.00"
								} ];
						$scope.tellerTransValuesCommon = {
							"InitSolDesc" : [],
							"InitSolId" : "295",
							"Status" : "P",
							"TranIdentifier" : {
								"TrnDt" : "2015-06-23T00:00:00.000",
								"TrnId" : "    M3946"
							},
							"TranRemarks" : [],
							"TranSubType" : {
								"tranSubType" : "NP",
								"tranType" : "C"
							}
						};
						if ($state.current.name == "tellerdashboard") {
							$state
									.go("tellerdashboard.template.tellertransactioninquirymini");
						} else {
							$state
									.go("tellerdashboard.template.tellertransactioninquirysuccesssuccess");
						}

					}

					$scope.openCustTranSummaryPopup = function() {
						$("#custTranSummaryPopup").popup("destroy");
						$("#custTranSummaryPopup").show();
						$("#custTranSummaryPopup").popup().popup("open");
					}

					$scope.processAuthSubmit = function(radioVal) {
						if (checkEmpty(radioVal)) {
							$scope.openAuthView(radioVal);
						} else {
							nativeAlert(
									"Please select appropriate Authentication Type",
									"Error", defaultBtnArray);
						}
					}

					$scope.signpadInit = function() {
						// $scope.toggleSignComparison();
						setTimeout(function() {
							$("#signPad").removeClass("no-display");
						}, 500);
					}

					$scope.toggleSignComparison = function() {
						$scope.zoomImg = "images/icons-png/Zoom_in.png";
						$scope.capturedSignSrc = $scope.viewDtl.sign;
						$("#compareDiv").toggle();
						$("#captureDiv").toggle();
						$("#signid").zoom({
							on : 'grab'

						});
					}

					$scope.openGallerySignCompare = function() {
						$scope.zoomImg = "images/icons-png/Zoom_in.png";
						var selected_file = $('#sign').get(0).files[0];
						selected_file = window.URL
								.createObjectURL(selected_file);
						$scope.capturedSignSrc = selected_file;
						$("#captureGalSignDiv").hide();
						$("#compareGalSignDiv").show();
						$scope.repositionPopup();
					}

					$scope.biometricReject = function() {
						$scope.showAuthPopupView = "authloading";
						setTimeout(
								function() {
									$scope.successfailmsg = "You have rejected the transaction with Reference Id: 342111";
									$scope.showAuthPopupView = "authsuccess";
									$scope.$apply();
								}, 500);
					}
					$scope.biometricSuccess = function() {
						/*
						 * $scope.showAuthPopupView = "authloading"; setTimeout(
						 * function() { $scope.successfailmsg = "You have
						 * successfully approved the request.";
						 * $scope.showAuthPopupView = "authsuccess";
						 * $scope.$apply(); }, 500);
						 */
						closePopup("authSign");
						$scope.transactId = "78128219";
						$scope.pendingApproval = $scope.pendingApproval - 1;
						$scope.notifNum = $scope.notifNum - 1;
						$state.go($state.current.name + "success");
					}

					$scope.biometricSuccessDismiss = function() {
						$scope.showAuthPopupView = "biometric";
						closePopup("authenticateWithdrawal");
						if (!checkEmpty($scope.inputObj.remarks)) {
							if ($scope.inputObj.instrumentType == 'Check') {
								$scope.inputObj.remarks = "Check Encashment";
							} else {
								$scope.inputObj.remarks = "Cash Withdrawal";
							}
						}
						$scope.processTransaction($scope.inputObj);
					}
					$scope.submitDepAuth = function() {
						$scope.showAuthPopupView = "signpad";
						closePopup("authSign");
						if ($scope.approvalkey == "342111") {
							$scope.referapprovalsuccessdeposit = $scope.approvalkey;
						}
						if ($scope.approvalkey == "342112") {
							$scope.referapprovalsuccesswith = $scope.approvalkey;
						}
						$state.go("tellerdashboard.template.pendingapprovals");
					}

					$scope.openTransactionAcctPopup = function() {
						openPopup('transactionAcct');
					}

					$scope.selectAcctSubmit = function(acctval) {
						$scope.Data.accNumb = acctval;
						closePopup('transactionAcct');
					}
					$scope.zoom = function(id) {
						if ($scope.zoomImg == "images/icons-png/Zoom_in.png") {
							var widthDiv = $("#" + id).width();
							$("#" + id).css("width", (1.25) * widthDiv);
							/*
							 * var heightDiv = $("#compareDiv").height();
							 * $("#compareDiv").css("height",(1.25)*heightDiv);
							 */
							/*
							 * var signPad1 = $("#signPad1").width();
							 * $("#signPad1").css("width", (1.25) * signPad1);
							 * $("#signPad2").css("width", (1.25) * signPad1);
							 * var signPad1height = $("#signPad1").height();
							 * $("#signPad1").css("height", (1.125) *
							 * signPad1height); $("#signPad2").css("height",
							 * (1.125) * signPad1height);
							 */
							$scope.zoomImg = "images/icons-png/Zoom_out.png";

						} else if ($scope.zoomImg == "images/icons-png/Zoom_out.png") {
							var widthDiv = $("#" + id).width();
							$("#" + id).css("width", (0.8) * widthDiv);
							/*
							 * var heightDiv = $("#compareDiv").height();
							 * $("#compareDiv").css("height",(0.8)*heightDiv);
							 */
							/*
							 * var signPad1 = $("#signPad1").width();
							 * $("#signPad1").css("width", (0.8) * signPad1);
							 * $("#signPad2").css("width", (0.8) * signPad1);
							 * var signPad1height = $("#signPad1").height();
							 * $("#signPad1").css("height", (0.889) *
							 * signPad1height); $("#signPad2").css("height",
							 * (0.889) * signPad1height);
							 */
							$scope.zoomImg = "images/icons-png/Zoom_in.png";
						}
					}
					/*
					 * $scope.zoom = function() { if ($scope.zoomImg ==
					 * "images/icons-png/Zoom_in.png") { var widthDiv =
					 * $("#compareDiv").width(); $("#compareDiv").css("width",
					 * (1.25) * widthDiv);
					 * 
					 * var heightDiv = $("#compareDiv").height();
					 * $("#compareDiv").css("height",(1.25)*heightDiv);
					 * 
					 * var signPad1 = $("#signPad1").width();
					 * $("#signPad1").css("width", (1.25) * signPad1);
					 * $("#signPad2").css("width", (1.25) * signPad1); var
					 * signPad1height = $("#signPad1").height();
					 * $("#signPad1").css("height", (1.125) * signPad1height);
					 * $("#signPad2").css("height", (1.125) * signPad1height);
					 * $scope.zoomImg = "images/icons-png/Zoom_out.png"; } else
					 * if ($scope.zoomImg == "images/icons-png/Zoom_out.png") {
					 * var widthDiv = $("#compareDiv").width();
					 * $("#compareDiv").css("width", (0.8) * widthDiv);
					 * 
					 * var heightDiv = $("#compareDiv").height();
					 * $("#compareDiv").css("height",(0.8)*heightDiv);
					 * 
					 * var signPad1 = $("#signPad1").width();
					 * $("#signPad1").css("width", (0.8) * signPad1);
					 * $("#signPad2").css("width", (0.8) * signPad1); var
					 * signPad1height = $("#signPad1").height();
					 * $("#signPad1").css("height", (0.889) * signPad1height);
					 * $("#signPad2").css("height", (0.889) * signPad1height);
					 * $scope.zoomImg = "images/icons-png/Zoom_in.png"; } }
					 * 
					 * $scope.zoomGal = function() { if ($scope.zoomImg ==
					 * "images/icons-png/Zoom_in.png") { $("#signCompareTable
					 * tbody img").css("zoom", 1.5);
					 * $("#signCompareTable").css("width", 600); $scope.zoomImg =
					 * "images/icons-png/Zoom_out.png"; } else if
					 * ($scope.zoomImg == "images/icons-png/Zoom_out.png") {
					 * $("#signCompareTable tbody img").css("zoom", 0);
					 * $("#signCompareTable").css("width", 520); $scope.zoomImg =
					 * "images/icons-png/Zoom_in.png"; } }
					 */

					$scope.otpClick = function() {
						$scope.firstPopup = "first";
						$scope.authRadio = "";
						$timeout(function() {
							$('input[type="radio"]:not(:checked)')
									.checkboxradio("refresh");
							$('input[type="radio"]:checked').checkboxradio(
									"refresh");
						});
						$scope.zoomImg = "images/icons-png/Zoom_in.png";
						if (!$scope.$$phase) {
							$scope.$apply();
						}
						openPopup("authenticateOTP");
						delete $scope.inputObject.viewSign;
						/*
						 * $("#authenticateOTP").show();
						 * $("#authenticateOTP").popup().popup("open");
						 */
					};
					$scope.openAuthView = function(viewName) {
						$scope.firstPopup = viewName;

					}
					$scope.showApprove = function() {
						$scope.firstPopup = "signature";
						setTimeout(function() {
							$("#signCompareTable .no-display").removeClass(
									"no-display");
						}, 0);
					}
					$scope.processAuthSignature = function(signtype) {
						if (checkEmpty(signtype)) {
							if (signtype == "cam") {
								$scope.zoomImg = "images/icons-png/Zoom_in.png";
								$scope.firstPopup = "authloading";
								setTimeout(function() {
									$scope.openAuthView(signtype);
									$scope.$apply();
								}, 500);
							} else {
								$scope.openAuthView(signtype);
							}
						}
					}
					$scope.openAuthSuccess = function(id) {
						var authArr = $scope.authSuccessArr;
						authArr.push($("#" + id + "-lbl").text());
						$scope.authSuccessArr = authArr;
						$scope.firstPopup = "authloading";
						// $("#" + id +
						// "-success").show().addClass("green-txt");
						$("#" + id).attr("disabled", true);
						$('input:radio').attr("checked", false).checkboxradio(
								"refresh");
						setTimeout(function() {
							$scope.firstPopup = "authsuccess";

							// $scope.submitOTP();
							setTimeout(function() {
								$scope.submitOTP();
								$scope.$apply();
							}, 1000);
							$scope.$apply();
						}, 800);

					}
					$scope.otpSet = function(value) {
						if (value.length == 4) {
							$scope.openAuthSuccess('auth-choice-2');
						}
					}
					$scope.openAuthReject = function() {
						$scope.firstPopup = "authloading";

						setTimeout(function() {
							$scope.firstPopup = "authreject";
							setTimeout(function() {
								$scope.submitOTP();
								$scope.$apply();
							}, 1000);
							$scope.$apply();
						}, 500);

					}

					$scope.loadRespDashboard = function() {
						$(".ui-btn-active").removeClass("ui-btn-active");
						if ($scope.role == "T") {
							$state.go("dashboard");
						} else if ($scope.role == "R") {
							$state.go("rmDashboard");
						} else if ($scope.role == "A") {
							$state.go("agentDashboard");
						}
					}

					function CustomerSummary(obj, id) {
						this.obj = obj;
						this.successId = id;
					}

					$scope.ownFundTransfer = function(inputObj, index) {
						if (inputObj.accountNumber != undefined
								&& inputObj.radioSel != undefined
								&& inputObj.transactionAmount != undefined) {

							var obj = angular.copy(inputObj);
							if ((index) != undefined) {
								if ($scope.ownTransferList[index].radioSel == "Credit") {
									$scope.fundSummaryObj.totalCreditAmt = $scope.fundSummaryObj.totalCreditAmt
											- parseInt($scope.ownTransferList[index].transactionAmount);
								} else if ($scope.ownTransferList[index].radioSel == "Debit") {
									$scope.fundSummaryObj.totalDebitAmt = $scope.fundSummaryObj.totalDebitAmt
											- parseInt($scope.ownTransferList[index].transactionAmount);
								}
								$scope.ownTransferList[index] = obj;
								if ($scope.ownTransferList[index].radioSel == "Credit") {
									$scope.fundSummaryObj.totalCreditAmt = $scope.fundSummaryObj.totalCreditAmt
											+ parseInt(inputObj.transactionAmount);
								} else if ($scope.ownTransferList[index].radioSel == "Debit") {
									$scope.fundSummaryObj.totalDebitAmt = $scope.fundSummaryObj.totalDebitAmt
											+ parseInt(inputObj.transactionAmount);
								}
							} else {
								$scope.ownTransferList.push(obj);
								if (inputObj.radioSel == "Credit") {
									$scope.fundSummaryObj.totalCreditAmt = $scope.fundSummaryObj.totalCreditAmt
											+ parseInt(inputObj.transactionAmount);
								} else if (inputObj.radioSel == "Debit") {
									$scope.fundSummaryObj.totalDebitAmt = $scope.fundSummaryObj.totalDebitAmt
											+ parseInt(inputObj.transactionAmount);
								}
							}

							$scope.inputObj = {};
							setTimeout(function() {
								$("select").selectmenu("refresh", true);
								$('input:radio').attr("checked", false)
										.checkboxradio("refresh");
							}, 0);
							this.inputObj.accCurrency = Data.accCurrency;
							// this.inputObj.accountNumber = Data.accNumb;
						}
					}
					$scope.deleteFundTran = function(index) {

						if ($scope.ownTransferList[index].radioSel == "Credit") {
							$scope.fundSummaryObj.totalCreditAmt = $scope.fundSummaryObj.totalCreditAmt
									- ($scope.ownTransferList[index].transactionAmount);
						} else if ($scope.ownTransferList[index].radioSel == "Debit") {
							$scope.fundSummaryObj.totalDebitAmt = $scope.fundSummaryObj.totalDebitAmt
									- ($scope.ownTransferList[index].transactionAmount);
						}
						$scope.ownTransferList.splice(index, 1);
					}
					$scope.editFundTran = function(index) {
						$state
								.go('dashboard.template.fundtransfer')
								.then(
										function() {
											$scope.inputObj = angular
													.copy($scope.ownTransferList[index]);
											$scope.inputObj.index = index;
											setTimeout(function() {
												$('input:radio').checkboxradio(
														"refresh");
											}, 0);
										});
					}
					$scope.backFundTransfer = function() {
						$state
								.go('dashboard.template.fundtransfer')
								.then(
										function() {
											$scope.inputObj = {};
											$('input:radio').attr("checked",
													false).checkboxradio(
													"refresh");
											this.inputObj.accCurrency = $scope.Data.accCurrency;
											this.inputObj.accountNumber = $scope.dashboardAcct;
										});
					}
					$scope.fundtransferSubmitWithin = function(inputObj) {
						/*
						 * $scope.inputObj.accountNumber =
						 * inputObj.accountNumber;
						 * $scope.inputObj.accountNumberTo =
						 * inputObj.accountNumberTo;
						 */
						if ($scope.custSummaryObj != undefined) {
							$scope.custSummaryObj.push(new CustomerSummary(
									inputObj, $scope.transactId));
						}
						$state.go($state.current.name + "success");
					};
					$scope.fundTransferOTP = function() {
						$scope.fundTransPopup = "otp";
						openPopup('fundTransferOTP');
					}
					$scope.fundOTPSet = function(value) {
						if (value.length == 4) {
							$scope.fundTransPopup = "authloading";
							setTimeout(function() {
								$scope.fundTransPopup = "authsuccess";
								$scope.$apply();
							}, 800);

						}
					}
					$scope.fundCloseBenAddPopup = function() {
						closePopup("fundTransferOTP");
						delete $scope.fundSummaryObj.tranMode;
						$scope.$apply();
					}
					$scope.populateLoanAcctInqDtls = function() {
						$scope.loanAcctObj = [];
						var a = {}, b = {};
						a.accNumb = "LA82389";
						a.disbursedAmount = "5000";
						a.disbursedDate = "Jul 14, 2014";
						a.loanTenure = "5 Years";
						a.interestRate = "14%";
						a.monthlyInstallment = "1140";
						a.NoOfInstallLeft = "2";
						a.NoOfInstall = "5";
						a.nextPaymentDate = "01-AUG-2015";
						a.amountDue = "5000";
						a.prodCode = "LOAN564FRD";
						a.prodDesc = "Home Loan";
						a.balAmount = "5000";
						a.loanExpiryDt = "Aug 01, 2019";
						$scope.loanAcctObj.push(a);
						b.accNumb = "LA81229";
						b.disbursedAmount = "5000";
						b.disbursedDate = "Jul 14, 2014";
						b.loanTenure = "5 Years";
						b.interestRate = "14%";
						b.monthlyInstallment = "1140";
						b.NoOfInstallLeft = "4";
						b.NoOfInstall = "5";
						b.nextPaymentDate = "01-AUG-2015";
						b.amountDue = "5000";
						b.prodCode = "LOAN884FRD";
						b.prodDesc = "Car Loan";
						b.balAmount = "5000";
						b.loanExpiryDt = "Aug 01, 2019";
						$scope.loanAcctObj.push(b);
					}

					$scope.viewMoreDtlsTellerDash = function() {
						$rootScope.submitted = "";
						$("#more-details").hide();
						$("#lastnTran").show();
						$(".tellerdiv").addClass("addShadowToViewDtlsDiv")
								.addClass("addShadowToMainViewDtlsDiv");
					}
					$scope.setTransactDetails = function() {

						$scope.transactDtls = getTransactionDtls();
					}
					$scope.navigateFromTellerDashboard = function(page,
							callbackFn) {
						$scope.isApprovalFlow = "";
						if ($state.current.name == "tellerdashboard") {
							$state.go("tellerdashboard.template");
						}
						$state.go("tellerdashboard.template." + page);
					}
					$scope.cancelClickTeller = function() {
						$state.go("tellerdashboard");
					}
					$scope.custTransSubmit = function() {
						$state
								.go("tellerdashboard.template.customertraninquirysuccess");
					}

					$scope.processWithdrawal = function(inputObj, accountNumber) {
						$rootScope.submitted = true;
						if ($("form .ng-invalid").length == 0) {
							/* if ($(".green-txt").length >= 1) { */
							if ($scope.Data.accNumb == '3200SB1784569045'
									&& $scope.inputObj.applyODProtection == true
									&& $scope.warningFlag) {
								swal(
										{
											title : "Warning",
											text : "Insufficient funds in the checking account, overdraft protection will be utilized to settle the transaction. A fee of $35 will also be applied on to the account"
										}, function(isConfirm) {

											$scope.warningFlag = false;

										});
								/*
								 * nativeAlert( "Insufficient funds in the
								 * checking account, overdraft protection will
								 * be utilized to settle the transaction. A fee
								 * of $35 will also be applied on to the
								 * account", "Warning", defaultBtnArray);
								 */
							} else {

								$scope.checkSubmitWithdrawal(inputObj,
										accountNumber);
							}
						}
					}
					$scope.checkSubmitWithdrawal = function(inputObj,
							accountNumber) {
						if (parseInt(inputObj.transactionAmount) >= 10000
								&& $scope.inputObj.isCtr != true) {
							swal(
									{
										title : "Error",
										text : "You have crossed your day's aggregate amount. Please enter the CTR details."
									}, function(isConfirm) {
										/*
										 * $scope.openCtrDetails($scope.inputObj);
										 * $scope.inputObj.isCtr = true;
										 * $scope.$apply();
										 */
									});
						} else {
							if (checkEmpty($scope.authSuccessArr)) {
								/*
								 * $scope.showAuthPopupView = 'biometric';
								 * openPopup("authenticateWithdrawal");
								 */
								$scope.referToClickWithdrawal(inputObj,
										accountNumber);
							} else {
								swal(
										{
											title : "Authenticate Customer",
											text : "Please authenticate the customer before proceeding with the transaction."
										}, function(isConfirm) {
											$scope.otpClick();
										});
							}
						}

					}
					$scope.referToClickWithdrawal = function(inputObj,
							accountNumber) {
						$rootScope.submitted = true;
						if ($("form .ng-invalid").length == 0) {
							if (parseInt(inputObj.transactionAmount) >= 15000) {
								closePopup("authenticateWithdrawal");
								$("#referToPopup").show();
								$("#referToPopup").popup().popup("open");
							} else {
								$scope.biometricSuccessDismiss();
							}
						}
					};
					$scope.approveReferWithdrawal = function() {
						$scope.referred = "true";
						$scope.biometricSuccessDismiss();
						closePopup("referToPopup");
					}

					$scope.tellerTransValuesDash = [ {
						"tranId" : "M3946",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-01T00:00:00",
						"valueDate" : "2015-02-01T00:00:00",
						"Iban" : "20150128085721",
						"tranType" : "Cash Withdrawal",
						"tranAmt" : "1400.00",
						"partTranType" : "D",
						"status" : "Posted",
						"masterAccId" : []
					}, {
						"tranId" : "SDG1960",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-01T00:00:00",
						"valueDate" : "2017-02-01T00:00:00",
						"Iban" : "20150128085726",
						"tranType" : "Cash Withdrawal",
						"tranAmt" : "8000.00",
						"partTranType" : "C",
						"status" : "Verified",
						"masterAccId" : []
					}, {
						"tranId" : "M3941",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-04T00:00:00",
						"valueDate" : "2017-02-04T00:00:00",
						"Iban" : "235128085720",
						"tranType" : "Cash Withdrawal",
						"tranAmt" : "8000.00",
						"partTranType" : "D",
						"status" : "Verified",
						"masterAccId" : "LA008525"
					}, {
						"tranId" : "M3931",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-04T00:00:00",
						"valueDate" : "2017-02-04T00:00:00",
						"Iban" : "2015012805443",
						"tranType" : "Cash Withdrawal",
						"tranAmt" : "25000.00",
						"partTranType" : "D",
						"status" : "Verified",
						"masterAccId" : "LA008464"
					}, {
						"tranId" : "ED858",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-04T00:00:00",
						"valueDate" : "2017-02-04T00:00:00",
						"Iban" : "544328085743243",
						"tranType" : "Cash Withdrawal",
						"tranAmt" : "1000.00",
						"partTranType" : "D",
						"status" : "Posted",
						"masterAccId" : "CA007979"
					}, {
						"tranId" : "H328",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-05T00:00:00",
						"valueDate" : "2017-02-05T00:00:00",
						"Iban" : "898728085743243",
						"tranType" : "Cash Deposit",
						"tranAmt" : "1000.00",
						"partTranType" : "D",
						"status" : "Posted",
						"masterAccId" : "CA007979"
					}, {
						"tranId" : "CL3858",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-05T00:00:00",
						"valueDate" : "2017-02-05T00:00:00",
						"Iban" : "2015012808543",
						"tranType" : "Cash Withdrawal",
						"tranAmt" : "1000.00",
						"partTranType" : "D",
						"status" : "Posted",
						"masterAccId" : "CA007979"
					}, {
						"tranId" : "M384338",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-05T00:00:00",
						"valueDate" : "2017-02-05T00:00:00",
						"Iban" : "20150128080243",
						"tranType" : "Cash Deposit",
						"tranAmt" : "1000.00",
						"partTranType" : "D",
						"status" : "Posted",
						"masterAccId" : "CA007979"
					}, {
						"tranId" : "M38234",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-05T00:00:00",
						"valueDate" : "2017-02-05T00:00:00",
						"Iban" : "6868128085743243",
						"tranType" : "Cash Deposit",
						"tranAmt" : "1000.00",
						"partTranType" : "D",
						"status" : "Posted",
						"masterAccId" : "CA007979"
					}, {
						"tranId" : "M38328",
						"partTranSrlNum" : "1",
						"tranDate" : "2017-02-15T00:00:00",
						"valueDate" : "2017-02-15T00:00:00",
						"Iban" : "201501769743243",
						"tranType" : "Cash Withdrawal",
						"tranAmt" : "1000.00",
						"partTranType" : "D",
						"status" : "Posted",
						"masterAccId" : "CA007979"
					} ];

					$scope.getApprovalDetail = function(key) {
						if (key == "342111") {
							$scope.isApprovalFlow = "1";
							$scope.viewDtl = {};
							$scope.viewDtl.name = "Mr. Steve Robin";
							$scope.viewDtl.img = "images/user-2.png";
							$scope.viewDtl.sign = "images/signature.jpg";
							$scope.viewDtl.currentRec = "1";
							$scope.dashboardAcct = "3200SB1645890701";
							$scope.viewDtl.custId = "CIF101";
							$scope.viewDtl.accOpenDt = "Sep 17, 2014"
							$scope.viewDtl.acctStat = "Active";
							$scope.viewDtl.operationMod = "Savings";
							$scope.Data.accNumb = "3200SB1645890701";
							$scope.Data.accCurrency = "USD";
							$scope.viewDtl.availBal = "1,000,010";
							$scope.viewDtl.maturityDt = "";
							$scope.viewDtl.operationMod = "Single";
							$scope.viewDtl.depAmt = "";
							$scope.viewDtl.maturityAmt = "";
							$state
									.go("tellerdashboard.template.deposit")
									.then(
											function() {
												$scope.inputObj.approvalkey = key;
												$scope.inputObj.intendedUseOfFunds = "Gifts";
												// $scope.inputObj.isCtr = true;
												$scope.inputObj.accCurrency = "USD";
												$scope.inputObj.remarks = "Cash Withdrawal";
												$scope
														.invokeFetchCtrDetails($scope.inputObj);
												$scope.inputObj.isCtr = true;
												$scope.$apply();
												// $scope.invokeDateInit();
											});
						}
						if (key == "342112") {
							$scope.isApprovalFlow = "1";
							$scope.viewDtl = {};
							$scope.viewDtl.name = "Mr. Steve Robin";
							$scope.viewDtl.img = "images/user-2.png";
							$scope.viewDtl.sign = "images/signature.jpg";
							$scope.viewDtl.currentRec = "1";
							$scope.dashboardAcct = "3200SB1645890701";
							$scope.viewDtl.custId = "CIF101";
							$scope.viewDtl.accOpenDt = "Sep 17, 2014"
							$scope.viewDtl.acctStat = "Active";
							$scope.viewDtl.operationMod = "Savings";
							$scope.Data.accNumb = "3200SB1645890701";
							$scope.Data.accCurrency = "USD";
							$scope.viewDtl.availBal = "1,000,010";
							$scope.viewDtl.maturityDt = "";
							$scope.viewDtl.operationMod = "Single";
							$scope.viewDtl.depAmt = "";
							$scope.viewDtl.maturityAmt = "";
							$state
									.go("tellerdashboard.template.withdrawal")
									.then(
											function() {
												$scope.inputObj.approvalkey = key;
												$scope.inputObj.isCtr = true;
												$scope.inputObj.intendedUseOfFunds = "Gifts";
												// /$scope.inputObj.isCtr =
												// true;
												$scope.inputObj.physicalClosingBal = "15000";
												$scope.inputObj.transactionAmount = "15000";
												// $scope.inputObj.remarks =
												// "Demo Withdrawal";
												$scope.inputObj.accCurrency = "USD";
												$scope.inputObj.remarks = "Cash Withdrawal";
												$scope
														.invokeFetchCtrDetails($scope.inputObj);
												$scope.inputObj.isCtr = true;
												$scope.$apply();
												// $scope.inputObj.instrumentType
												// = "CHQ";
												// $scope.inputObj.instrumentNumber
												// = "1234567";
												// $scope.invokeDateInit();
											});
						}
					}

					$scope.processApproval = function(inputObj, accountNumber) {
						$scope.zoomImg = "images/icons-png/Zoom_in.png";
						$scope.errorMsgDesc = "";
						openPopup("authSign");
						$scope.showAuthPopupView = "signpad";
					}
					$scope.processRejection = function(inputObj, accountNumber) {
						$scope.errorMsgDesc = "Cash Deposit has failed due to rejection by approver.";
						$state.go("dashboard.template.depositsuccess");
					}

					$scope.initDeno = function() {
						$scope.inputObj.loose100 = 0;
						$scope.inputObj.loose50 = 0;
						$scope.inputObj.loose20 = 0;
						$scope.inputObj.loose10 = 0;
						$scope.inputObj.loose5 = 0;
						$scope.inputObj.loose2 = 0;
						$scope.inputObj.loose1 = 0;
						$scope.inputObj.notes100 = 0;
						$scope.inputObj.notes50 = 0;
						$scope.inputObj.notes20 = 0;
						$scope.inputObj.notes10 = 0;
						$scope.inputObj.notes5 = 0;
						$scope.inputObj.notes2 = 0;
						$scope.inputObj.notes1 = 0;
						$scope.inputObj.strapped100 = 0;
						$scope.inputObj.strapped50 = 0;
						$scope.inputObj.strapped20 = 0;
						$scope.inputObj.strapped10 = 0;
						$scope.inputObj.strapped5 = 0;
						$scope.inputObj.strapped2 = 0;
						$scope.inputObj.strapped1 = 0;
						$scope.inputObj.loosec1 = 0;
						$scope.inputObj.loose050 = 0;
						$scope.inputObj.loose025 = 0;
						$scope.inputObj.loose010 = 0;
						$scope.inputObj.loose005 = 0;
						$scope.inputObj.loose001 = 0;
						if ($scope.isApprovalFlow == '1') {
							$scope.inputObj.loose100 = "150";
						}
					}

					$scope.initDeno2 = function() {
						$scope.inputObj.out_loose100 = 0;
						$scope.inputObj.out_loose50 = 0;
						$scope.inputObj.out_loose20 = 0;
						$scope.inputObj.out_loose10 = 0;
						$scope.inputObj.out_loose5 = 0;
						$scope.inputObj.out_loose2 = 0;
						$scope.inputObj.out_loose1 = 0;
						$scope.inputObj.out_notes100 = 0;
						$scope.inputObj.out_notes50 = 0;
						$scope.inputObj.out_notes20 = 0;
						$scope.inputObj.out_notes10 = 0;
						$scope.inputObj.out_notes5 = 0;
						$scope.inputObj.out_notes2 = 0;
						$scope.inputObj.out_notes1 = 0;
						$scope.inputObj.out_strapped100 = 0;
						$scope.inputObj.out_strapped50 = 0;
						$scope.inputObj.out_strapped20 = 0;
						$scope.inputObj.out_strapped10 = 0;
						$scope.inputObj.out_strapped5 = 0;
						$scope.inputObj.out_strapped2 = 0;
						$scope.inputObj.out_strapped1 = 0;
						$scope.inputObj.out_loosec1 = 0;
						$scope.inputObj.out_loose050 = 0;
						$scope.inputObj.out_loose025 = 0;
						$scope.inputObj.out_loose010 = 0;
						$scope.inputObj.out_loose005 = 0;
						$scope.inputObj.out_loose001 = 0;
						if ($scope.isApprovalFlow == '1') {
							$scope.inputObj.out_loose100 = "90";
						}
					}

					$scope.dashboardshowSharePopup = function() {
						/* if ($(".green-txt").length >= 1) { */
						if (checkEmpty($scope.authSuccessArr)) {
							$scope.showSharePopup();
						} else {
							swal(
									{
										title : "Error",
										text : "Please authenticate the customer before proceeding with the transaction."
									}, function(isConfirm) {
										$scope.openedFrmShare = 1;
										$scope.otpClick();
									});
						}
					}

					$scope.custIdSearchAgent = function(inputObj, id) {
						$scope.flagCust = id;
						$scope.inputObject = {};
						$scope.cType = 'Retail';
						$rootScope.popupContent = 'custIdPopup';
						openPopup("custIdPopup");
						$rootScope.flagSearcher = '';

					};
					$scope.searchForCif = function(searchType, inputObj) {
						inputObj.page = searchType;
						$rootScope.flagSearcher = 'C';
					}
					$scope.processCifContinueClick = function() {
						$scope.inputObj.ciffId = "CIF20150128085721";
						$scope.inputObj.custname = "Steve Robin";
						closePopup("custIdPopup");
					};

					$scope.openCityCodePopup = function(fieldname) {
						closePopup("ctr");
						$scope.inputObj.fieldWithPopup = fieldname;
						$("#cityIdPopup").popup("destroy");
						$("#cityIdPopup").show();
						$("#cityIdPopup").popup().popup("open");
					}

					$scope.closeCityCode = function(currentRow) {
						$scope.ctrInputObj[$scope.inputObj.fieldWithPopup] = currentRow;
						$scope.inputObj[$scope.inputObj.fieldWithPopup] = currentRow;
						closePopup("cityIdPopup");
						openPopup("ctr");
					}

					$scope.openStateCodePopup = function(fieldname) {
						closePopup("ctr");
						$scope.inputObj.fieldWithPopup = fieldname;
						$("#stateCodePopup").popup("destroy");
						$("#stateCodePopup").show();
						$("#stateCodePopup").popup().popup("open");
					}

					$scope.closeStateCode = function(currentRow) {
						$scope.ctrInputObj[$scope.inputObj.fieldWithPopup] = currentRow;
						closePopup("stateCodePopup");
						openPopup("ctr");
					}

					$scope.openCountryCodePopup = function(fieldname) {
						closePopup("ctr");
						$scope.inputObj.fieldWithPopup = fieldname;
						$("#countryCodePopup").popup("destroy");
						$("#countryCodePopup").show();
						$("#countryCodePopup").popup().popup("open");
					}

					$scope.closeCountryCode = function(currentRow) {
						$scope.ctrInputObj[$scope.inputObj.fieldWithPopup] = currentRow;
						$scope.inputObj[$scope.inputObj.fieldWithPopup] = currentRow;
						closePopup("countryCodePopup");
						openPopup("ctr");
					}

					$scope.newAppointmentAdd = function(name) {
						$scope.inputObj = {};
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
						}, 0);
						if (name != undefined && name != "") {
							var message = 'Your appointment to meet ' + name
									+ ' is added successfully';

						} else {
							var message = 'Your appointment is added successfully';
						}
						nativeAlert(message, 'Success', defaultBtnArray);
					}

					$scope.addInstDetailsCheckDeposit = function(docDetailsObj) {
						if (docDetailsObj != undefined
								&& docDetailsObj.insNumber != undefined
								&& docDetailsObj.instrumentAmount != undefined) {
							var documnt = angular.copy(docDetailsObj);
							$scope.insDtlArr.push(documnt);
						}
						this.inputObjt = {
							"instrumentDate" : $scope.Date
						};
					};

					$scope.deleteInstDetailsCheckDeposit = function(index) {
						/*
						 * delete $scope.docArrCust[index];
						 * $scope.docArrCust.length = $scope.docArrCust.length -
						 * 1;
						 */
						$scope.insDtlArr.splice(index, 1);
					}

					$scope.populateCustName = function() {
						if (checkEmpty($scope.inputObj.ciffId)) {
							$scope.inputObj.customerName = "Regina Grey";
						}
					}

					$scope.openOutputDeno = function() {
						if ($scope.inputObj.outputCurrency == $scope.inputObj.inputCurrency
								|| ($scope.inputObj.outputCurrency != $scope.inputObj.inputCurrency && checkEmpty($scope.inputObj.destinationAmt))) {
							openPopup('denomination2');
						} else {
							nativeAlert(
									"Please enter the exchange rate details.",
									"Error", defaultBtnArray);
						}
					}

					$scope.openCustAcctPopup = function() {
						openPopup("custAcctPopup");
					}

					$scope.custAccountSelect = function() {
						if ($scope.inputObject.acctRow == "1") {
							$scope.Data.dashAcctNum = "3200CA1789654123";
						} else if ($scope.inputObject.acctRow == "2") {
							$scope.Data.dashAcctNum = "3200SB1645890701";
						} else {
							$scope.Data.dashAcctNum = "3200SB1645890701";
						}
						closePopup("custAcctPopup");
						$scope.toAccountBlurDashboard();
						$scope.viewDetailsClick("", Data.dashAcctNum);
						$state.go("dashboard");
					}

					$scope.toAccountBlurDashboard = function() {
						$scope.toDashAccName = "Mr. Steve Robin";
						$scope.toDashAccCurrency = "USD";
					};

					$scope.processCurrencyExchange = function(inputObj) {
						if (inputObj.inputCurrency == inputObj.outputCurrency) {
							if (inputObj.transactionAmount != inputObj.outputAmount) {
								nativeAlert(
										"Entered output value doesn't match with the input value. Please recheck.",
										"Error", defaultBtnArray);
								return;
							}
						} else {
							if (inputObj.destinationAmt != inputObj.outputAmount) {
								nativeAlert(
										"Entered output value doesn't match with the amount in chosen currency. Please recheck.",
										"Error", defaultBtnArray);
								return;
							}
						}
						/*
						 * if (parseInt(inputObj.transactionAmount) >= 10000 &&
						 * $scope.inputObj.isCtr != true) { swal( { title :
						 * "Error", text : "You have crossed your day's
						 * aggregate amount. Please enter the CTR details." },
						 * function(isConfirm) { }); } else {
						 */
						$state.go($state.current.name + "success")
						// }
					}

					$scope.tdClosureContinue = function(index) {
						$scope.tdClosureObj = $scope.tdClosureObjComp[index];
						$state.go("dashboard.template.tdclosure");
					}

					$scope.navToCombinedDep = function() {
						$scope.inputObj = {};
						$scope.repeatTask('reset');
						$scope.navigate('combineddeposit');
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
						}, 0);
					}

					$scope.initRoutingNum = function() {
						if ($scope.inputObj.bankCode
								&& $scope.inputObj.branchCode) {
							$scope.inputObj.routingNum = "762171";
						}
					}

					$scope.amlDetails = function(val) {
						if (val == "cust") {
							$scope.inputObj.depositor = $scope.viewDtl.name;
							$scope.inputObj.contactDetls = "(152) 555-1321";
							$scope.inputObj.idType = "National ID";
							$scope.inputObj.idNo = "409-52-5050";
							$scope.inputObj.nationality = "American";
						} else {
							$scope.inputObj.depositor = "";
							$scope.inputObj.contactDetls = "";
							$scope.inputObj.idType = "";
							$scope.inputObj.idType = "";
							$scope.inputObj.idNo = "";
							$scope.inputObj.nationality = "";
						}
						setTimeout(function() {
							$("select").selectmenu("refresh", true);
						}, 0);
					}

					$scope.captureDoc = function() {
						$scope.captureInsPopup = 'option';
						openPopup("captureDoc");
					}
					$scope.openOptionDoc = function(radioVal) {
						$scope.signRadioVal2 = radioVal;
						if (radioVal == "gallery") {
							$scope.captureInsPopup = "gallery";
						} else {
							$scope.captureInsPopup = 'saveloading';
							setTimeout(function() {
								$scope.captureInsPopup = 'savesuccess';
								$scope.$apply();
							}, 500);
						}
					}
					$scope.openLoadingDoc = function() {
						// $scope.capturedImg = "images/user-2.png";
						$scope.captureInsPopup = 'saveloading';
						setTimeout(function() {
							$scope.captureInsPopup = 'savesuccess';
							$scope.$apply();
						}, 500);
					}
					
					$scope.fileaDispute = function(cifid){
						
						$state.go("tellerdashboard.template.fileADispute");
						$scope.inputObj.ciffId = cifid;
					}
					$scope.identificationScanCust = function(docDetailsObj) {
						if (docDetailsObj != undefined) {
							if($scope.inputObj.docArrCust == undefined){
								$scope.inputObj.docArrCust = [];
							}
							docDetailsObj.docStatus = "Pending";
							var documnt = angular.copy(docDetailsObj);
							$scope.inputObj.docArrCust.push(documnt);
						}
					};

					$scope.deleteCustomers = function(index) {
						$scope.inputObj.docArrCust.splice(index, 1);
					}
					
					$scope.captureCustImg = function(index) {
						if((index)!=undefined){
							$scope.inputObj.index=index;
						}
						else{
							delete $scope.inputObj.index;
						}
						
						$scope.captureImgPopup = 'option';
						
						openPopup("captureCustImg");
					}
					$scope.openOptionSign = function(radioVal) {
						if (radioVal == "gallery1") {
							$scope.captureSignPopup = "gallery";
						} else if (radioVal == "signpad1") {
							$scope.captureSignPopup = "signpad";
						} else {
							$scope.capturedSign = "images/signature.jpg";
							$scope.captureSignPopup = 'saveloading';
							setTimeout(function() {
								$scope.captureSignPopup = 'savesuccess';
								$scope.$apply();
							}, 500);
						}
					}

					$scope.openLoadingSign = function() {
						/*
						 * if($scope.signRadioVal1 == "gallery1"){ var
						 * selected_file = $('#uploadSign').get(0).files[0];
						 * selected_file = window.URL
						 * .createObjectURL(selected_file); $scope.capturedSign =
						 * selected_file; } else {
						 */
						$scope.capturedSign = "images/signature.jpg";
						// }

						$scope.captureSignPopup = 'saveloading';
						setTimeout(function() {
							$scope.captureSignPopup = 'savesuccess';
							$scope.$apply();
						}, 500);
					}
					$scope.openOptionImg = function(radioVal) {
						$scope.signRadioVal2 = radioVal;
						if (radioVal == "gallery") {
							$scope.captureImgPopup = "gallery";
						} else {
							$scope.captureImgPopup = 'saveloading';
							setTimeout(function() {
								$scope.captureImgPopup = 'savesuccess';
								$scope.$apply();
							}, 500);
						}
					}

					$scope.openLoadingImg = function() {
						/*
						 * if($scope.signRadioVal2 == "gallery"){ var
						 * selected_file = $('#sign').get(0).files[0];
						 * selected_file = window.URL
						 * .createObjectURL(selected_file); $scope.capturedImg =
						 * selected_file; } else {
						 */
						$scope.capturedImg = "images/user-2.png";
						// }
						$scope.captureImgPopup = 'saveloading';
						setTimeout(function() {
							$scope.captureImgPopup = 'savesuccess';
							$scope.$apply();
						}, 500);
					}

					$scope.closePopup = function(id) {
						if (id == "captureSign") {
							$scope.signStatus = 'Uploaded';
						} else if (id == "captureCustImg") {
							if (($scope.inputObj.index) != undefined) {
								$scope.inputObj.docArrCust[$scope.inputObj.index].docStatus = "Uploaded";
							} else {
								$scope.imgStatus = 'Uploaded';
							}

						}

						closePopup(id);
					}

					$scope.openPopup = function(id, imgtype) {
						if (imgtype == "custimg") {
							$scope.viewimg = "images/user-2.png";
						}
						if (imgtype == "docimg") {
							$scope.viewimg = "images/dl.jpg";
						}
						openPopup(id);
					}
					$scope.closeViewPopup = function() {
						closePopup("viewImg");
					}
					
					$scope.navigateFromKiosk = function(page, callbackFn) {
						delete this.Data.rateVal;
						this.Data.rateCode = "";
						$scope.feemsg = "";
						if (($state.current.name).split("template.")[1] == page) {
							$scope.inputObj = {};
						}
							$(".disable-anchor").removeClass("disable-anchor");
							if ($state.current.name == "dashboard") {
								$state.go("dashboard.template");
							}
							if ($("#menuTitle").text() == "Teller Admin") {
								$state.go("dashboard." + page);

							} else {

								$state.go("dashboard.template." + page);
							}
					};
					$scope.tokenList = [];
					$scope.addToTokenList = function(inputObj,page){
						inputObj.pageType=page
						$scope.tokenList.push(inputObj);
						$state.go("dashboard");
					}
				});

function floatingIconClick() {
	var x = $('.fab-section').find('.mini-action-button').length * 60 + 60;
	$('.fab-section').height(x);
	$('.action-btn').toggle();
	// $('.main-action-button-txt').toggle();
	$(".fab img").toggleClass("rotate-floating-icon");
	$(".fab img").toggleClass("rotate-floating-icon-reset");
}

myApp.factory('Data', function() {
	var Data = {};
	Data.getAccCurrency = function() {
		return Data.accCurrency;
	}, Data.setAccCurrency = function(accCurrency) {
		Data.accCurrency = accCurrency;
	}
	return Data;
});

myApp.filter('isNaN', function() {
	return function(input, defaultValue) {
		if (isNaN(input)) {
			return defaultValue;
		}
		return input;
	}
});

myApp.filter('transactType', function() {
	return function(input) {
		if (input == "C") {
			return "Credit";
		} else if (input == "D") {
			return "Debit";
		}
	};
});

myApp.filter('titleTransactType', function() {
	return function(input) {
		input = input || '';
		return input.replace(/\w\S*/g, function(txt) {
			return txt.charAt(0).toUpperCase()
					+ txt.substr(1).replace(/([A-Z])/g, ' $1');
		});
	};
});

myApp.directive('modal', function() {
	return {
		templateUrl : 'exchangeRatePopup.html',
		restrict : 'E',
		transclude : true,
		replace : true,
		scope : {
			acccurr : '@',
			curr : '@'
		},
		link : function(scope, element, attrs) {
			scope.accCurr = attrs.acccurr;
			/*
			 * scope.$watch(attrs.curr, function(val) { scope.curr = val; });
			 */
			scope.curr = attrs.curr;
		}
	};

});

myApp.directive('sharepopup', function() {
	return {
		templateUrl : 'sharePopup.html',
		restrict : 'E',
		transclude : true,
		replace : true,
	};

});

myApp.directive('denominationpopup', function() {
	return {
		templateUrl : 'denomination.html',
		restrict : 'E',
		transclude : true,
		replace : true,
	};
});
myApp.directive('ctrpopup', function() {
	return {
		templateUrl : 'ctr.html',
		restrict : 'E',
		transclude : true,
		replace : true,
	};
});

function checkMenu() {

	var phrases = [];

	$('#dashboardlist').each(function() {

		var phrase = '';
		var menuss = menus + "";
		menuss = menuss.split(",");
		$(this).find('li').each(function() {
			var current = $(this);
			var a = 0;
			for (var i = 0; i < menuss.length; i++) {
				current.hide();
				if ($(this).text() == menuss[i]) {
					a = 1;
					current.show();
					break;
				}
			}

			phrases.push($(this).text());
		});
	});

}

myApp.factory(
		"getWatchCount",
		function() {

			// I return the count of watchers on the current page.
			function getWatchCount() {

				var total = 0;

				// AngularJS denotes new scopes in the HTML markup by appending the
				// class "ng-scope" to appropriate elements. As such, rather than 
				// attempting to navigate the hierarchical Scope tree, we can simply
				// query the DOM for the individual scopes. Then, we can pluck the 
				// watcher-count from each scope.
				// --
				// NOTE: Ordinarily, it would be a HUGE SIN for an AngularJS service
				// to access the DOM (Document Object Model). But, in this case,
				// we're not really building a true AngularJS service, so we can 
				// break the rules a bit.
				angular.element( ".ng-scope" ).each(
					function ngScopeIterator() {

						// Get the scope associated with this element node.
						var scope = $( this ).scope();

						// The $$watchers value starts out as NULL. 
						total += scope.$$watchers
							? scope.$$watchers.length
							: 0
						;

					}
				);
				
				return( total );

			}

			// For convenience, let's serialize the above method and convert it to 
			// a bookmarklet that can easily be run on ANY AngularJS page. 
			getWatchCount.bookmarklet = ( 
				"javascript:alert('Watchers:'+(" + 
				getWatchCount.toString()
					.replace( /\/\/.*/g, " " )
					.replace( /\s+/g, " " ) +
				")());void(0);" 
			);

			return( getWatchCount );

		}
	);